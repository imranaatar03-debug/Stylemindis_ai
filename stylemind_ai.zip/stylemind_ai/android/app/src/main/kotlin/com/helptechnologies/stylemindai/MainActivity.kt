package com.helptechnologies.stylemindai

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
