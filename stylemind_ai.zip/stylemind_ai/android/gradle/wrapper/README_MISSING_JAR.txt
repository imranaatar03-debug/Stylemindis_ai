gradle-wrapper.jar is intentionally NOT included here
======================================================

This project ships gradlew, gradlew.bat and gradle-wrapper.properties
(pinned to Gradle 8.4), but not the compiled gradle-wrapper.jar binary
itself — it was generated in a sandboxed environment with no internet
access and no local Gradle/Flutter installation, so a genuine jar could
not be produced or verified here.

You need to generate it once on your own machine (which already has
Flutter/Android Studio and internet access). Pick ONE of these:

1. Easiest — let Flutter regenerate the missing Android tooling files:
     flutter create --platforms=android .
   Run this from the project root. It only fills in missing
   platform-glue files (like this jar) and will NOT touch your lib/
   code, pubspec.yaml, or the customizations already made under
   android/ (manifest, build.gradle, icons, etc.) — but do review the
   diff / re-check android/app/build.gradle and AndroidManifest.xml
   afterwards in case it adds its own defaults.

2. Or, if you have Gradle installed separately:
     cd android
     gradle wrapper --gradle-version 8.4
     cd ..

3. Or open the project once in Android Studio — it detects the missing
   wrapper jar and offers to download/generate it automatically.

After that, gradlew/gradlew.bat will work immediately since the
scripts and gradle-wrapper.properties are already in place.
