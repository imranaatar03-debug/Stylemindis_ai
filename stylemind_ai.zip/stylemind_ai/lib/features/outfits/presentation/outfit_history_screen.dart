import 'package:flutter/material.dart';

import '../../../core/constants/app_constants.dart';
import '../../../core/constants/colors.dart';
import '../../../core/constants/strings.dart';
import '../../../core/widgets/empty_state.dart';
import '../../../models/outfit_model.dart';
import '../../outfit_generator/presentation/outfit_result_screen.dart';

class OutfitHistoryScreen extends StatefulWidget {
  const OutfitHistoryScreen({super.key});

  @override
  State<OutfitHistoryScreen> createState() =>
      _OutfitHistoryScreenState();
}

class _OutfitHistoryScreenState
    extends State<OutfitHistoryScreen> {
  final List<OutfitModel> _history = [];

  String _selectedFilter = 'All';

  List<OutfitModel> get _filteredHistory {
    if (_selectedFilter == 'All') {
      return List<OutfitModel>.from(_history.reversed);
    }

    return _history
        .where(
          (outfit) => outfit.occasion == _selectedFilter,
        )
        .toList()
        .reversed
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: AppBar(
        title: const Text(
          AppStrings.outfitHistory,
          style: TextStyle(
            fontWeight: FontWeight.w800,
          ),
        ),
        centerTitle: false,
        actions: [
          if (_history.isNotEmpty)
            IconButton(
              onPressed: _showClearDialog,
              icon: const Icon(
                Icons.delete_sweep_outlined,
              ),
              tooltip: 'Clear history',
            ),
        ],
      ),
      body: SafeArea(
        child: _history.isEmpty
            ? _buildEmptyState()
            : Column(
                children: [
                  _buildFilter(theme),
                  const SizedBox(height: 8),
                  Expanded(
                    child: _buildHistoryList(theme),
                  ),
                ],
              ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return EmptyState(
      icon: Icons.history_rounded,
      title: 'No outfit history',
      message:
          'Your generated outfits will appear here so you can revisit your previous looks.',
      actionLabel: AppStrings.createOutfit,
      onAction: () {
        Navigator.pushNamed(
          context,
          '/create-outfit',
        );
      },
    );
  }

  Widget _buildFilter(ThemeData theme) {
    final filters = <String>[
      'All',
      ...AppConstants.supportedOccasions,
    ];

    return SizedBox(
      height: 48,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(
          horizontal: 20,
        ),
        scrollDirection: Axis.horizontal,
        itemCount: filters.length,
        separatorBuilder: (_, __) =>
            const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final filter = filters[index];
          final selected = _selectedFilter == filter;

          return GestureDetector(
            onTap: () {
              setState(() {
                _selectedFilter = filter;
              });
            },
            child: AnimatedContainer(
              duration: const Duration(
                milliseconds: 200,
              ),
              padding: const EdgeInsets.symmetric(
                horizontal: 16,
              ),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: selected
                    ? AppColors.primary
                    : theme.cardColor,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: selected
                      ? AppColors.primary
                      : theme.dividerColor.withOpacity(0.4),
                ),
              ),
              child: Text(
                filter,
                style: theme.textTheme.labelMedium?.copyWith(
                  color: selected
                      ? Colors.white
                      : theme.textTheme.bodyMedium?.color,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildHistoryList(ThemeData theme) {
    final history = _filteredHistory;

    if (history.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(30),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.filter_alt_off_rounded,
                size: 48,
                color: AppColors.primary.withOpacity(0.7),
              ),
              const SizedBox(height: 14),
              Text(
                'No outfits found',
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                'Try another occasion filter.',
                textAlign: TextAlign.center,
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.textTheme.bodyMedium?.color
                      ?.withOpacity(0.6),
                ),
              ),
            ],
          ),
        ),
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(
        20,
        8,
        20,
        30,
      ),
      itemCount: history.length,
      separatorBuilder: (_, __) =>
          const SizedBox(height: 12),
      itemBuilder: (context, index) {
        return _buildHistoryCard(
          theme,
          history[index],
        );
      },
    );
  }

  Widget _buildHistoryCard(
    ThemeData theme,
    OutfitModel outfit,
  ) {
    return Material(
      color: theme.cardColor,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => OutfitResultScreen(
                outfit: outfit,
              ),
            ),
          );
        },
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: theme.dividerColor.withOpacity(0.35),
            ),
          ),
          child: Row(
            children: [
              _buildPreview(theme, outfit),
              const SizedBox(width: 14),
              Expanded(
                child: _buildInfo(theme, outfit),
              ),
              const SizedBox(width: 6),
              const Icon(
                Icons.chevron_right_rounded,
                color: AppColors.primary,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPreview(
    ThemeData theme,
    OutfitModel outfit,
  ) {
    return Container(
      width: 82,
      height: 82,
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: AppColors.primary.withOpacity(0.08),
        borderRadius: BorderRadius.circular(16),
      ),
      child: outfit.items.isEmpty
          ? const Icon(
              Icons.checkroom_rounded,
              size: 34,
              color: AppColors.primary,
            )
          : GridView.builder(
              physics:
                  const NeverScrollableScrollPhysics(),
              itemCount: outfit.items.length > 4
                  ? 4
                  : outfit.items.length,
              gridDelegate:
                  const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 3,
                mainAxisSpacing: 3,
              ),
              itemBuilder: (context, index) {
                final imagePath =
                    outfit.items[index].imagePath;

                if (imagePath.isEmpty) {
                  return Container(
                    decoration: BoxDecoration(
                      color: theme.cardColor,
                      borderRadius:
                          BorderRadius.circular(6),
                    ),
                    child: const Icon(
                      Icons.checkroom_rounded,
                      size: 18,
                      color: AppColors.primary,
                    ),
                  );
                }

                return ClipRRect(
                  borderRadius:
                      BorderRadius.circular(6),
                  child: Image.network(
                    imagePath,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) {
                      return Container(
                        color: theme.cardColor,
                        child: const Icon(
                          Icons.image_outlined,
                          size: 18,
                          color: AppColors.primary,
                        ),
                      );
                    },
                  ),
                );
              },
            ),
    );
  }

  Widget _buildInfo(
    ThemeData theme,
    OutfitModel outfit,
  ) {
    final date = _formatDate(outfit.createdAt);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          outfit.name,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w800,
          ),
        ),
        const SizedBox(height: 6),
        Wrap(
          spacing: 6,
          runSpacing: 6,
          children: [
            _buildTag(
              theme,
              outfit.style,
              Icons.style_rounded,
            ),
            _buildTag(
              theme,
              outfit.occasion,
              Icons.event_rounded,
            ),
          ],
        ),
        const SizedBox(height: 7),
        Row(
          children: [
            const Icon(
              Icons.auto_awesome_rounded,
              size: 14,
              color: AppColors.primary,
            ),
            const SizedBox(width: 5),
            Text(
              '${outfit.compatibilityScore}% match',
              style: theme.textTheme.bodySmall?.copyWith(
                color: AppColors.primary,
                fontWeight: FontWeight.w700,
              ),
            ),
            const Spacer(),
            Text(
              date,
              style: theme.textTheme.bodySmall?.copyWith(
                color: theme.textTheme.bodySmall?.color
                    ?.withOpacity(0.55),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildTag(
    ThemeData theme,
    String text,
    IconData icon,
  ) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 8,
        vertical: 5,
      ),
      decoration: BoxDecoration(
        color: theme.scaffoldBackgroundColor,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            size: 12,
            color: AppColors.primary,
          ),
          const SizedBox(width: 4),
          Text(
            text,
            style: theme.textTheme.labelSmall?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);

    if (difference.inMinutes < 1) {
      return 'Just now';
    }

    if (difference.inHours < 1) {
      return '${difference.inMinutes}m ago';
    }

    if (difference.inDays < 1) {
      return '${difference.inHours}h ago';
    }

    if (difference.inDays < 7) {
      return '${difference.inDays}d ago';
    }

    return '${date.day}/${date.month}/${date.year}';
  }

  Future<void> _showClearDialog() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text(
            'Clear outfit history?',
          ),
          content: const Text(
            'This will remove all outfits from your history.',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(
                  dialogContext,
                  false,
                );
              },
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () {
                Navigator.pop(
                  dialogContext,
                  true,
                );
              },
              child: const Text('Clear'),
            ),
          ],
        );
      },
    );

    if (confirmed == true && mounted) {
      setState(() {
        _history.clear();
        _selectedFilter = 'All';
      });
    }
  }
}