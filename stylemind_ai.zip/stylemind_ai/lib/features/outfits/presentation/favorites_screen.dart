import 'package:flutter/material.dart';

import '../../../core/constants/colors.dart';
import '../../../core/constants/strings.dart';
import '../../../core/widgets/empty_state.dart';
import '../../../models/outfit_model.dart';
import '../../outfit_generator/presentation/outfit_result_screen.dart';

class FavoritesScreen extends StatefulWidget {
  const FavoritesScreen({super.key});

  @override
  State<FavoritesScreen> createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> {
  final List<OutfitModel> _favorites = [];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: AppBar(
        title: const Text(
          AppStrings.favorites,
          style: TextStyle(
            fontWeight: FontWeight.w800,
          ),
        ),
        centerTitle: false,
      ),
      body: SafeArea(
        child: _favorites.isEmpty
            ? _buildEmptyState()
            : _buildFavorites(theme),
      ),
    );
  }

  Widget _buildEmptyState() {
    return EmptyState(
      icon: Icons.favorite_border_rounded,
      title: 'No favorite outfits',
      message:
          'Save outfits you love and they will appear here for quick access.',
      actionLabel: AppStrings.createOutfit,
      onAction: () {
        Navigator.pushNamed(
          context,
          '/create-outfit',
        );
      },
    );
  }

  Widget _buildFavorites(ThemeData theme) {
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 30),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 14,
        mainAxisSpacing: 14,
        childAspectRatio: 0.78,
      ),
      itemCount: _favorites.length,
      itemBuilder: (context, index) {
        return _buildFavoriteCard(
          theme,
          _favorites[index],
        );
      },
    );
  }

  Widget _buildFavoriteCard(
    ThemeData theme,
    OutfitModel outfit,
  ) {
    return Card(
      elevation: 0,
      margin: EdgeInsets.zero,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(
          color: theme.dividerColor.withOpacity(0.35),
        ),
      ),
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => OutfitResultScreen(
                outfit: outfit,
              ),
            ),
          );
        },
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: _buildPreview(
                theme,
                outfit,
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(
                12,
                10,
                8,
                12,
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          outfit.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: theme.textTheme.titleSmall?.copyWith(
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          outfit.style,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: theme.textTheme.bodySmall?.color
                                ?.withOpacity(0.6),
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () {
                      setState(() {
                        _favorites.removeWhere(
                          (item) => item.id == outfit.id,
                        );
                      });
                    },
                    icon: const Icon(
                      Icons.favorite_rounded,
                      color: AppColors.error,
                    ),
                    tooltip: AppStrings.removeFromFavorites,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPreview(
    ThemeData theme,
    OutfitModel outfit,
  ) {
    if (outfit.items.isEmpty) {
      return Container(
        width: double.infinity,
        decoration: BoxDecoration(
          color: AppColors.primary.withOpacity(0.08),
        ),
        child: const Center(
          child: Icon(
            Icons.checkroom_rounded,
            size: 48,
            color: AppColors.primary,
          ),
        ),
      );
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: AppColors.primary.withOpacity(0.06),
      ),
      child: GridView.builder(
        physics: const NeverScrollableScrollPhysics(),
        itemCount:
            outfit.items.length > 4 ? 4 : outfit.items.length,
        gridDelegate:
            const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 6,
          mainAxisSpacing: 6,
        ),
        itemBuilder: (context, index) {
          final imagePath = outfit.items[index].imagePath;

          if (imagePath.isEmpty) {
            return Container(
              decoration: BoxDecoration(
                color: theme.cardColor,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(
                Icons.checkroom_rounded,
                color: AppColors.primary,
              ),
            );
          }

          return ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.network(
              imagePath,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) {
                return Container(
                  color: theme.cardColor,
                  child: const Icon(
                    Icons.image_not_supported_outlined,
                    color: AppColors.primary,
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}