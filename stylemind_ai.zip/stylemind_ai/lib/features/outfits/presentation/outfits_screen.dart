import 'package:flutter/material.dart';

import '../../../core/constants/colors.dart';
import '../../../core/constants/strings.dart';
import '../../../core/widgets/app_card.dart';
import '../../../core/widgets/empty_state.dart';
import '../../../models/outfit_model.dart';
import '../../../models/outfit_item_model.dart';
import '../../outfit_generator/presentation/outfit_result_screen.dart';

class OutfitsScreen extends StatefulWidget {
  const OutfitsScreen({super.key});

  @override
  State<OutfitsScreen> createState() => _OutfitsScreenState();
}

class _OutfitsScreenState extends State<OutfitsScreen> {
  int _selectedTab = 0;

  final List<String> _tabs = const [
    AppStrings.all,
    AppStrings.favorites,
    AppStrings.history,
  ];

  final List<OutfitModel> _outfits = [];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: AppBar(
        title: const Text(
          AppStrings.outfits,
          style: TextStyle(
            fontWeight: FontWeight.w700,
          ),
        ),
        centerTitle: false,
        actions: [
          IconButton(
            onPressed: _openGenerator,
            icon: const Icon(Icons.auto_awesome_rounded),
            tooltip: AppStrings.createOutfit,
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(theme),
            _buildTabs(theme),
            const SizedBox(height: 12),
            Expanded(
              child: _buildContent(theme),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openGenerator,
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.auto_awesome_rounded),
        label: const Text(
          AppStrings.createOutfit,
          style: TextStyle(
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(ThemeData theme) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 4),
      child: Row(
        children: [
          Expanded(
            child: Text(
              'Your style collection',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: theme.textTheme.bodyMedium?.color?.withOpacity(0.65),
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 12,
              vertical: 7,
            ),
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.10),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              '${_outfits.length} outfits',
              style: theme.textTheme.labelMedium?.copyWith(
                color: AppColors.primary,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabs(ThemeData theme) {
    return SizedBox(
      height: 52,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        scrollDirection: Axis.horizontal,
        itemCount: _tabs.length,
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (context, index) {
          final selected = _selectedTab == index;

          return GestureDetector(
            onTap: () {
              setState(() {
                _selectedTab = index;
              });
            },
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              padding: const EdgeInsets.symmetric(horizontal: 18),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: selected
                    ? AppColors.primary
                    : theme.cardColor,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(
                  color: selected
                      ? AppColors.primary
                      : theme.dividerColor.withOpacity(0.5),
                ),
                boxShadow: selected
                    ? [
                        BoxShadow(
                          color: AppColors.primary.withOpacity(0.20),
                          blurRadius: 14,
                          offset: const Offset(0, 5),
                        ),
                      ]
                    : null,
              ),
              child: Text(
                _tabs[index],
                style: theme.textTheme.labelLarge?.copyWith(
                  color: selected
                      ? Colors.white
                      : theme.textTheme.bodyMedium?.color,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildContent(ThemeData theme) {
    final outfits = _filteredOutfits;

    if (outfits.isEmpty) {
      return EmptyState(
        icon: Icons.checkroom_rounded,
        title: _emptyTitle,
        message: _emptyMessage,
        actionLabel: AppStrings.createOutfit,
        onAction: _openGenerator,
      );
    }

    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 110),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 14,
        mainAxisSpacing: 14,
        childAspectRatio: 0.78,
      ),
      itemCount: outfits.length,
      itemBuilder: (context, index) {
        return _buildOutfitCard(
          theme,
          outfits[index],
        );
      },
    );
  }

  Widget _buildOutfitCard(
    ThemeData theme,
    OutfitModel outfit,
  ) {
    return AppCard(
      padding: EdgeInsets.zero,
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () => _openOutfit(outfit),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: _buildOutfitPreview(
                theme,
                outfit,
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    outfit.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: theme.textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          outfit.style,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: theme.textTheme.bodySmall?.color
                                ?.withOpacity(0.60),
                          ),
                        ),
                      ),
                      if (outfit.isFavorite)
                        const Icon(
                          Icons.favorite_rounded,
                          size: 16,
                          color: AppColors.error,
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOutfitPreview(
    ThemeData theme,
    OutfitModel outfit,
  ) {
    if (outfit.items.isEmpty) {
      return Container(
        width: double.infinity,
        decoration: BoxDecoration(
          color: AppColors.primary.withOpacity(0.08),
          borderRadius: const BorderRadius.vertical(
            top: Radius.circular(20),
          ),
        ),
        child: const Center(
          child: Icon(
            Icons.checkroom_rounded,
            size: 48,
            color: AppColors.primary,
          ),
        ),
      );
    }

    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: AppColors.primary.withOpacity(0.06),
        borderRadius: const BorderRadius.vertical(
          top: Radius.circular(20),
        ),
      ),
      padding: const EdgeInsets.all(10),
      child: GridView.builder(
        physics: const NeverScrollableScrollPhysics(),
        itemCount: outfit.items.length > 4
            ? 4
            : outfit.items.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 6,
          mainAxisSpacing: 6,
        ),
        itemBuilder: (context, index) {
          return _buildItemPreview(
            theme,
            outfit.items[index],
          );
        },
      ),
    );
  }

  Widget _buildItemPreview(
    ThemeData theme,
    OutfitItemModel item,
  ) {
    final imagePath = item.imagePath;

    if (imagePath.isEmpty) {
      return Container(
        decoration: BoxDecoration(
          color: theme.cardColor,
          borderRadius: BorderRadius.circular(12),
        ),
        child: const Icon(
          Icons.checkroom_rounded,
          color: AppColors.primary,
        ),
      );
    }

    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: Image.network(
        imagePath,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) {
          return Container(
            color: theme.cardColor,
            child: const Icon(
              Icons.image_not_supported_outlined,
              color: AppColors.primary,
            ),
          );
        },
      ),
    );
  }

  List<OutfitModel> get _filteredOutfits {
    switch (_selectedTab) {
      case 1:
        return _outfits
            .where((outfit) => outfit.isFavorite)
            .toList();

      case 2:
        return List<OutfitModel>.from(_outfits.reversed);

      default:
        return _outfits;
    }
  }

  String get _emptyTitle {
    switch (_selectedTab) {
      case 1:
        return 'No favorite outfits';

      case 2:
        return 'No outfit history';

      default:
        return 'Your outfits are waiting';
    }
  }

  String get _emptyMessage {
    switch (_selectedTab) {
      case 1:
        return 'Save your favorite AI-generated looks and they will appear here.';

      case 2:
        return 'Generated outfits will automatically appear in your history.';

      default:
        return 'Create your first AI-powered outfit from your wardrobe.';
    }
  }

  void _openGenerator() {
    Navigator.pushNamed(
      context,
      '/create-outfit',
    );
  }

  void _openOutfit(OutfitModel outfit) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => OutfitResultScreen(
          outfit: outfit,
        ),
      ),
    );
  }
}