import 'package:flutter/material.dart';

import '../../../core/constants/colors.dart';
import '../../../core/constants/strings.dart';
import '../../../core/widgets/app_card.dart';
import '../../../core/widgets/empty_state.dart';
import '../../../models/outfit_model.dart';
import '../../outfit_generator/presentation/outfit_result_screen.dart';

class OutfitCalendarScreen extends StatefulWidget {
  const OutfitCalendarScreen({super.key});

  @override
  State<OutfitCalendarScreen> createState() =>
      _OutfitCalendarScreenState();
}

class _OutfitCalendarScreenState
    extends State<OutfitCalendarScreen> {
  DateTime _selectedDate = DateTime.now();

  final Map<String, OutfitModel> _scheduledOutfits = {};

  String _dateKey(DateTime date) {
    return '${date.year}-${date.month}-${date.day}';
  }

  OutfitModel? get _selectedOutfit {
    return _scheduledOutfits[_dateKey(_selectedDate)];
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: AppBar(
        title: const Text(
          AppStrings.outfitCalendar,
          style: TextStyle(
            fontWeight: FontWeight.w800,
          ),
        ),
        centerTitle: false,
        actions: [
          IconButton(
            onPressed: _goToToday,
            icon: const Icon(
              Icons.today_rounded,
            ),
            tooltip: 'Today',
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            _buildCalendar(theme),
            const SizedBox(height: 12),
            Expanded(
              child: _buildSelectedDay(theme),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addOutfit,
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        icon: const Icon(
          Icons.add_rounded,
        ),
        label: const Text(
          'Plan outfit',
          style: TextStyle(
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }

  Widget _buildCalendar(ThemeData theme) {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      padding: const EdgeInsets.only(
        bottom: 14,
      ),
      decoration: BoxDecoration(
        color: theme.cardColor,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: theme.dividerColor.withOpacity(0.35),
        ),
      ),
      child: CalendarDatePicker(
        initialDate: _selectedDate,
        firstDate: DateTime(
          DateTime.now().year - 1,
        ),
        lastDate: DateTime(
          DateTime.now().year + 2,
        ),
        onDateChanged: (date) {
          setState(() {
            _selectedDate = date;
          });
        },
      ),
    );
  }

  Widget _buildSelectedDay(ThemeData theme) {
    final outfit = _selectedOutfit;

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(
        20,
        8,
        20,
        110,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _formatSelectedDate(),
            style: theme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 5),
          Text(
            'Your planned look for this day',
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.textTheme.bodyMedium?.color
                  ?.withOpacity(0.6),
            ),
          ),
          const SizedBox(height: 18),
          if (outfit == null)
            _buildEmptyDay(theme)
          else
            _buildOutfitCard(theme, outfit),
        ],
      ),
    );
  }

  Widget _buildEmptyDay(ThemeData theme) {
    return AppCard(
      child: Column(
        children: [
          Container(
            width: 68,
            height: 68,
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.10),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.calendar_month_rounded,
              size: 32,
              color: AppColors.primary,
            ),
          ),
          const SizedBox(height: 14),
          Text(
            'No outfit planned',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 7),
          Text(
            'Plan an outfit for this day and STYLEMIND AI will keep it organized here.',
            textAlign: TextAlign.center,
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.textTheme.bodyMedium?.color
                  ?.withOpacity(0.6),
            ),
          ),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: _addOutfit,
            icon: const Icon(
              Icons.add_rounded,
            ),
            label: const Text(
              'Plan outfit',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOutfitCard(
    ThemeData theme,
    OutfitModel outfit,
  ) {
    return AppCard(
      padding: EdgeInsets.zero,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildOutfitPreview(theme, outfit),
          Padding(
            padding: const EdgeInsets.fromLTRB(
              16,
              14,
              16,
              16,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  outfit.name,
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    _buildTag(
                      theme,
                      outfit.style,
                      Icons.style_rounded,
                    ),
                    const SizedBox(width: 8),
                    _buildTag(
                      theme,
                      outfit.occasion,
                      Icons.event_rounded,
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) =>
                                  OutfitResultScreen(
                                outfit: outfit,
                              ),
                            ),
                          );
                        },
                        icon: const Icon(
                          Icons.visibility_outlined,
                        ),
                        label: const Text(
                          'View',
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    IconButton.filledTonal(
                      onPressed: _removeOutfit,
                      icon: const Icon(
                        Icons.delete_outline_rounded,
                      ),
                      tooltip: 'Remove',
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOutfitPreview(
    ThemeData theme,
    OutfitModel outfit,
  ) {
    if (outfit.items.isEmpty) {
      return Container(
        height: 190,
        width: double.infinity,
        decoration: BoxDecoration(
          color: AppColors.primary.withOpacity(0.08),
          borderRadius: const BorderRadius.vertical(
            top: Radius.circular(20),
          ),
        ),
        child: const Center(
          child: Icon(
            Icons.checkroom_rounded,
            size: 60,
            color: AppColors.primary,
          ),
        ),
      );
    }

    return Container(
      height: 190,
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.primary.withOpacity(0.06),
        borderRadius: const BorderRadius.vertical(
          top: Radius.circular(20),
        ),
      ),
      child: GridView.builder(
        physics: const NeverScrollableScrollPhysics(),
        itemCount:
            outfit.items.length > 4 ? 4 : outfit.items.length,
        gridDelegate:
            const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 8,
          mainAxisSpacing: 8,
        ),
        itemBuilder: (context, index) {
          final imagePath = outfit.items[index].imagePath;

          if (imagePath.isEmpty) {
            return Container(
              decoration: BoxDecoration(
                color: theme.cardColor,
                borderRadius: BorderRadius.circular(14),
              ),
              child: const Icon(
                Icons.checkroom_rounded,
                color: AppColors.primary,
              ),
            );
          }

          return ClipRRect(
            borderRadius: BorderRadius.circular(14),
            child: Image.network(
              imagePath,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) {
                return Container(
                  color: theme.cardColor,
                  child: const Icon(
                    Icons.image_not_supported_outlined,
                    color: AppColors.primary,
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }

  Widget _buildTag(
    ThemeData theme,
    String text,
    IconData icon,
  ) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 6,
      ),
      decoration: BoxDecoration(
        color: AppColors.primary.withOpacity(0.08),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(
            Icons.auto_awesome_rounded,
            size: 13,
            color: AppColors.primary,
          ),
          const SizedBox(width: 4),
          Icon(
            icon,
            size: 13,
            color: AppColors.primary,
          ),
          const SizedBox(width: 4),
          Text(
            text,
            style: theme.textTheme.labelSmall?.copyWith(
              color: AppColors.primary,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }

  String _formatSelectedDate() {
    const weekdays = [
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday',
      'Sunday',
    ];

    const months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];

    return '${weekdays[_selectedDate.weekday - 1]}, '
        '${months[_selectedDate.month - 1]} '
        '${_selectedDate.day}, '
        '${_selectedDate.year}';
  }

  void _goToToday() {
    setState(() {
      _selectedDate = DateTime.now();
    });
  }

  void _addOutfit() {
    Navigator.pushNamed(
      context,
      '/create-outfit',
    );
  }

  void _removeOutfit() {
    setState(() {
      _scheduledOutfits.remove(
        _dateKey(_selectedDate),
      );
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'Outfit removed from the calendar.',
        ),
      ),
    );
  }
}