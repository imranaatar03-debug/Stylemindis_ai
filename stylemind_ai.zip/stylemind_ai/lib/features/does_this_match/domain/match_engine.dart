import '../../../core/utils/color_utils.dart';
import '../../../models/clothing_item_model.dart';

class MatchEngine {
  const MatchEngine();

  double calculateMatchScore(
    ClothingItemModel scannedItem,
    ClothingItemModel wardrobeItem,
  ) {
    double score = 0.0;

    score += _colorScore(
          scannedItem.color,
          wardrobeItem.color,
        ) *
        0.45;

    score += _styleScore(
          scannedItem.style,
          wardrobeItem.style,
        ) *
        0.30;

    score += _categoryScore(
          scannedItem.category,
          wardrobeItem.category,
        ) *
        0.15;

    score += _occasionScore(
          scannedItem.occasion,
          wardrobeItem.occasion,
        ) *
        0.10;

    return score.clamp(0.0, 1.0);
  }

  List<ClothingItemModel> findBestMatches({
    required ClothingItemModel scannedItem,
    required List<ClothingItemModel> wardrobe,
    int limit = 5,
  }) {
    final matches = wardrobe
        .where((item) => item.id != scannedItem.id)
        .map(
          (item) => _ScoredItem(
            item: item,
            score: calculateMatchScore(
              scannedItem,
              item,
            ),
          ),
        )
        .toList();

    matches.sort(
      (a, b) => b.score.compareTo(a.score),
    );

    return matches
        .take(limit)
        .map((entry) => entry.item)
        .toList();
  }

  double _colorScore(String first, String second) {
    if (first.trim().isEmpty || second.trim().isEmpty) {
      return 0.5;
    }

    final a = first.trim().toLowerCase();
    final b = second.trim().toLowerCase();

    if (a == b) {
      return 0.75;
    }

    final neutralColors = <String>{
      'black',
      'white',
      'grey',
      'gray',
      'beige',
      'cream',
      'brown',
      'navy',
    };

    if (neutralColors.contains(a) && neutralColors.contains(b)) {
      return 0.95;
    }

    try {
      final compatibility = ColorUtils.getColorCompatibility(
        a,
        b,
      );

      return compatibility.clamp(0.0, 1.0);
    } catch (_) {
      return 0.55;
    }
  }

  double _styleScore(String first, String second) {
    if (first.trim().isEmpty || second.trim().isEmpty) {
      return 0.5;
    }

    final a = first.trim().toLowerCase();
    final b = second.trim().toLowerCase();

    if (a == b) {
      return 1.0;
    }

    const compatibleStyles = <String, Set<String>>{
      'casual': {
        'minimal',
        'streetwear',
        'sporty',
      },
      'minimal': {
        'casual',
        'classic',
      },
      'streetwear': {
        'casual',
        'sporty',
      },
      'sporty': {
        'casual',
        'streetwear',
      },
      'classic': {
        'minimal',
        'casual',
      },
    };

    if (compatibleStyles[a]?.contains(b) ?? false) {
      return 0.82;
    }

    return 0.45;
  }

  double _categoryScore(String first, String second) {
    if (first.trim().isEmpty || second.trim().isEmpty) {
      return 0.5;
    }

    final a = first.trim().toLowerCase();
    final b = second.trim().toLowerCase();

    if (a == b) {
      return 0.45;
    }

    const tops = {
      't-shirt',
      'tshirt',
      'shirt',
      'hoodie',
      'jacket',
      'sweater',
    };

    const bottoms = {
      'jeans',
      'pants',
      'cargo pants',
      'shorts',
      'trousers',
    };

    const footwear = {
      'shoes',
      'sneakers',
      'boots',
      'sandals',
    };

    if ((tops.contains(a) && bottoms.contains(b)) ||
        (bottoms.contains(a) && tops.contains(b))) {
      return 1.0;
    }

    if ((footwear.contains(a) && (tops.contains(b) || bottoms.contains(b))) ||
        (footwear.contains(b) && (tops.contains(a) || bottoms.contains(a)))) {
      return 0.95;
    }

    return 0.55;
  }

  double _occasionScore(String first, String second) {
    if (first.trim().isEmpty || second.trim().isEmpty) {
      return 0.5;
    }

    final a = first.trim().toLowerCase();
    final b = second.trim().toLowerCase();

    if (a == b) {
      return 1.0;
    }

    if ((a.contains('casual') && b.contains('friends')) ||
        (b.contains('casual') && a.contains('friends'))) {
      return 0.85;
    }

    if ((a.contains('school') && b.contains('casual')) ||
        (b.contains('school') && a.contains('casual'))) {
      return 0.80;
    }

    return 0.55;
  }
}

class _ScoredItem {
  final ClothingItemModel item;
  final double score;

  const _ScoredItem({
    required this.item,
    required this.score,
  });
}