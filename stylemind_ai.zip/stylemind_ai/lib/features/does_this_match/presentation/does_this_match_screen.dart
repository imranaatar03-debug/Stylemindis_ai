import 'package:flutter/material.dart';

import '../../../core/constants/colors.dart';
import '../../../core/constants/strings.dart';
import '../../../core/widgets/app_button.dart';
import '../../../core/widgets/app_card.dart';

class DoesThisMatchScreen extends StatefulWidget {
  const DoesThisMatchScreen({super.key});

  @override
  State<DoesThisMatchScreen> createState() => _DoesThisMatchScreenState();
}

class _DoesThisMatchScreenState extends State<DoesThisMatchScreen>
    with SingleTickerProviderStateMixin {
  bool _isScanning = false;
  bool _hasResult = false;

  late final AnimationController _scanAnimationController;
  late final Animation<double> _scanAnimation;

  @override
  void initState() {
    super.initState();

    _scanAnimationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    );

    _scanAnimation = CurvedAnimation(
      parent: _scanAnimationController,
      curve: Curves.easeInOut,
    );
  }

  @override
  void dispose() {
    _scanAnimationController.dispose();
    super.dispose();
  }

  Future<void> _startScan() async {
    if (_isScanning) return;

    setState(() {
      _isScanning = true;
      _hasResult = false;
    });

    _scanAnimationController.repeat(reverse: true);

    await Future.delayed(const Duration(seconds: 2));

    if (!mounted) return;

    _scanAnimationController.stop();

    setState(() {
      _isScanning = false;
      _hasResult = true;
    });
  }

  void _resetScan() {
    setState(() {
      _hasResult = false;
    });

    _scanAnimationController.reset();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(AppStrings.doesThisMatch),
        centerTitle: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildHeader(context),
              const SizedBox(height: 20),
              _buildScanner(context),
              const SizedBox(height: 20),
              if (_hasResult) ...[
                _buildResult(context),
                const SizedBox(height: 16),
              ],
              if (!_hasResult) _buildInstructions(context),
              const SizedBox(height: 22),
              _buildActionButton(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                gradient: const LinearGradient(
                  colors: [
                    AppColors.primary,
                    AppColors.secondary,
                  ],
                ),
              ),
              child: const Icon(
                Icons.auto_awesome_rounded,
                color: Colors.white,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                'AI Style Match',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w800,
                    ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Text(
          'Scan an item and let STYLEMIND AI check how well it works with your wardrobe.',
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                height: 1.5,
                color: Theme.of(context)
                    .textTheme
                    .bodyMedium
                    ?.color
                    ?.withOpacity(0.65),
              ),
        ),
      ],
    );
  }

  Widget _buildScanner(BuildContext context) {
    return AppCard(
      padding: EdgeInsets.zero,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(22),
        child: AspectRatio(
          aspectRatio: 0.82,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      AppColors.darkBackground,
                      AppColors.primaryDark.withOpacity(0.75),
                    ],
                  ),
                ),
              ),

              Positioned(
                top: 18,
                left: 18,
                right: 18,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _scannerBadge(
                      icon: Icons.camera_alt_rounded,
                      label: 'LIVE SCAN',
                    ),
                    _scannerBadge(
                      icon: Icons.shield_outlined,
                      label: 'PRIVATE',
                    ),
                  ],
                ),
              ),

              // Main detection frame.
              AnimatedBuilder(
                animation: _scanAnimation,
                builder: (context, child) {
                  final scale = 1.0 + (_scanAnimation.value * 0.025);

                  return Transform.scale(
                    scale: scale,
                    child: Container(
                      width: 210,
                      height: 270,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(28),
                        border: Border.all(
                          color: AppColors.secondary.withOpacity(
                            _isScanning ? 0.9 : 0.55,
                          ),
                          width: 2,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.secondary.withOpacity(
                              _isScanning ? 0.22 : 0.08,
                            ),
                            blurRadius: 30,
                            spreadRadius: 4,
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),

              if (_isScanning)
                AnimatedBuilder(
                  animation: _scanAnimation,
                  builder: (context, child) {
                    return Positioned(
                      top: 145 + (_scanAnimation.value * 190),
                      left: 55,
                      right: 55,
                      child: Container(
                        height: 2,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [
                              Colors.transparent,
                              AppColors.secondary,
                              Colors.transparent,
                            ],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: AppColors.secondary.withOpacity(0.7),
                              blurRadius: 10,
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),

              if (!_isScanning && !_hasResult)
                const Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.checkroom_rounded,
                      color: Colors.white70,
                      size: 54,
                    ),
                    SizedBox(height: 12),
                    Text(
                      'Place your clothing item here',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),

              if (_isScanning)
                const Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircularProgressIndicator(
                      strokeWidth: 2.5,
                      color: AppColors.secondary,
                    ),
                    SizedBox(height: 14),
                    Text(
                      'ANALYZING STYLE...',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1.2,
                      ),
                    ),
                  ],
                ),

              if (_hasResult)
                Positioned(
                  bottom: 18,
                  left: 18,
                  right: 18,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 11,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.42),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: const Row(
                      children: [
                        Icon(
                          Icons.check_circle_rounded,
                          color: AppColors.success,
                          size: 20,
                        ),
                        SizedBox(width: 9),
                        Expanded(
                          child: Text(
                            'Item analyzed successfully',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _scannerBadge({
    required IconData icon,
    required String label,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 7,
      ),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.28),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.white.withOpacity(0.12),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            size: 14,
            color: Colors.white,
          ),
          const SizedBox(width: 5),
          Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 10,
              fontWeight: FontWeight.w700,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildResult(BuildContext context) {
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(
                Icons.auto_awesome_rounded,
                color: AppColors.primary,
              ),
              const SizedBox(width: 8),
              Text(
                'AI Match Result',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w800,
                    ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              SizedBox(
                width: 78,
                height: 78,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    const SizedBox(
                      width: 78,
                      height: 78,
                      child: CircularProgressIndicator(
                        value: 0.87,
                        strokeWidth: 7,
                        backgroundColor: Color(0x227C6CFF),
                        valueColor: AlwaysStoppedAnimation<Color>(
                          AppColors.primary,
                        ),
                      ),
                    ),
                    Text(
                      '87%',
                      style: TextStyle(
                        color: AppColors.primary,
                        fontWeight: FontWeight.w800,
                        fontSize: 17,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 16),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Great match!',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    SizedBox(height: 5),
                    Text(
                      'This item works well with several pieces in your wardrobe.',
                      style: TextStyle(
                        fontSize: 12,
                        height: 1.4,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          _resultReason(
            Icons.palette_outlined,
            'Color harmony',
            'Strong color combination',
          ),
          const SizedBox(height: 10),
          _resultReason(
            Icons.style_outlined,
            'Style',
            'Fits your selected style',
          ),
          const SizedBox(height: 10),
          _resultReason(
            Icons.event_available_outlined,
            'Versatility',
            'Works for multiple occasions',
          ),
        ],
      ),
    );
  }

  Widget _resultReason(
    IconData icon,
    String title,
    String subtitle,
  ) {
    return Row(
      children: [
        Container(
          width: 38,
          height: 38,
          decoration: BoxDecoration(
            color: AppColors.primary.withOpacity(0.10),
            borderRadius: BorderRadius.circular(11),
          ),
          child: Icon(
            icon,
            color: AppColors.primary,
            size: 20,
          ),
        ),
        const SizedBox(width: 11),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 13,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                subtitle,
                style: TextStyle(
                  fontSize: 11,
                  color: Colors.grey.shade600,
                ),
              ),
            ],
          ),
        ),
        const Icon(
          Icons.check_circle_rounded,
          color: AppColors.success,
          size: 19,
        ),
      ],
    );
  }

  Widget _buildInstructions(BuildContext context) {
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'How it works',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w800,
                ),
          ),
          const SizedBox(height: 15),
          _instruction(
            number: '01',
            icon: Icons.camera_alt_outlined,
            title: 'Scan an item',
            description: 'Point the camera at one clothing item.',
          ),
          const SizedBox(height: 13),
          _instruction(
            number: '02',
            icon: Icons.auto_awesome_outlined,
            title: 'AI analyzes it',
            description: 'STYLEMIND checks colors, style and compatibility.',
          ),
          const SizedBox(height: 13),
          _instruction(
            number: '03',
            icon: Icons.checkroom_outlined,
            title: 'Get your match',
            description: 'See which wardrobe pieces work best with it.',
          ),
        ],
      ),
    );
  }

  Widget _instruction({
    required String number,
    required IconData icon,
    required String title,
    required String description,
  }) {
    return Row(
      children: [
        Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(13),
            color: AppColors.primary.withOpacity(0.10),
          ),
          child: Center(
            child: Icon(
              icon,
              size: 20,
              color: AppColors.primary,
            ),
          ),
        ),
        const SizedBox(width: 11),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text(
                    number,
                    style: const TextStyle(
                      color: AppColors.primary,
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(width: 7),
                  Text(
                    title,
                    style: const TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 13,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 3),
              Text(
                description,
                style: const TextStyle(
                  fontSize: 11,
                  height: 1.35,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildActionButton() {
    if (_hasResult) {
      return Row(
        children: [
          Expanded(
            child: AppButton(
              text: 'SCAN AGAIN',
              icon: Icons.refresh_rounded,
              onPressed: _resetScan,
              outlined: true,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: AppButton(
              text: 'VIEW OUTFITS',
              icon: Icons.checkroom_rounded,
              onPressed: () {},
            ),
          ),
        ],
      );
    }

    return AppButton(
      text: _isScanning ? 'ANALYZING...' : 'START AI SCAN',
      icon: _isScanning
          ? Icons.hourglass_top_rounded
          : Icons.camera_alt_rounded,
      onPressed: _isScanning ? null : _startScan,
    );
  }
}