import 'package:flutter/foundation.dart';

import '../../../models/clothing_item_model.dart';
import '../domain/match_engine.dart';

class MatchController extends ChangeNotifier {
  final MatchEngine _matchEngine;

  MatchController({
    MatchEngine? matchEngine,
  }) : _matchEngine = matchEngine ?? const MatchEngine();

  bool _isLoading = false;
  String? _error;

  ClothingItemModel? _scannedItem;
  List<ClothingItemModel> _matches = [];
  double? _bestScore;

  bool get isLoading => _isLoading;
  String? get error => _error;

  ClothingItemModel? get scannedItem => _scannedItem;

  List<ClothingItemModel> get matches =>
      List.unmodifiable(_matches);

  double? get bestScore => _bestScore;

  bool get hasResult =>
      _scannedItem != null && _matches.isNotEmpty;

  void setScannedItem(ClothingItemModel item) {
    _scannedItem = item;
    _matches = [];
    _bestScore = null;
    _error = null;

    notifyListeners();
  }

  Future<void> findMatches(
    List<ClothingItemModel> wardrobe, {
    int limit = 5,
  }) async {
    if (_scannedItem == null) {
      _error = 'No clothing item has been scanned.';
      notifyListeners();
      return;
    }

    _setLoading(true);
    _error = null;

    try {
      if (wardrobe.isEmpty) {
        _matches = [];
        _bestScore = null;
        _error = 'Your wardrobe is empty.';
        return;
      }

      _matches = _matchEngine.findBestMatches(
        scannedItem: _scannedItem!,
        wardrobe: wardrobe,
        limit: limit,
      );

      if (_matches.isNotEmpty) {
        _bestScore = _matchEngine.calculateMatchScore(
          _scannedItem!,
          _matches.first,
        );
      } else {
        _bestScore = null;
        _error = 'No compatible items were found.';
      }
    } catch (e) {
      _error = 'Unable to analyze the match.';
      _matches = [];
      _bestScore = null;
    } finally {
      _setLoading(false);
    }
  }

  double getScoreFor(ClothingItemModel item) {
    if (_scannedItem == null) {
      return 0.0;
    }

    return _matchEngine.calculateMatchScore(
      _scannedItem!,
      item,
    );
  }

  void clearResult() {
    _scannedItem = null;
    _matches = [];
    _bestScore = null;
    _error = null;

    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }

  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }
}