import 'package:flutter/material.dart';

import '../../../core/constants/colors.dart';
import '../../../core/constants/strings.dart';
import '../../../core/widgets/app_card.dart';

class PrivacyScreen extends StatefulWidget {
  const PrivacyScreen({super.key});

  @override
  State<PrivacyScreen> createState() => _PrivacyScreenState();
}

class _PrivacyScreenState extends State<PrivacyScreen> {
  bool _cameraPermission = true;
  bool _photoPermission = true;
  bool _locationPermission = false;
  bool _weatherAccess = false;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: AppBar(
        title: const Text(
          AppStrings.privacy,
          style: TextStyle(
            fontWeight: FontWeight.w800,
          ),
        ),
        centerTitle: false,
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(
            20,
            12,
            20,
            32,
          ),
          children: [
            _buildPrivacyHeader(theme),
            const SizedBox(height: 18),
            _buildPermissionsSection(theme),
            const SizedBox(height: 18),
            _buildDataSection(theme),
            const SizedBox(height: 18),
            _buildAiSection(theme),
            const SizedBox(height: 18),
            _buildSecuritySection(theme),
          ],
        ),
      ),
    );
  }

  Widget _buildPrivacyHeader(ThemeData theme) {
    return AppCard(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.10),
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Icon(
              Icons.shield_rounded,
              color: AppColors.primary,
              size: 28,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Your privacy matters',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'You control what STYLEMIND AI can access. Permissions are optional and can be changed at any time.',
                  style: theme.textTheme.bodySmall?.copyWith(
                    height: 1.45,
                    color: theme.textTheme.bodySmall?.color
                        ?.withOpacity(0.65),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPermissionsSection(ThemeData theme) {
    return _buildSection(
      theme,
      title: 'Permissions',
      icon: Icons.admin_panel_settings_outlined,
      children: [
        _buildPermissionTile(
          theme,
          icon: Icons.camera_alt_outlined,
          title: 'Camera',
          subtitle: 'Used for AI Style Scan and outfit matching.',
          value: _cameraPermission,
          onChanged: (value) {
            setState(() {
              _cameraPermission = value;
            });
          },
        ),
        _buildPermissionTile(
          theme,
          icon: Icons.photo_library_outlined,
          title: 'Photos',
          subtitle: 'Used when you add clothing from your gallery.',
          value: _photoPermission,
          onChanged: (value) {
            setState(() {
              _photoPermission = value;
            });
          },
        ),
        _buildPermissionTile(
          theme,
          icon: Icons.location_on_outlined,
          title: 'Location',
          subtitle: 'Optional access for local weather information.',
          value: _locationPermission,
          onChanged: (value) {
            setState(() {
              _locationPermission = value;
            });
          },
        ),
        _buildPermissionTile(
          theme,
          icon: Icons.cloud_outlined,
          title: 'Weather',
          subtitle: 'Allow weather data to improve outfit suggestions.',
          value: _weatherAccess,
          onChanged: (value) {
            setState(() {
              _weatherAccess = value;
            });
          },
        ),
      ],
    );
  }

  Widget _buildDataSection(ThemeData theme) {
    return _buildSection(
      theme,
      title: 'Your data',
      icon: Icons.storage_outlined,
      children: [
        _buildActionTile(
          theme,
          icon: Icons.photo_library_outlined,
          title: 'Uploaded photos',
          subtitle: 'Manage photos you added to your wardrobe.',
          onTap: _showPhotoInfo,
        ),
        _buildActionTile(
          theme,
          icon: Icons.checkroom_outlined,
          title: 'Wardrobe data',
          subtitle: 'Manage your saved clothing items.',
          onTap: _showWardrobeInfo,
        ),
        _buildActionTile(
          theme,
          icon: Icons.auto_awesome_outlined,
          title: 'Outfit data',
          subtitle: 'Manage generated outfits and history.',
          onTap: _showOutfitInfo,
        ),
      ],
    );
  }

  Widget _buildAiSection(ThemeData theme) {
    return _buildSection(
      theme,
      title: 'AI & personalization',
      icon: Icons.auto_awesome_rounded,
      children: [
        _buildInfoTile(
          theme,
          icon: Icons.psychology_outlined,
          title: 'Personalized recommendations',
          description:
              'STYLEMIND AI uses information you provide about your wardrobe and style preferences to create more relevant outfit suggestions.',
        ),
        _buildInfoTile(
          theme,
          icon: Icons.visibility_off_outlined,
          title: 'No unnecessary use',
          description:
              'Your clothing photos and wardrobe information should only be used for the app features you choose to use.',
        ),
        _buildInfoTile(
          theme,
          icon: Icons.tune_rounded,
          title: 'You stay in control',
          description:
              'You can stop using optional features and remove your saved data from the app.',
        ),
      ],
    );
  }

  Widget _buildSecuritySection(ThemeData theme) {
    return _buildSection(
      theme,
      title: 'Security',
      icon: Icons.lock_outline_rounded,
      children: [
        _buildInfoTile(
          theme,
          icon: Icons.lock_rounded,
          title: 'Protected access',
          description:
              'Account and personal information should be handled using secure storage and authenticated access.',
        ),
        _buildInfoTile(
          theme,
          icon: Icons.delete_forever_outlined,
          title: 'Delete your data',
          description:
              'You can request removal of your saved wardrobe, outfits, photos, and profile information from the app.',
        ),
      ],
    );
  }

  Widget _buildSection(
    ThemeData theme, {
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return AppCard(
      padding: const EdgeInsets.fromLTRB(
        8,
        10,
        8,
        8,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(
              10,
              2,
              10,
              8,
            ),
            child: Row(
              children: [
                Icon(
                  icon,
                  size: 19,
                  color: AppColors.primary,
                ),
                const SizedBox(width: 8),
                Text(
                  title,
                  style: theme.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
          ...children,
        ],
      ),
    );
  }

  Widget _buildPermissionTile(
    ThemeData theme, {
    required IconData icon,
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 2,
      ),
      leading: _buildIconContainer(icon),
      title: Text(
        title,
        style: theme.textTheme.bodyMedium?.copyWith(
          fontWeight: FontWeight.w700,
        ),
      ),
      subtitle: Text(
        subtitle,
        style: theme.textTheme.bodySmall?.copyWith(
          height: 1.3,
          color: theme.textTheme.bodySmall?.color
              ?.withOpacity(0.55),
        ),
      ),
      trailing: Switch.adaptive(
        value: value,
        onChanged: onChanged,
      ),
    );
  }

  Widget _buildActionTile(
    ThemeData theme, {
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 2,
      ),
      leading: _buildIconContainer(icon),
      title: Text(
        title,
        style: theme.textTheme.bodyMedium?.copyWith(
          fontWeight: FontWeight.w700,
        ),
      ),
      subtitle: Text(
        subtitle,
        style: theme.textTheme.bodySmall?.copyWith(
          color: theme.textTheme.bodySmall?.color
              ?.withOpacity(0.55),
        ),
      ),
      trailing: const Icon(
        Icons.chevron_right_rounded,
      ),
      onTap: onTap,
    );
  }

  Widget _buildInfoTile(
    ThemeData theme, {
    required IconData icon,
    required String title,
    required String description,
  }) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        10,
        5,
        10,
        12,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildIconContainer(icon),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  description,
                  style: theme.textTheme.bodySmall?.copyWith(
                    height: 1.4,
                    color: theme.textTheme.bodySmall?.color
                        ?.withOpacity(0.58),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildIconContainer(IconData icon) {
    return Container(
      width: 42,
      height: 42,
      decoration: BoxDecoration(
        color: AppColors.primary.withOpacity(0.10),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Icon(
        icon,
        color: AppColors.primary,
        size: 21,
      ),
    );
  }

  void _showPhotoInfo() {
    _showInfoDialog(
      title: 'Uploaded photos',
      message:
          'Photos added to your wardrobe are intended to help STYLEMIND AI organize clothing and create outfit recommendations. You can remove them when they are no longer needed.',
    );
  }

  void _showWardrobeInfo() {
    _showInfoDialog(
      title: 'Wardrobe data',
      message:
          'Your saved clothing items contain information such as category, color, style, and other details needed for outfit recommendations.',
    );
  }

  void _showOutfitInfo() {
    _showInfoDialog(
      title: 'Outfit data',
      message:
          'Generated outfits can be saved so you can view favorites, history, and calendar plans later.',
    );
  }

  void _showInfoDialog({
    required String title,
    required String message,
  }) {
    showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: Text(title),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(dialogContext);
              },
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }
}