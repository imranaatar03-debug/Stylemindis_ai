import 'package:flutter/material.dart';

import '../../../core/constants/colors.dart';
import '../../../core/constants/strings.dart';
import '../../../core/widgets/app_card.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _darkMode = false;
  bool _notifications = true;
  bool _dailyOutfitReminder = true;
  bool _weatherSuggestions = true;
  bool _smartSuggestions = true;
  bool _saveScanHistory = true;

  @override
  void initState() {
    super.initState();

    final brightness =
        WidgetsBinding.instance.platformDispatcher.platformBrightness;

    _darkMode = brightness == Brightness.dark;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: AppBar(
        title: const Text(
          AppStrings.settings,
          style: TextStyle(
            fontWeight: FontWeight.w800,
          ),
        ),
        centerTitle: false,
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(
            20,
            12,
            20,
            32,
          ),
          children: [
            _buildAppearanceSection(theme),
            const SizedBox(height: 18),
            _buildNotificationSection(theme),
            const SizedBox(height: 18),
            _buildAiSection(theme),
            const SizedBox(height: 18),
            _buildDataSection(theme),
            const SizedBox(height: 18),
            _buildAboutSection(theme),
          ],
        ),
      ),
    );
  }

  Widget _buildAppearanceSection(ThemeData theme) {
    return _buildSection(
      theme,
      title: 'Appearance',
      icon: Icons.palette_outlined,
      children: [
        ListTile(
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 10,
            vertical: 2,
          ),
          leading: _buildIconContainer(
            Icons.dark_mode_outlined,
          ),
          title: Text(
            'Dark mode',
            style: theme.textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.w700,
            ),
          ),
          subtitle: Text(
            'Use a darker interface for comfortable viewing.',
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.textTheme.bodySmall?.color
                  ?.withOpacity(0.55),
            ),
          ),
          trailing: Switch.adaptive(
            value: _darkMode,
            onChanged: (value) {
              setState(() {
                _darkMode = value;
              });

              _showThemeMessage(value);
            },
          ),
        ),
        ListTile(
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 10,
            vertical: 2,
          ),
          leading: _buildIconContainer(
            Icons.language_outlined,
          ),
          title: Text(
            'Language',
            style: theme.textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.w700,
            ),
          ),
          subtitle: Text(
            'English',
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.textTheme.bodySmall?.color
                  ?.withOpacity(0.55),
            ),
          ),
          trailing: const Icon(
            Icons.chevron_right_rounded,
          ),
          onTap: _showLanguageDialog,
        ),
      ],
    );
  }

  Widget _buildNotificationSection(ThemeData theme) {
    return _buildSection(
      theme,
      title: 'Notifications',
      icon: Icons.notifications_none_rounded,
      children: [
        _buildSwitchTile(
          theme,
          icon: Icons.notifications_active_outlined,
          title: 'Notifications',
          subtitle: 'Receive useful style reminders and updates.',
          value: _notifications,
          onChanged: (value) {
            setState(() {
              _notifications = value;

              if (!value) {
                _dailyOutfitReminder = false;
                _weatherSuggestions = false;
              }
            });
          },
        ),
        _buildSwitchTile(
          theme,
          icon: Icons.checkroom_outlined,
          title: 'Daily outfit reminder',
          subtitle: 'Get a reminder to plan your look.',
          value: _dailyOutfitReminder,
          enabled: _notifications,
          onChanged: (value) {
            setState(() {
              _dailyOutfitReminder = value;
            });
          },
        ),
        _buildSwitchTile(
          theme,
          icon: Icons.cloud_outlined,
          title: 'Weather suggestions',
          subtitle: 'Receive outfit suggestions based on weather.',
          value: _weatherSuggestions,
          enabled: _notifications,
          onChanged: (value) {
            setState(() {
              _weatherSuggestions = value;
            });
          },
        ),
      ],
    );
  }

  Widget _buildAiSection(ThemeData theme) {
    return _buildSection(
      theme,
      title: 'AI preferences',
      icon: Icons.auto_awesome_rounded,
      children: [
        _buildSwitchTile(
          theme,
          icon: Icons.lightbulb_outline_rounded,
          title: 'Smart suggestions',
          subtitle:
              'Let STYLEMIND AI personalize recommendations using your wardrobe.',
          value: _smartSuggestions,
          onChanged: (value) {
            setState(() {
              _smartSuggestions = value;
            });
          },
        ),
        _buildSwitchTile(
          theme,
          icon: Icons.history_rounded,
          title: 'Save scan history',
          subtitle:
              'Keep previous AI Style Scan results available in the app.',
          value: _saveScanHistory,
          onChanged: (value) {
            setState(() {
              _saveScanHistory = value;
            });
          },
        ),
      ],
    );
  }

  Widget _buildDataSection(ThemeData theme) {
    return _buildSection(
      theme,
      title: 'Data & privacy',
      icon: Icons.shield_outlined,
      children: [
        _buildActionTile(
          theme,
          icon: Icons.lock_outline_rounded,
          title: AppStrings.privacy,
          subtitle: 'Permissions, privacy and saved data.',
          onTap: () {
            Navigator.pushNamed(
              context,
              '/privacy',
            );
          },
        ),
        _buildActionTile(
          theme,
          icon: Icons.delete_outline_rounded,
          title: 'Clear local data',
          subtitle:
              'Remove locally saved preferences and temporary data.',
          isDestructive: true,
          onTap: _confirmClearData,
        ),
      ],
    );
  }

  Widget _buildAboutSection(ThemeData theme) {
    return _buildSection(
      theme,
      title: 'About',
      icon: Icons.info_outline_rounded,
      children: [
        _buildActionTile(
          theme,
          icon: Icons.auto_awesome_rounded,
          title: AppStrings.appName,
          subtitle: 'Your Wardrobe. Your Style. Powered by AI.',
          onTap: _showAboutDialog,
        ),
        _buildActionTile(
          theme,
          icon: Icons.description_outlined,
          title: 'Terms & guidelines',
          subtitle: 'Learn how the app features work.',
          onTap: _showTermsDialog,
        ),
      ],
    );
  }

  Widget _buildSection(
    ThemeData theme, {
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return AppCard(
      padding: const EdgeInsets.fromLTRB(
        8,
        10,
        8,
        8,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(
              10,
              2,
              10,
              8,
            ),
            child: Row(
              children: [
                Icon(
                  icon,
                  size: 19,
                  color: AppColors.primary,
                ),
                const SizedBox(width: 8),
                Text(
                  title,
                  style: theme.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
          ...children,
        ],
      ),
    );
  }

  Widget _buildSwitchTile(
    ThemeData theme, {
    required IconData icon,
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
    bool enabled = true,
  }) {
    final color = enabled
        ? AppColors.primary
        : theme.disabledColor;

    return ListTile(
      enabled: enabled,
      contentPadding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 2,
      ),
      leading: Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(
          color: color.withOpacity(0.10),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Icon(
          icon,
          color: color,
          size: 21,
        ),
      ),
      title: Text(
        title,
        style: theme.textTheme.bodyMedium?.copyWith(
          fontWeight: FontWeight.w700,
        ),
      ),
      subtitle: Text(
        subtitle,
        style: theme.textTheme.bodySmall?.copyWith(
          height: 1.3,
          color: theme.textTheme.bodySmall?.color
              ?.withOpacity(0.55),
        ),
      ),
      trailing: Switch.adaptive(
        value: value,
        onChanged: enabled ? onChanged : null,
      ),
    );
  }

  Widget _buildActionTile(
    ThemeData theme, {
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
    bool isDestructive = false,
  }) {
    final color =
        isDestructive ? AppColors.error : AppColors.primary;

    return ListTile(
      contentPadding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 2,
      ),
      leading: Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(
          color: color.withOpacity(0.10),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Icon(
          icon,
          color: color,
          size: 21,
        ),
      ),
      title: Text(
        title,
        style: theme.textTheme.bodyMedium?.copyWith(
          fontWeight: FontWeight.w700,
          color: isDestructive
              ? AppColors.error
              : theme.textTheme.bodyMedium?.color,
        ),
      ),
      subtitle: Text(
        subtitle,
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        style: theme.textTheme.bodySmall?.copyWith(
          color: theme.textTheme.bodySmall?.color
              ?.withOpacity(0.55),
        ),
      ),
      trailing: const Icon(
        Icons.chevron_right_rounded,
      ),
      onTap: onTap,
    );
  }

  Widget _buildIconContainer(IconData icon) {
    return Container(
      width: 42,
      height: 42,
      decoration: BoxDecoration(
        color: AppColors.primary.withOpacity(0.10),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Icon(
        icon,
        color: AppColors.primary,
        size: 21,
      ),
    );
  }

  void _showThemeMessage(bool darkMode) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          darkMode
              ? 'Dark mode selected.'
              : 'Light mode selected.',
        ),
      ),
    );
  }

  Future<void> _showLanguageDialog() async {
    await showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text(
            'Language',
          ),
          content: const Text(
            'Language selection will be available in a future version.',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(dialogContext);
              },
              child: const Text(
                'OK',
              ),
            ),
          ],
        );
      },
    );
  }

  Future<void> _confirmClearData() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text(
            'Clear local data?',
          ),
          content: const Text(
            'This removes locally saved temporary preferences. Your account itself will not be deleted.',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(
                  dialogContext,
                  false,
                );
              },
              child: const Text(
                'Cancel',
              ),
            ),
            FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: AppColors.error,
              ),
              onPressed: () {
                Navigator.pop(
                  dialogContext,
                  true,
                );
              },
              child: const Text(
                'Clear',
              ),
            ),
          ],
        );
      },
    );

    if (confirmed != true || !mounted) {
      return;
    }

    setState(() {
      _smartSuggestions = true;
      _saveScanHistory = true;
      _dailyOutfitReminder = _notifications;
      _weatherSuggestions = _notifications;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'Local settings have been reset.',
        ),
      ),
    );
  }

  Future<void> _showAboutDialog() async {
    await showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          icon: const Icon(
            Icons.auto_awesome_rounded,
            color: AppColors.primary,
            size: 34,
          ),
          title: const Text(
            'STYLEMIND AI',
          ),
          content: const Text(
            'Your Wardrobe. Your Style. Powered by AI.\n\nA smart fashion assistant designed to help you organize your wardrobe and discover outfit combinations.',
            textAlign: TextAlign.center,
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(dialogContext);
              },
              child: const Text(
                'Close',
              ),
            ),
          ],
        );
      },
    );
  }

  Future<void> _showTermsDialog() async {
    await showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text(
            'Terms & guidelines',
          ),
          content: const SingleChildScrollView(
            child: Text(
              'STYLEMIND AI provides fashion recommendations for convenience and inspiration. AI suggestions may not always be perfect.\n\nAI-generated visualizations are illustrative and should not be treated as an exact representation of how clothing will look on a person.\n\nUse only photos and information that you have the right to upload.',
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(dialogContext);
              },
              child: const Text(
                'OK',
              ),
            ),
          ],
        );
      },
    );
  }
}