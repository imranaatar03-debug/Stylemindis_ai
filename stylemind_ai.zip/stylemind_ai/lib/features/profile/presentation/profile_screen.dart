import 'package:flutter/material.dart';

import '../../../core/constants/colors.dart';
import '../../../core/constants/strings.dart';
import '../../../core/widgets/app_card.dart';
import '../../../models/user_model.dart';
import '../controller/profile_controller.dart';
import 'privacy_screen.dart';
import 'settings_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late final ProfileController _controller;

  @override
  void initState() {
    super.initState();
    _controller = ProfileController();
    _controller.initialize();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        return Scaffold(
          backgroundColor: theme.scaffoldBackgroundColor,
          appBar: AppBar(
            title: const Text(
              AppStrings.profile,
              style: TextStyle(
                fontWeight: FontWeight.w800,
              ),
            ),
            centerTitle: false,
            actions: [
              IconButton(
                onPressed: _openSettings,
                icon: const Icon(
                  Icons.settings_outlined,
                ),
                tooltip: AppStrings.settings,
              ),
            ],
          ),
          body: SafeArea(
            child: RefreshIndicator(
              onRefresh: _refresh,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(
                  20,
                  12,
                  20,
                  32,
                ),
                children: [
                  _buildProfileHeader(theme),
                  const SizedBox(height: 18),
                  _buildStats(theme),
                  const SizedBox(height: 18),
                  _buildStyleSection(theme),
                  const SizedBox(height: 18),
                  _buildAccountSection(theme),
                  const SizedBox(height: 18),
                  _buildPrivacySection(theme),
                  const SizedBox(height: 24),
                  _buildAppInfo(theme),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildProfileHeader(ThemeData theme) {
    final user = _controller.user;

    return AppCard(
      child: Row(
        children: [
          Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [
                  AppColors.primary,
                  AppColors.secondary,
                ],
              ),
              boxShadow: [
                BoxShadow(
                  color: AppColors.primary.withOpacity(0.25),
                  blurRadius: 18,
                  offset: const Offset(0, 7),
                ),
              ],
            ),
            child: const Icon(
              Icons.person_rounded,
              size: 38,
              color: Colors.white,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _displayName(user),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  user?.email ?? 'Your personal style profile',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.textTheme.bodySmall?.color
                        ?.withOpacity(0.60),
                  ),
                ),
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 6,
                  ),
                  decoration: BoxDecoration(
                    color: AppColors.primary.withOpacity(0.10),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.auto_awesome_rounded,
                        size: 14,
                        color: AppColors.primary,
                      ),
                      SizedBox(width: 5),
                      Text(
                        'STYLEMIND AI',
                        style: TextStyle(
                          color: AppColors.primary,
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: _editProfile,
            icon: const Icon(
              Icons.edit_outlined,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStats(ThemeData theme) {
    return Row(
      children: [
        Expanded(
          child: _buildStatCard(
            theme,
            Icons.checkroom_rounded,
            'Wardrobe',
            '${_controller.wardrobeCount}',
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _buildStatCard(
            theme,
            Icons.auto_awesome_rounded,
            'Outfits',
            '${_controller.outfitCount}',
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _buildStatCard(
            theme,
            Icons.favorite_rounded,
            'Favorites',
            '${_controller.favoriteCount}',
          ),
        ),
      ],
    );
  }

  Widget _buildStatCard(
    ThemeData theme,
    IconData icon,
    String label,
    String value,
  ) {
    return AppCard(
      padding: const EdgeInsets.symmetric(
        horizontal: 8,
        vertical: 14,
      ),
      child: Column(
        children: [
          Icon(
            icon,
            size: 22,
            color: AppColors.primary,
          ),
          const SizedBox(height: 8),
          Text(
            value,
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: theme.textTheme.labelSmall?.copyWith(
              color: theme.textTheme.labelSmall?.color
                  ?.withOpacity(0.60),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStyleSection(ThemeData theme) {
    return _buildSection(
      theme,
      title: 'My style',
      icon: Icons.style_rounded,
      children: [
        _buildMenuTile(
          theme,
          icon: Icons.person_outline_rounded,
          title: 'Style profile',
          subtitle: 'Update your fashion preferences',
          onTap: _openStyleProfile,
        ),
        _buildMenuTile(
          theme,
          icon: Icons.palette_outlined,
          title: 'Color preferences',
          subtitle: 'Choose colors you enjoy wearing',
          onTap: _openColorPreferences,
        ),
      ],
    );
  }

  Widget _buildAccountSection(ThemeData theme) {
    return _buildSection(
      theme,
      title: 'Account',
      icon: Icons.account_circle_outlined,
      children: [
        _buildMenuTile(
          theme,
          icon: Icons.settings_outlined,
          title: AppStrings.settings,
          subtitle: 'App preferences and appearance',
          onTap: _openSettings,
        ),
        _buildMenuTile(
          theme,
          icon: Icons.notifications_none_rounded,
          title: 'Notifications',
          subtitle: 'Manage style reminders',
          trailing: Switch.adaptive(
            value: _controller.notificationsEnabled,
            onChanged: _controller.setNotificationsEnabled,
          ),
        ),
      ],
    );
  }

  Widget _buildPrivacySection(ThemeData theme) {
    return _buildSection(
      theme,
      title: 'Privacy & data',
      icon: Icons.shield_outlined,
      children: [
        _buildMenuTile(
          theme,
          icon: Icons.lock_outline_rounded,
          title: AppStrings.privacy,
          subtitle: 'Control your data and permissions',
          onTap: _openPrivacy,
        ),
        _buildMenuTile(
          theme,
          icon: Icons.delete_outline_rounded,
          title: 'Delete my data',
          subtitle: 'Remove stored wardrobe and profile data',
          isDestructive: true,
          onTap: _confirmDeleteData,
        ),
      ],
    );
  }

  Widget _buildSection(
    ThemeData theme, {
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return AppCard(
      padding: const EdgeInsets.fromLTRB(
        8,
        10,
        8,
        8,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(
              10,
              2,
              10,
              8,
            ),
            child: Row(
              children: [
                Icon(
                  icon,
                  size: 19,
                  color: AppColors.primary,
                ),
                const SizedBox(width: 8),
                Text(
                  title,
                  style: theme.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
          ...children,
        ],
      ),
    );
  }

  Widget _buildMenuTile(
    ThemeData theme, {
    required IconData icon,
    required String title,
    String? subtitle,
    VoidCallback? onTap,
    Widget? trailing,
    bool isDestructive = false,
  }) {
    final iconColor =
        isDestructive ? AppColors.error : AppColors.primary;

    return ListTile(
      contentPadding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 2,
      ),
      leading: Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(
          color: iconColor.withOpacity(0.10),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Icon(
          icon,
          color: iconColor,
          size: 21,
        ),
      ),
      title: Text(
        title,
        style: theme.textTheme.bodyMedium?.copyWith(
          fontWeight: FontWeight.w700,
          color: isDestructive
              ? AppColors.error
              : theme.textTheme.bodyMedium?.color,
        ),
      ),
      subtitle: subtitle == null
          ? null
          : Text(
              subtitle,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: theme.textTheme.bodySmall?.copyWith(
                color: theme.textTheme.bodySmall?.color
                    ?.withOpacity(0.55),
              ),
            ),
      trailing: trailing ??
          (onTap == null
              ? null
              : const Icon(
                  Icons.chevron_right_rounded,
                  size: 22,
                )),
      onTap: onTap,
    );
  }

  Widget _buildAppInfo(ThemeData theme) {
    return Column(
      children: [
        const Icon(
          Icons.auto_awesome_rounded,
          size: 28,
          color: AppColors.primary,
        ),
        const SizedBox(height: 8),
        Text(
          AppStrings.appName,
          style: theme.textTheme.titleSmall?.copyWith(
            fontWeight: FontWeight.w900,
            letterSpacing: 0.5,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          'Your Wardrobe. Your Style. Powered by AI.',
          textAlign: TextAlign.center,
          style: theme.textTheme.bodySmall?.copyWith(
            color: theme.textTheme.bodySmall?.color
                ?.withOpacity(0.55),
          ),
        ),
        const SizedBox(height: 6),
        Text(
          'Version 1.0.0',
          style: theme.textTheme.labelSmall?.copyWith(
            color: theme.textTheme.labelSmall?.color
                ?.withOpacity(0.45),
          ),
        ),
      ],
    );
  }

  String _displayName(UserModel? user) {
    if (user == null) {
      return 'Style Explorer';
    }

    if (user.name.trim().isNotEmpty) {
      return user.name;
    }

    return 'Style Explorer';
  }

  Future<void> _refresh() async {
    await _controller.refresh();
  }

  void _editProfile() {
    _openStyleProfile();
  }

  void _openStyleProfile() {
    Navigator.pushNamed(
      context,
      '/style-profile',
    );
  }

  void _openColorPreferences() {
    Navigator.pushNamed(
      context,
      '/color-preferences',
    );
  }

  void _openSettings() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const SettingsScreen(),
      ),
    );
  }

  void _openPrivacy() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const PrivacyScreen(),
      ),
    );
  }

  Future<void> _confirmDeleteData() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text(
            'Delete your data?',
          ),
          content: const Text(
            'This will remove your saved wardrobe, outfits, and profile data from this app. This action cannot be undone.',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(
                  dialogContext,
                  false,
                );
              },
              child: const Text(
                'Cancel',
              ),
            ),
            FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: AppColors.error,
              ),
              onPressed: () {
                Navigator.pop(
                  dialogContext,
                  true,
                );
              },
              child: const Text(
                'Delete',
              ),
            ),
          ],
        );
      },
    );

    if (confirmed != true || !mounted) {
      return;
    }

    await _controller.deleteAllData();

    if (!mounted) {
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'Your app data has been deleted.',
        ),
      ),
    );
  }
}