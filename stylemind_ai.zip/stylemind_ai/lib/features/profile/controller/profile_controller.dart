import 'package:flutter/foundation.dart';

import '../../../core/constants/app_constants.dart';
import '../../../core/services/storage_service.dart';
import '../../../models/outfit_model.dart';
import '../../../models/user_model.dart';

class ProfileController extends ChangeNotifier {
  final StorageService _storageService;

  ProfileController({
    StorageService? storageService,
  }) : _storageService =
            storageService ?? StorageService();

  UserModel? _user;

  int _wardrobeCount = 0;
  int _outfitCount = 0;
  int _favoriteCount = 0;

  bool _notificationsEnabled = true;
  bool _isLoading = false;

  UserModel? get user => _user;

  int get wardrobeCount => _wardrobeCount;

  int get outfitCount => _outfitCount;

  int get favoriteCount => _favoriteCount;

  bool get notificationsEnabled =>
      _notificationsEnabled;

  bool get isLoading => _isLoading;

  Future<void> initialize() async {
    await refresh();
  }

  Future<void> refresh() async {
    _setLoading(true);

    try {
      await _loadUser();
      await _loadStatistics();
      await _loadNotificationPreference();
    } finally {
      _setLoading(false);
    }
  }

  Future<void> _loadUser() async {
    try {
      final data = await _storageService.getJson(
        'user_profile',
      );

      if (data != null) {
        _user = UserModel.fromJson(data);
      }
    } catch (_) {
      _user = null;
    }
  }

  Future<void> _loadStatistics() async {
    try {
      final wardrobe =
          await _storageService.getJsonList(
        AppConstants.wardrobeKey,
      );

      final outfits =
          await _storageService.getJsonList(
        'saved_outfits',
      );

      _wardrobeCount = wardrobe.length;
      _outfitCount = outfits.length;

      _favoriteCount = 0;

      for (final item in outfits) {
        try {
          final outfit = OutfitModel.fromJson(item);

          if (outfit.isFavorite) {
            _favoriteCount++;
          }
        } catch (_) {
          // Ignore invalid saved outfit data.
        }
      }
    } catch (_) {
      _wardrobeCount = 0;
      _outfitCount = 0;
      _favoriteCount = 0;
    }
  }

  Future<void> _loadNotificationPreference() async {
    try {
      final value =
          await _storageService.getBool(
        'notifications_enabled',
      );

      _notificationsEnabled = value ?? true;
    } catch (_) {
      _notificationsEnabled = true;
    }
  }

  Future<void> setNotificationsEnabled(
    bool value,
  ) async {
    _notificationsEnabled = value;

    notifyListeners();

    try {
      await _storageService.setBool(
        'notifications_enabled',
        value,
      );
    } catch (_) {
      // Keep the UI responsive even if storage fails.
    }
  }

  Future<void> updateUser(UserModel user) async {
    _user = user;

    notifyListeners();

    try {
      await _storageService.setJson(
        'user_profile',
        user.toJson(),
      );
    } catch (_) {
      // The in-memory profile remains available.
    }
  }

  Future<void> deleteAllData() async {
    _setLoading(true);

    try {
      await _storageService.remove(
        'user_profile',
      );

      await _storageService.remove(
        AppConstants.wardrobeKey,
      );

      await _storageService.remove(
        'saved_outfits',
      );

      await _storageService.remove(
        'outfit_history',
      );

      _user = null;
      _wardrobeCount = 0;
      _outfitCount = 0;
      _favoriteCount = 0;
    } finally {
      _setLoading(false);
    }
  }

  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }
}