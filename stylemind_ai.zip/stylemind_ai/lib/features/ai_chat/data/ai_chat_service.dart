import '../../../models/clothing_item_model.dart';
import '../../../models/outfit_model.dart';

class AiChatService {
  const AiChatService();

  Future<String> sendMessage({
    required String message,
    List<ClothingItemModel> wardrobe = const [],
    List<OutfitModel> outfits = const [],
  }) async {
    await Future.delayed(const Duration(milliseconds: 700));

    final text = message.trim().toLowerCase();

    if (text.isEmpty) {
      return 'Tell me what you would like help with.';
    }

    if (_containsAny(text, [
      'hello',
      'hi',
      'hey',
      'مرحبا',
      'سلام',
    ])) {
      return 'Hi! I’m STYLEMIND AI. I can help you choose outfits, match colors, and make better use of your wardrobe.';
    }

    if (_containsAny(text, [
      'wardrobe',
      'clothes',
      'clothing',
      'ملابس',
      'خزانة',
    ])) {
      if (wardrobe.isEmpty) {
        return 'Your wardrobe is currently empty. Add a few clothing items and I can start creating recommendations for you.';
      }

      return 'You currently have ${wardrobe.length} item${wardrobe.length == 1 ? '' : 's'} in your wardrobe. I can help you combine them into outfits.';
    }

    if (_containsAny(text, [
      'outfit',
      'wear',
      'look',
      'لبس',
      'ملابس ألبس',
      'تنسيق',
    ])) {
      if (wardrobe.isEmpty) {
        return 'Add some clothes to your wardrobe first, then I can suggest outfits based on what you already own.';
      }

      return 'Absolutely. Tell me the occasion and style you want, and I’ll help you build an outfit from your wardrobe.';
    }

    if (_containsAny(text, [
      'color',
      'colour',
      'لون',
      'ألوان',
    ])) {
      return 'For an easy combination, start with neutral colors such as black, white, grey, beige, or navy, then add one stronger color as an accent.';
    }

    if (_containsAny(text, [
      'school',
      'مدرسة',
    ])) {
      return 'For school, try a comfortable and simple combination: a clean top, well-matched trousers or jeans, and simple sneakers.';
    }

    if (_containsAny(text, [
      'casual',
      'كاجوال',
    ])) {
      return 'For a casual look, combine comfortable basics with clean colors and one subtle statement piece.';
    }

    if (_containsAny(text, [
      'streetwear',
      'ستريت',
    ])) {
      return 'For streetwear, try relaxed pieces, layered tops, sneakers, and a simple accessory while keeping the colors coordinated.';
    }

    if (_containsAny(text, [
      'favorite',
      'favorites',
      'مفضلة',
      'المفضلة',
    ])) {
      final favoriteCount =
          wardrobe.where((item) => item.isFavorite).length;

      if (favoriteCount == 0) {
        return 'You don’t have any favorite clothing items yet.';
      }

      return 'You have $favoriteCount favorite clothing item${favoriteCount == 1 ? '' : 's'} in your wardrobe.';
    }

    if (_containsAny(text, [
      'history',
      'previous',
      'سابق',
      'التاريخ',
    ])) {
      if (outfits.isEmpty) {
        return 'You don’t have any saved outfits yet.';
      }

      return 'You have ${outfits.length} saved outfit${outfits.length == 1 ? '' : 's'} in your outfit history.';
    }

    if (_containsAny(text, [
      'help',
      'مساعدة',
      'ساعدني',
    ])) {
      return 'I can help you with outfit ideas, color combinations, wardrobe items, occasions, styles, and matching clothes.';
    }

    return 'I understand. Tell me the occasion, style, or clothing item you are thinking about, and I’ll help you create a better combination.';
  }

  bool _containsAny(
    String text,
    List<String> keywords,
  ) {
    return keywords.any(text.contains);
  }
}