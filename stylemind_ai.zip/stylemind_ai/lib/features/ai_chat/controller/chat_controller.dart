import 'package:flutter/foundation.dart';

import '../../../models/clothing_item_model.dart';
import '../../../models/outfit_model.dart';
import '../data/ai_chat_service.dart';

class ChatMessage {
  final String id;
  final String text;
  final bool isUser;
  final DateTime timestamp;

  const ChatMessage({
    required this.id,
    required this.text,
    required this.isUser,
    required this.timestamp,
  });
}

class ChatController extends ChangeNotifier {
  final AiChatService _chatService;

  ChatController({
    AiChatService? chatService,
  }) : _chatService = chatService ?? const AiChatService();

  final List<ChatMessage> _messages = [];

  bool _isLoading = false;
  String? _error;

  List<ClothingItemModel> _wardrobe = [];
  List<OutfitModel> _outfits = [];

  List<ChatMessage> get messages => List.unmodifiable(_messages);

  bool get isLoading => _isLoading;

  String? get error => _error;

  bool get hasMessages => _messages.isNotEmpty;

  void initialize({
    List<ClothingItemModel> wardrobe = const [],
    List<OutfitModel> outfits = const [],
  }) {
    _wardrobe = List<ClothingItemModel>.from(wardrobe);
    _outfits = List<OutfitModel>.from(outfits);

    if (_messages.isEmpty) {
      _addAssistantMessage(
        'Hi! I’m STYLEMIND AI. Ask me about your wardrobe, outfits, colors, or what to wear.',
      );
    }
  }

  void updateWardrobe(List<ClothingItemModel> wardrobe) {
    _wardrobe = List<ClothingItemModel>.from(wardrobe);
    notifyListeners();
  }

  void updateOutfits(List<OutfitModel> outfits) {
    _outfits = List<OutfitModel>.from(outfits);
    notifyListeners();
  }

  Future<void> sendMessage(String message) async {
    final text = message.trim();

    if (text.isEmpty || _isLoading) return;

    _error = null;

    _addUserMessage(text);

    _setLoading(true);

    try {
      final response = await _chatService.sendMessage(
        message: text,
        wardrobe: _wardrobe,
        outfits: _outfits,
      );

      _addAssistantMessage(response);
    } catch (e) {
      _error = 'Unable to get a response. Please try again.';

      _addAssistantMessage(
        'Sorry, I could not process that right now. Please try again.',
      );
    } finally {
      _setLoading(false);
    }
  }

  Future<void> sendSuggestion(String suggestion) async {
    await sendMessage(suggestion);
  }

  void clearChat() {
    _messages.clear();
    _error = null;

    _addAssistantMessage(
      'Chat cleared. How can I help you with your style?',
    );
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }

  void _addUserMessage(String text) {
    _messages.add(
      ChatMessage(
        id: _createId(),
        text: text,
        isUser: true,
        timestamp: DateTime.now(),
      ),
    );

    notifyListeners();
  }

  void _addAssistantMessage(String text) {
    _messages.add(
      ChatMessage(
        id: _createId(),
        text: text,
        isUser: false,
        timestamp: DateTime.now(),
      ),
    );

    notifyListeners();
  }

  String _createId() {
    return DateTime.now().microsecondsSinceEpoch.toString();
  }

  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }
}