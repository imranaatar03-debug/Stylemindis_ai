import 'package:flutter/foundation.dart';

import '../../../models/clothing_item_model.dart';
import '../data/wardrobe_repository.dart';

class WardrobeController extends ChangeNotifier {
  final WardrobeRepository _repository;

  WardrobeController({
    WardrobeRepository? repository,
  }) : _repository = repository ?? WardrobeRepository();

  bool _isLoading = false;
  String? _error;
  String? _selectedCategory;
  String _searchQuery = '';
  List<ClothingItemModel> _items = [];

  bool get isLoading => _isLoading;
  String? get error => _error;
  String? get selectedCategory => _selectedCategory;
  String get searchQuery => _searchQuery;
  List<ClothingItemModel> get items => List.unmodifiable(_items);

  List<ClothingItemModel> get filteredItems {
    Iterable<ClothingItemModel> result = _items;

    if (_selectedCategory != null &&
        _selectedCategory!.isNotEmpty) {
      result = result.where(
        (item) =>
            item.category.toLowerCase() ==
            _selectedCategory!.toLowerCase(),
      );
    }

    if (_searchQuery.trim().isNotEmpty) {
      final query = _searchQuery.trim().toLowerCase();

      result = result.where(
        (item) =>
            item.name.toLowerCase().contains(query) ||
            item.category.toLowerCase().contains(query) ||
            item.color.toLowerCase().contains(query) ||
            (item.brand?.toLowerCase().contains(query) ?? false),
      );
    }

    return result.toList();
  }

  Future<void> initialize() async {
    await loadItems();
  }

  Future<void> loadItems() async {
    _setLoading(true);
    _error = null;

    try {
      _items = await _repository.getWardrobeItems();
    } catch (e) {
      _error = 'Unable to load wardrobe items.';
    } finally {
      _setLoading(false);
    }
  }

  void setCategory(String? category) {
    if (category == null ||
        category.trim().isEmpty ||
        category.toLowerCase() == 'all') {
      _selectedCategory = null;
    } else {
      _selectedCategory = category;
    }

    notifyListeners();
  }

  void search(String query) {
    _searchQuery = query;
    notifyListeners();
  }

  Future<bool> addItem(ClothingItemModel item) async {
    try {
      await _repository.addItem(item);

      _items = [..._items, item];
      notifyListeners();

      return true;
    } catch (e) {
      _error = 'Unable to add this item.';
      notifyListeners();
      return false;
    }
  }

  Future<bool> updateItem(ClothingItemModel item) async {
    try {
      await _repository.updateItem(item);

      final index = _items.indexWhere(
        (existing) => existing.id == item.id,
      );

      if (index != -1) {
        final updatedItems = [..._items];
        updatedItems[index] = item;
        _items = updatedItems;
        notifyListeners();
      }

      return true;
    } catch (e) {
      _error = 'Unable to update this item.';
      notifyListeners();
      return false;
    }
  }

  Future<bool> toggleFavorite(String id) async {
    final index = _items.indexWhere(
      (item) => item.id == id,
    );

    if (index == -1) {
      return false;
    }

    try {
      final item = _items[index];

      await _repository.toggleFavorite(id);

      final updatedItem = item.copyWith(
        isFavorite: !item.isFavorite,
      );

      final updatedItems = [..._items];
      updatedItems[index] = updatedItem;
      _items = updatedItems;

      notifyListeners();

      return true;
    } catch (e) {
      _error = 'Unable to update favorite status.';
      notifyListeners();
      return false;
    }
  }

  Future<bool> deleteItem(String id) async {
    try {
      await _repository.deleteItem(id);

      _items = _items
          .where((item) => item.id != id)
          .toList();

      notifyListeners();

      return true;
    } catch (e) {
      _error = 'Unable to delete this item.';
      notifyListeners();
      return false;
    }
  }

  ClothingItemModel? getItemById(String id) {
    try {
      return _items.firstWhere(
        (item) => item.id == id,
      );
    } catch (_) {
      return null;
    }
  }

  void clearFilters() {
    _selectedCategory = null;
    _searchQuery = '';
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }

  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }
}