import 'package:flutter/material.dart';

import '../../../core/constants/app_constants.dart';
import '../../../core/constants/colors.dart';
import '../../../core/widgets/app_button.dart';
import '../../../core/widgets/app_card.dart';
import '../../../models/clothing_item_model.dart';
import '../data/wardrobe_repository.dart';

class ClothingDetailsScreen extends StatefulWidget {
  final String itemId;

  const ClothingDetailsScreen({
    super.key,
    required this.itemId,
  });

  @override
  State<ClothingDetailsScreen> createState() =>
      _ClothingDetailsScreenState();
}

class _ClothingDetailsScreenState
    extends State<ClothingDetailsScreen> {
  final WardrobeRepository _repository = WardrobeRepository();

  ClothingItemModel? _item;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadItem();
  }

  Future<void> _loadItem() async {
    final item = await _repository.getItemById(widget.itemId);

    if (!mounted) return;

    setState(() {
      _item = item;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    if (_item == null) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Clothing Details'),
        ),
        body: const Center(
          child: Text('Clothing item not found.'),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Clothing Details'),
        actions: [
          IconButton(
            onPressed: _toggleFavorite,
            icon: Icon(
              _item!.isFavorite
                  ? Icons.favorite_rounded
                  : Icons.favorite_border_rounded,
              color: _item!.isFavorite
                  ? AppColors.accent
                  : null,
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.all(
            AppConstants.screenPadding,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildImage(context),
              const SizedBox(height: 24),
              _buildTitle(context),
              const SizedBox(height: 20),
              _buildDetails(context),
              const SizedBox(height: 20),
              _buildAiInfo(context),
              const SizedBox(height: 28),
              _buildActions(context),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildImage(BuildContext context) {
    return Container(
      width: double.infinity,
      height: 330,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(
          AppConstants.largeBorderRadius,
        ),
        color: AppColors.lightCard,
        border: Border.all(
          color: AppColors.lightBorder,
        ),
      ),
      child: _item!.imagePath.isNotEmpty
          ? ClipRRect(
              borderRadius: BorderRadius.circular(
                AppConstants.largeBorderRadius,
              ),
              child: Image.file(
                // The actual file path is used when the image
                // exists locally on the device.
                __fileFromPath(_item!.imagePath),
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) {
                  return _imagePlaceholder();
                },
              ),
            )
          : _imagePlaceholder(),
    );
  }

  Widget _imagePlaceholder() {
    return const Center(
      child: Icon(
        Icons.checkroom_rounded,
        size: 80,
        color: AppColors.primary,
      ),
    );
  }

  Widget _buildTitle(BuildContext context) {
    final theme = Theme.of(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          _item!.name,
          style: theme.textTheme.headlineSmall?.copyWith(
            fontWeight: FontWeight.w800,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          _item!.category,
          style: theme.textTheme.bodyMedium?.copyWith(
            color: AppColors.primary,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }

  Widget _buildDetails(BuildContext context) {
    return AppCard(
      padding: const EdgeInsets.all(18),
      borderRadius: 22,
      child: Column(
        children: [
          _detailRow(
            context,
            Icons.palette_outlined,
            'Color',
            _item!.color,
          ),
          _divider(),
          _detailRow(
            context,
            Icons.category_outlined,
            'Category',
            _item!.category,
          ),
          _divider(),
          _detailRow(
            context,
            Icons.label_outline_rounded,
            'Brand',
            _item!.brand.isEmpty ? 'Not specified' : _item!.brand,
          ),
          _divider(),
          _detailRow(
            context,
            Icons.texture_rounded,
            'Material',
            _item!.material.isEmpty
                ? 'Not specified'
                : _item!.material,
          ),
          _divider(),
          _detailRow(
            context,
            Icons.straighten_rounded,
            'Size',
            _item!.size.isEmpty ? 'Not specified' : _item!.size,
          ),
        ],
      ),
    );
  }

  Widget _detailRow(
    BuildContext context,
    IconData icon,
    String title,
    String value,
  ) {
    final theme = Theme.of(context);

    return Row(
      children: [
        Container(
          width: 38,
          height: 38,
          decoration: BoxDecoration(
            color: AppColors.primary.withOpacity(0.10),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            icon,
            size: 19,
            color: AppColors.primary,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            title,
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onSurface.withOpacity(0.6),
            ),
          ),
        ),
        Flexible(
          child: Text(
            value,
            textAlign: TextAlign.end,
            style: theme.textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ],
    );
  }

  Widget _divider() {
    return const Padding(
      padding: EdgeInsets.symmetric(vertical: 14),
      child: Divider(height: 1),
    );
  }

  Widget _buildAiInfo(BuildContext context) {
    return AppCard(
      padding: const EdgeInsets.all(18),
      borderRadius: 22,
      child: Row(
        children: [
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.12),
              borderRadius: BorderRadius.circular(15),
            ),
            child: const Icon(
              Icons.auto_awesome_rounded,
              color: AppColors.primary,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'AI Detection',
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  _item!.aiConfidence > 0
                      ? 'Confidence: ${_item!.aiConfidence}%'
                      : 'Added manually',
                  style: Theme.of(context)
                      .textTheme
                      .bodySmall
                      ?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurface
                            .withOpacity(0.6),
                      ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActions(BuildContext context) {
    return Column(
      children: [
        AppButton(
          text: 'Use in Outfit',
          icon: Icons.auto_awesome_rounded,
          fullWidth: true,
          onPressed: () {
            Navigator.pop(context, _item);
          },
        ),
        const SizedBox(height: 12),
        AppButton(
          text: 'Delete Item',
          icon: Icons.delete_outline_rounded,
          fullWidth: true,
          outlined: true,
          onPressed: _deleteItem,
        ),
      ],
    );
  }

  Future<void> _toggleFavorite() async {
    await _repository.toggleFavorite(widget.itemId);

    await _loadItem();
  }

  Future<void> _deleteItem() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Delete item?'),
          content: Text(
            'Remove "${_item!.name}" from your wardrobe?',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(dialogContext, false);
              },
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () {
                Navigator.pop(dialogContext, true);
              },
              child: const Text('Delete'),
            ),
          ],
        );
      },
    );

    if (confirmed != true) return;

    await _repository.deleteItem(widget.itemId);

    if (!mounted) return;

    Navigator.pop(context);
  }
}