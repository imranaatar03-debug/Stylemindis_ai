import 'package:flutter/material.dart';

import '../../../../core/constants/app_constants.dart';
import '../../../../core/constants/colors.dart';

class WardrobeFilter extends StatelessWidget {
  final String? selectedCategory;
  final ValueChanged<String?> onCategoryChanged;

  const WardrobeFilter({
    super.key,
    this.selectedCategory,
    required this.onCategoryChanged,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    final categories = [
      'All',
      ...AppConstants.clothingCategories,
    ];

    return SizedBox(
      height: 42,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        itemCount: categories.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final category = categories[index];

          final isSelected = category == 'All'
              ? selectedCategory == null ||
                  selectedCategory!.isEmpty
              : selectedCategory == selectedCategoryValue(category);

          return _FilterChip(
            label: _formatCategory(category),
            selected: isSelected,
            onTap: () {
              if (category == 'All') {
                onCategoryChanged(null);
              } else {
                onCategoryChanged(
                  selectedCategoryValue(category),
                );
              }
            },
            theme: theme,
          );
        },
      ),
    );
  }

  String selectedCategoryValue(String category) {
    return category.toLowerCase();
  }

  String _formatCategory(String value) {
    if (value.isEmpty) {
      return 'All';
    }

    return value[0].toUpperCase() + value.substring(1);
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  final ThemeData theme;

  const _FilterChip({
    required this.label,
    required this.selected,
    required this.onTap,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: selected
          ? AppColors.primary
          : theme.colorScheme.surface,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding: const EdgeInsets.symmetric(
            horizontal: 15,
            vertical: 10,
          ),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: selected
                  ? AppColors.primary
                  : theme.colorScheme.onSurface.withOpacity(0.10),
            ),
          ),
          child: Text(
            label,
            style: theme.textTheme.labelMedium?.copyWith(
              color: selected
                  ? Colors.white
                  : theme.colorScheme.onSurface,
              fontWeight:
                  selected ? FontWeight.w700 : FontWeight.w500,
            ),
          ),
        ),
      ),
    );
  }
}