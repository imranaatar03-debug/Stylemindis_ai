import 'package:flutter/material.dart';

import '../../../core/constants/app_constants.dart';
import '../../../core/constants/colors.dart';
import '../../../core/widgets/app_button.dart';
import '../../../core/widgets/app_card.dart';
import '../../../models/clothing_item_model.dart';
import '../data/wardrobe_repository.dart';

class AddClothingScreen extends StatefulWidget {
  const AddClothingScreen({super.key});

  @override
  State<AddClothingScreen> createState() => _AddClothingScreenState();
}

class _AddClothingScreenState extends State<AddClothingScreen> {
  final WardrobeRepository _repository = WardrobeRepository();

  final _formKey = GlobalKey<FormState>();

  final _nameController = TextEditingController();
  final _brandController = TextEditingController();
  final _colorController = TextEditingController();
  final _materialController = TextEditingController();
  final _sizeController = TextEditingController();
  final _notesController = TextEditingController();

  String _category = 'tops';
  String _season = 'All Season';

  bool _isSaving = false;

  final List<String> _categories = [
    'tops',
    'bottoms',
    'shoes',
    'outerwear',
    'accessories',
  ];

  final List<String> _seasons = [
    'All Season',
    'Spring',
    'Summer',
    'Autumn',
    'Winter',
  ];

  @override
  void dispose() {
    _nameController.dispose();
    _brandController.dispose();
    _colorController.dispose();
    _materialController.dispose();
    _sizeController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Clothing'),
        centerTitle: true,
      ),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.all(
              AppConstants.screenPadding,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildImagePlaceholder(context),
                const SizedBox(height: 24),
                _buildSectionTitle(context, 'Basic Information'),
                const SizedBox(height: 14),
                _buildTextField(
                  controller: _nameController,
                  label: 'Item name',
                  hint: 'e.g. Black T-Shirt',
                  icon: Icons.checkroom_outlined,
                  required: true,
                ),
                const SizedBox(height: 14),
                _buildCategorySelector(context),
                const SizedBox(height: 24),
                _buildSectionTitle(context, 'Details'),
                const SizedBox(height: 14),
                _buildTextField(
                  controller: _brandController,
                  label: 'Brand',
                  hint: 'Optional',
                  icon: Icons.branding_watermark_outlined,
                ),
                const SizedBox(height: 14),
                _buildTextField(
                  controller: _colorController,
                  label: 'Color',
                  hint: 'e.g. Black',
                  icon: Icons.palette_outlined,
                ),
                const SizedBox(height: 14),
                _buildTextField(
                  controller: _materialController,
                  label: 'Material',
                  hint: 'e.g. Cotton',
                  icon: Icons.texture_outlined,
                ),
                const SizedBox(height: 14),
                _buildTextField(
                  controller: _sizeController,
                  label: 'Size',
                  hint: 'e.g. M',
                  icon: Icons.straighten_outlined,
                ),
                const SizedBox(height: 14),
                _buildSeasonSelector(context),
                const SizedBox(height: 24),
                _buildSectionTitle(context, 'Notes'),
                const SizedBox(height: 14),
                _buildTextField(
                  controller: _notesController,
                  label: 'Notes',
                  hint: 'Add anything you want to remember...',
                  icon: Icons.notes_outlined,
                  maxLines: 4,
                ),
                const SizedBox(height: 28),
                AppButton(
                  text: 'Save to Wardrobe',
                  icon: Icons.check_rounded,
                  fullWidth: true,
                  loading: _isSaving,
                  onPressed: _saveItem,
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildImagePlaceholder(BuildContext context) {
    return AppCard(
      width: double.infinity,
      height: 220,
      borderRadius: AppConstants.largeBorderRadius,
      onTap: () {
        _showImageOptions(context);
      },
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.12),
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Icon(
              Icons.add_a_photo_outlined,
              color: AppColors.primary,
              size: 30,
            ),
          ),
          const SizedBox(height: 14),
          Text(
            'Add clothing photo',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w700,
                ),
          ),
          const SizedBox(height: 6),
          Text(
            'Take a photo or choose one from your gallery',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context)
                      .colorScheme
                      .onSurface
                      .withOpacity(0.55),
                ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(
    BuildContext context,
    String title,
  ) {
    return Text(
      title,
      style: Theme.of(context).textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w800,
          ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    bool required = false,
    int maxLines = 1,
  }) {
    return TextFormField(
      controller: controller,
      maxLines: maxLines,
      textInputAction:
          maxLines > 1 ? TextInputAction.newline : TextInputAction.next,
      validator: required
          ? (value) {
              if (value == null || value.trim().isEmpty) {
                return '$label is required';
              }
              return null;
            }
          : null,
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        prefixIcon: Icon(icon),
      ),
    );
  }

  Widget _buildCategorySelector(BuildContext context) {
    return DropdownButtonFormField<String>(
      value: _category,
      decoration: const InputDecoration(
        labelText: 'Category',
        prefixIcon: Icon(Icons.category_outlined),
      ),
      items: _categories.map((category) {
        return DropdownMenuItem(
          value: category,
          child: Text(
            _formatCategory(category),
          ),
        );
      }).toList(),
      onChanged: (value) {
        if (value == null) return;

        setState(() {
          _category = value;
        });
      },
    );
  }

  Widget _buildSeasonSelector(BuildContext context) {
    return DropdownButtonFormField<String>(
      value: _season,
      decoration: const InputDecoration(
        labelText: 'Season',
        prefixIcon: Icon(Icons.wb_sunny_outlined),
      ),
      items: _seasons.map((season) {
        return DropdownMenuItem(
          value: season,
          child: Text(season),
        );
      }).toList(),
      onChanged: (value) {
        if (value == null) return;

        setState(() {
          _season = value;
        });
      },
    );
  }

  String _formatCategory(String value) {
    return value[0].toUpperCase() + value.substring(1);
  }

  void _showImageOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ListTile(
                  leading: const Icon(Icons.camera_alt_outlined),
                  title: const Text('Take a photo'),
                  onTap: () {
                    Navigator.pop(sheetContext);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text(
                          'Camera will be connected here.',
                        ),
                      ),
                    );
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.photo_library_outlined),
                  title: const Text('Choose from gallery'),
                  onTap: () {
                    Navigator.pop(sheetContext);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text(
                          'Gallery will be connected here.',
                        ),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _saveItem() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    setState(() {
      _isSaving = true;
    });

    try {
      final now = DateTime.now();

      final item = ClothingItemModel(
        id: '',
        name: _nameController.text.trim(),
        category: _category,
        subcategory: '',
        imagePath: '',
        brand: _brandController.text.trim(),
        color: _colorController.text.trim(),
        colors: _colorController.text.trim().isEmpty
            ? []
            : [_colorController.text.trim()],
        pattern: '',
        material: _materialController.text.trim(),
        size: _sizeController.text.trim(),
        season: _season,
        styles: const [],
        occasions: const [],
        isFavorite: false,
        isAvailable: true,
        price: null,
        notes: _notesController.text.trim(),
        aiConfidence: 0,
        createdAt: now,
        updatedAt: now,
      );

      await _repository.addItem(item);

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Item added to your wardrobe.'),
        ),
      );

      Navigator.pop(context, true);
    } catch (error) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Could not save item: $error'),
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          _isSaving = false;
        });
      }
    }
  }
}