import 'package:flutter/material.dart';

import '../../../app/routes.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/constants/colors.dart';
import '../../../core/constants/strings.dart';
import '../../../core/widgets/app_button.dart';
import '../../../core/widgets/empty_state.dart';
import '../controller/wardrobe_controller.dart';
import 'widgets/clothing_card.dart';
import 'widgets/wardrobe_filter.dart';

class WardrobeScreen extends StatefulWidget {
  const WardrobeScreen({super.key});

  @override
  State<WardrobeScreen> createState() => _WardrobeScreenState();
}

class _WardrobeScreenState extends State<WardrobeScreen> {
  late final WardrobeController _controller;

  @override
  void initState() {
    super.initState();

    _controller = WardrobeController();
    _controller.initialize();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        return Scaffold(
          appBar: _buildAppBar(context),
          body: _controller.isLoading
              ? const Center(
                  child: CircularProgressIndicator(),
                )
              : _buildBody(context),
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () {
              Navigator.pushNamed(
                context,
                AppRoutes.addClothing,
              ).then((_) {
                _controller.loadItems();
              });
            },
            icon: const Icon(Icons.add_rounded),
            label: const Text(AppStrings.addClothing),
          ),
        );
      },
    );
  }

  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return AppBar(
      title: const Text(AppStrings.wardrobe),
      actions: [
        IconButton(
          tooltip: 'Search',
          onPressed: () {
            _showSearchDialog(context);
          },
          icon: const Icon(Icons.search_rounded),
        ),
        IconButton(
          tooltip: 'Favorites',
          onPressed: () {
            Navigator.pushNamed(
              context,
              AppRoutes.favorites,
            );
          },
          icon: const Icon(Icons.favorite_border_rounded),
        ),
        const SizedBox(width: 6),
      ],
    );
  }

  Widget _buildBody(BuildContext context) {
    if (_controller.items.isEmpty) {
      return EmptyState(
        icon: Icons.checkroom_outlined,
        title: AppStrings.emptyWardrobe,
        description: AppStrings.emptyWardrobeDescription,
        action: AppButton(
          text: AppStrings.addClothing,
          icon: Icons.add_rounded,
          onPressed: () {
            Navigator.pushNamed(
              context,
              AppRoutes.addClothing,
            ).then((_) {
              _controller.loadItems();
            });
          },
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _controller.loadItems,
      child: CustomScrollView(
        physics: const AlwaysScrollableScrollPhysics(
          parent: BouncingScrollPhysics(),
        ),
        slivers: [
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(
              AppConstants.screenPadding,
              16,
              AppConstants.screenPadding,
              0,
            ),
            sliver: SliverToBoxAdapter(
              child: _buildHeader(context),
            ),
          ),

          SliverPadding(
            padding: const EdgeInsets.fromLTRB(
              AppConstants.screenPadding,
              16,
              AppConstants.screenPadding,
              0,
            ),
            sliver: SliverToBoxAdapter(
              child: WardrobeFilter(
                selectedCategory: _controller.selectedCategory,
                onCategoryChanged: _controller.setCategory,
              ),
            ),
          ),

          SliverPadding(
            padding: const EdgeInsets.all(
              AppConstants.screenPadding,
            ),
            sliver: SliverGrid(
              delegate: SliverChildBuilderDelegate(
                (context, index) {
                  final item = _controller.filteredItems[index];

                  return ClothingCard(
                    item: item,
                    onTap: () {
                      Navigator.pushNamed(
                        context,
                        AppRoutes.clothingDetails,
                        arguments: item.id,
                      );
                    },
                    onFavorite: () {
                      _controller.toggleFavorite(item.id);
                    },
                    onDelete: () {
                      _showDeleteDialog(
                        context,
                        item.id,
                        item.name,
                      );
                    },
                  );
                },
                childCount: _controller.filteredItems.length,
              ),
              gridDelegate:
                  const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: AppConstants.wardrobeGridColumns,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 0.72,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    final theme = Theme.of(context);

    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '${_controller.filteredItems.length} items',
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'Everything you own, organized in one place.',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onSurface.withOpacity(0.6),
                ),
              ),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 8,
          ),
          decoration: BoxDecoration(
            color: AppColors.primary.withOpacity(0.10),
            borderRadius: BorderRadius.circular(14),
          ),
          child: const Icon(
            Icons.auto_awesome_rounded,
            color: AppColors.primary,
            size: 20,
          ),
        ),
      ],
    );
  }

  Future<void> _showSearchDialog(BuildContext context) async {
    final controller = TextEditingController();

    await showDialog(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Search wardrobe'),
          content: TextField(
            controller: controller,
            autofocus: true,
            decoration: const InputDecoration(
              hintText: 'Search clothes...',
              prefixIcon: Icon(Icons.search_rounded),
            ),
            onChanged: _controller.search,
          ),
          actions: [
            TextButton(
              onPressed: () {
                _controller.search('');
                Navigator.pop(dialogContext);
              },
              child: const Text('Done'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _showDeleteDialog(
    BuildContext context,
    String id,
    String name,
  ) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Delete item?'),
          content: Text(
            'Are you sure you want to remove "$name" from your wardrobe?',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(dialogContext, false);
              },
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () {
                Navigator.pop(dialogContext, true);
              },
              child: const Text('Delete'),
            ),
          ],
        );
      },
    );

    if (confirmed == true) {
      await _controller.deleteItem(id);
    }
  }
}