import '../../../models/clothing_item_model.dart';
import 'wardrobe_service.dart';

class WardrobeRepository {
  final WardrobeService _service;

  WardrobeRepository({
    WardrobeService? service,
  }) : _service = service ?? WardrobeService();

  Future<List<ClothingItemModel>> getWardrobeItems() async {
    return _service.getAllItems();
  }

  Future<ClothingItemModel?> getItemById(String id) async {
    return _service.getItemById(id);
  }

  Future<void> addItem(ClothingItemModel item) async {
    await _service.addItem(item);
  }

  Future<void> updateItem(ClothingItemModel item) async {
    await _service.updateItem(item);
  }

  Future<void> deleteItem(String id) async {
    await _service.deleteItem(id);
  }

  Future<void> toggleFavorite(String id) async {
    await _service.toggleFavorite(id);
  }

  Future<List<ClothingItemModel>> getFavorites() async {
    return _service.getFavorites();
  }

  Future<List<ClothingItemModel>> getItemsByCategory(
    String category,
  ) async {
    return _service.getItemsByCategory(category);
  }

  Future<List<ClothingItemModel>> searchItems(String query) async {
    return _service.searchItems(query);
  }

  Future<void> clearWardrobe() async {
    await _service.clearWardrobe();
  }
}