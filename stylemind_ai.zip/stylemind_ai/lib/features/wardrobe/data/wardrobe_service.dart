import 'dart:math';

import '../../../core/constants/app_constants.dart';
import '../../../core/services/storage_service.dart';
import '../../../models/clothing_item_model.dart';

class WardrobeService {
  final StorageService _storage;

  WardrobeService({
    StorageService? storage,
  }) : _storage = storage ?? StorageService();

  Future<List<ClothingItemModel>> getAllItems() async {
    final data = await _storage.getJsonList(
      AppConstants.wardrobeKey,
    );

    return data
        .map((item) => ClothingItemModel.fromJson(item))
        .toList();
  }

  Future<ClothingItemModel?> getItemById(String id) async {
    final items = await getAllItems();

    try {
      return items.firstWhere(
        (item) => item.id == id,
      );
    } catch (_) {
      return null;
    }
  }

  Future<void> addItem(ClothingItemModel item) async {
    final items = await getAllItems();

    if (items.length >= AppConstants.maxWardrobeItems) {
      throw Exception('Wardrobe limit reached.');
    }

    final newItem = item.id.isEmpty
        ? item.copyWith(
            id: _generateId(),
            createdAt: DateTime.now(),
            updatedAt: DateTime.now(),
          )
        : item;

    items.add(newItem);

    await _saveItems(items);
  }

  Future<void> updateItem(ClothingItemModel item) async {
    final items = await getAllItems();
    final index = items.indexWhere(
      (existing) => existing.id == item.id,
    );

    if (index == -1) {
      throw Exception('Clothing item not found.');
    }

    items[index] = item.copyWith(
      updatedAt: DateTime.now(),
    );

    await _saveItems(items);
  }

  Future<void> deleteItem(String id) async {
    final items = await getAllItems();

    items.removeWhere(
      (item) => item.id == id,
    );

    await _saveItems(items);
  }

  Future<void> toggleFavorite(String id) async {
    final items = await getAllItems();
    final index = items.indexWhere(
      (item) => item.id == id,
    );

    if (index == -1) {
      return;
    }

    final item = items[index];

    items[index] = item.copyWith(
      isFavorite: !item.isFavorite,
      updatedAt: DateTime.now(),
    );

    await _saveItems(items);
  }

  Future<List<ClothingItemModel>> getFavorites() async {
    final items = await getAllItems();

    return items
        .where((item) => item.isFavorite)
        .toList();
  }

  Future<List<ClothingItemModel>> getItemsByCategory(
    String category,
  ) async {
    final items = await getAllItems();

    return items
        .where(
          (item) =>
              item.category.toLowerCase() ==
              category.toLowerCase(),
        )
        .toList();
  }

  Future<List<ClothingItemModel>> searchItems(
    String query,
  ) async {
    if (query.trim().isEmpty) {
      return getAllItems();
    }

    final items = await getAllItems();
    final search = query.trim().toLowerCase();

    return items.where((item) {
      return item.name.toLowerCase().contains(search) ||
          item.category.toLowerCase().contains(search) ||
          item.subcategory.toLowerCase().contains(search) ||
          item.brand.toLowerCase().contains(search) ||
          item.color.toLowerCase().contains(search) ||
          item.material.toLowerCase().contains(search);
    }).toList();
  }

  Future<void> clearWardrobe() async {
    await _storage.setJsonList(
      AppConstants.wardrobeKey,
      [],
    );
  }

  Future<void> _saveItems(
    List<ClothingItemModel> items,
  ) async {
    await _storage.setJsonList(
      AppConstants.wardrobeKey,
      items.map((item) => item.toJson()).toList(),
    );
  }

  String _generateId() {
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final random = Random().nextInt(999999);

    return 'clothing_${timestamp}_$random';
  }
}