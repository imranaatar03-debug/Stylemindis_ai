import '../../../core/services/storage_service.dart';
import '../../../models/user_model.dart';

class AuthService {
  final StorageService _storageService;

  AuthService({
    StorageService? storageService,
  }) : _storageService = storageService ?? StorageService();

  Future<UserModel?> login({
    required String email,
    required String password,
  }) async {
    await Future.delayed(const Duration(milliseconds: 700));

    final users = await _storageService.getJsonList('registered_users');

    for (final json in users) {
      final user = UserModel.fromJson(
        Map<String, dynamic>.from(json),
      );

      if (user.email.toLowerCase() == email.trim().toLowerCase()) {
        await _storageService.setString(
          'current_user_id',
          user.id,
        );

        return user;
      }
    }

    return null;
  }

  Future<UserModel?> signup({
    required String name,
    required String email,
    required String password,
  }) async {
    await Future.delayed(const Duration(milliseconds: 700));

    final users = await _storageService.getJsonList('registered_users');

    final normalizedEmail = email.trim().toLowerCase();

    for (final json in users) {
      final existingUser = UserModel.fromJson(
        Map<String, dynamic>.from(json),
      );

      if (existingUser.email.toLowerCase() == normalizedEmail) {
        return null;
      }
    }

    final now = DateTime.now();

    final user = UserModel(
      id: now.millisecondsSinceEpoch.toString(),
      name: name.trim(),
      email: normalizedEmail,
      createdAt: now,
      updatedAt: now,
    );

    users.add(user.toJson());

    await _storageService.setJsonList(
      'registered_users',
      users,
    );

    await _storageService.setString(
      'current_user_id',
      user.id,
    );

    return user;
  }

  Future<bool> resetPassword(String email) async {
    await Future.delayed(const Duration(milliseconds: 700));

    final users = await _storageService.getJsonList('registered_users');

    final normalizedEmail = email.trim().toLowerCase();

    for (final json in users) {
      final user = UserModel.fromJson(
        Map<String, dynamic>.from(json),
      );

      if (user.email.toLowerCase() == normalizedEmail) {
        return true;
      }
    }

    return false;
  }

  Future<void> logout() async {
    await _storageService.remove('current_user_id');
  }

  Future<UserModel?> getCurrentUser() async {
    final userId = await _storageService.getString(
      'current_user_id',
    );

    if (userId == null || userId.isEmpty) {
      return null;
    }

    final users = await _storageService.getJsonList(
      'registered_users',
    );

    for (final json in users) {
      final user = UserModel.fromJson(
        Map<String, dynamic>.from(json),
      );

      if (user.id == userId) {
        return user;
      }
    }

    return null;
  }

  Future<bool> isLoggedIn() async {
    final user = await getCurrentUser();
    return user != null;
  }
}