import '../../../models/user_model.dart';
import 'auth_service.dart';

class AuthRepository {
  final AuthService _authService;

  AuthRepository({
    AuthService? authService,
  }) : _authService = authService ?? AuthService();

  Future<UserModel?> login({
    required String email,
    required String password,
  }) async {
    return _authService.login(
      email: email,
      password: password,
    );
  }

  Future<UserModel?> signup({
    required String name,
    required String email,
    required String password,
  }) async {
    return _authService.signup(
      name: name,
      email: email,
      password: password,
    );
  }

  Future<bool> resetPassword(String email) async {
    return _authService.resetPassword(email);
  }

  Future<void> logout() async {
    await _authService.logout();
  }

  Future<UserModel?> getCurrentUser() async {
    return _authService.getCurrentUser();
  }

  Future<bool> isLoggedIn() async {
    return _authService.isLoggedIn();
  }
}