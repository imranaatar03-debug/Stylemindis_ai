import 'package:flutter/material.dart';

import '../../../app/routes.dart';
import '../../../core/constants/colors.dart';
import '../../../core/constants/strings.dart';
import '../../../core/widgets/app_card.dart';

class RecentOutfits extends StatelessWidget {
  const RecentOutfits({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                AppStrings.recentOutfits,
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            TextButton(
              onPressed: () {
                Navigator.pushNamed(
                  context,
                  AppRoutes.outfits,
                );
              },
              child: const Text(AppStrings.seeAll),
            ),
          ],
        ),
        const SizedBox(height: 12),

        SizedBox(
          height: 190,
          child: ListView(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            children: const [
              _OutfitPreviewCard(
                title: 'Casual Look',
                occasion: 'Casual Day',
                score: 92,
                icon: Icons.style_rounded,
              ),
              SizedBox(width: 12),
              _OutfitPreviewCard(
                title: 'Street Style',
                occasion: 'Friends',
                score: 88,
                icon: Icons.directions_run_rounded,
              ),
              SizedBox(width: 12),
              _OutfitPreviewCard(
                title: 'Minimal Look',
                occasion: 'School',
                score: 95,
                icon: Icons.checkroom_rounded,
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _OutfitPreviewCard extends StatelessWidget {
  final String title;
  final String occasion;
  final int score;
  final IconData icon;

  const _OutfitPreviewCard({
    required this.title,
    required this.occasion,
    required this.score,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return SizedBox(
      width: 165,
      child: AppCard(
        padding: const EdgeInsets.all(14),
        borderRadius: 20,
        onTap: () {
          Navigator.pushNamed(
            context,
            AppRoutes.outfitResult,
          );
        },
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                  color: AppColors.primary.withOpacity(0.10),
                ),
                child: Icon(
                  icon,
                  size: 42,
                  color: AppColors.primary,
                ),
              ),
            ),
            const SizedBox(height: 10),
            Text(
              title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: theme.textTheme.titleSmall?.copyWith(
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 3),
            Row(
              children: [
                Expanded(
                  child: Text(
                    occasion,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurface.withOpacity(0.55),
                    ),
                  ),
                ),
                const Icon(
                  Icons.auto_awesome_rounded,
                  size: 13,
                  color: AppColors.primary,
                ),
                const SizedBox(width: 3),
                Text(
                  '$score%',
                  style: theme.textTheme.labelSmall?.copyWith(
                    color: AppColors.primary,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}