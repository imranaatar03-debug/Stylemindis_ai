import 'package:flutter/material.dart';

import '../../../app/routes.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/constants/colors.dart';
import '../../../core/constants/strings.dart';
import '../../../core/widgets/app_card.dart';
import 'quick_actions.dart';
import 'recent_outfits.dart';
import 'wardrobe_summary.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      body: SafeArea(
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(),
          slivers: [
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(
                AppConstants.screenPadding,
                18,
                AppConstants.screenPadding,
                0,
              ),
              sliver: SliverToBoxAdapter(
                child: _buildHeader(context),
              ),
            ),

            SliverPadding(
              padding: const EdgeInsets.fromLTRB(
                AppConstants.screenPadding,
                24,
                AppConstants.screenPadding,
                0,
              ),
              sliver: SliverToBoxAdapter(
                child: _buildAiBanner(context),
              ),
            ),

            SliverPadding(
              padding: const EdgeInsets.fromLTRB(
                AppConstants.screenPadding,
                28,
                AppConstants.screenPadding,
                0,
              ),
              sliver: SliverToBoxAdapter(
                child: Text(
                  AppStrings.quickActions,
                  style: theme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),

            const SliverPadding(
              padding: EdgeInsets.fromLTRB(
                AppConstants.screenPadding,
                14,
                AppConstants.screenPadding,
                0,
              ),
              sliver: SliverToBoxAdapter(
                child: QuickActions(),
              ),
            ),

            const SliverPadding(
              padding: EdgeInsets.fromLTRB(
                AppConstants.screenPadding,
                28,
                AppConstants.screenPadding,
                0,
              ),
              sliver: SliverToBoxAdapter(
                child: WardrobeSummary(),
              ),
            ),

            const SliverPadding(
              padding: EdgeInsets.fromLTRB(
                AppConstants.screenPadding,
                28,
                AppConstants.screenPadding,
                30,
              ),
              sliver: SliverToBoxAdapter(
                child: RecentOutfits(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    final theme = Theme.of(context);

    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Good to see you 👋',
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onSurface.withOpacity(0.6),
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'Your Style Space',
                style: theme.textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
        ),

        AppCard(
          width: 48,
          height: 48,
          padding: EdgeInsets.zero,
          borderRadius: 16,
          onTap: () {
            Navigator.pushNamed(
              context,
              AppRoutes.profile,
            );
          },
          child: const Icon(
            Icons.person_outline_rounded,
            size: 24,
          ),
        ),
      ],
    );
  }

  Widget _buildAiBanner(BuildContext context) {
    final theme = Theme.of(context);

    return AppCard(
      padding: const EdgeInsets.all(20),
      borderRadius: AppConstants.largeBorderRadius,
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          AppColors.primary.withOpacity(0.95),
          AppColors.primaryDark.withOpacity(0.95),
        ],
      ),
      onTap: () {
        Navigator.pushNamed(
          context,
          AppRoutes.aiStyleScan,
        );
      },
      child: Row(
        children: [
          Container(
            width: 58,
            height: 58,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.14),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                color: Colors.white.withOpacity(0.2),
              ),
            ),
            child: const Icon(
              Icons.auto_awesome_rounded,
              color: Colors.white,
              size: 29,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  AppStrings.aiStyleScan,
                  style: theme.textTheme.titleMedium?.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  'Scan your clothes and let AI understand your style.',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: Colors.white.withOpacity(0.82),
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          const Icon(
            Icons.arrow_forward_ios_rounded,
            color: Colors.white,
            size: 17,
          ),
        ],
      ),
    );
  }
}