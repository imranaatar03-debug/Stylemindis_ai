import 'dart:io';

import 'ai_vision_service.dart';

class ClothingDetector {
  final AiVisionService _visionService;

  ClothingDetector({
    AiVisionService? visionService,
  }) : _visionService = visionService ?? AiVisionService();

  Future<List<DetectedClothing>> detect(
    File imageFile,
  ) async {
    if (!await _visionService.isClothingImage(imageFile)) {
      return [];
    }

    final results = await _visionService.analyzeImage(imageFile);

    return results
        .map(
          (result) => DetectedClothing.fromMap(result),
        )
        .toList();
  }

  Future<DetectedClothing?> detectSingle(
    File imageFile,
  ) async {
    final results = await detect(imageFile);

    if (results.isEmpty) {
      return null;
    }

    return results.first;
  }
}

class DetectedClothing {
  final String name;
  final String category;
  final String color;
  final double confidence;
  final DetectionBoundingBox boundingBox;

  const DetectedClothing({
    required this.name,
    required this.category,
    required this.color,
    required this.confidence,
    required this.boundingBox,
  });

  factory DetectedClothing.fromMap(
    Map<String, dynamic> map,
  ) {
    final rawBox =
        map['boundingBox'] as Map<String, dynamic>?;

    return DetectedClothing(
      name: map['name']?.toString() ?? 'Clothing Item',
      category: map['category']?.toString() ?? 'unknown',
      color: map['color']?.toString() ?? 'Unknown',
      confidence:
          (map['confidence'] as num?)?.toDouble() ?? 0.0,
      boundingBox: DetectionBoundingBox.fromMap(
        rawBox ?? const {},
      ),
    );
  }

  String get confidenceLabel {
    return '${(confidence * 100).round()}%';
  }
}

class DetectionBoundingBox {
  final double left;
  final double top;
  final double width;
  final double height;

  const DetectionBoundingBox({
    required this.left,
    required this.top,
    required this.width,
    required this.height,
  });

  factory DetectionBoundingBox.fromMap(
    Map<String, dynamic> map,
  ) {
    return DetectionBoundingBox(
      left: (map['left'] as num?)?.toDouble() ?? 0.0,
      top: (map['top'] as num?)?.toDouble() ?? 0.0,
      width: (map['width'] as num?)?.toDouble() ?? 0.0,
      height: (map['height'] as num?)?.toDouble() ?? 0.0,
    );
  }
}