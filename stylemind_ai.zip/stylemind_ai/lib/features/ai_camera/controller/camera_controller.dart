import 'dart:io';

import 'package:flutter/foundation.dart';

import '../../../core/services/camera_service.dart';
import '../data/ai_vision_service.dart';
import '../data/clothing_detector.dart';

class CameraController extends ChangeNotifier {
  final CameraService _cameraService;
  final AiVisionService _visionService;
  final ClothingDetector _clothingDetector;

  CameraController({
    CameraService? cameraService,
    AiVisionService? visionService,
    ClothingDetector? clothingDetector,
  })  : _cameraService = cameraService ?? CameraService(),
        _visionService = visionService ?? AiVisionService(),
        _clothingDetector = clothingDetector ?? ClothingDetector();

  bool _isInitialized = false;
  bool _isScanning = false;
  bool _isCapturing = false;
  bool _flashEnabled = false;
  String? _errorMessage;
  List<DetectedClothing> _detectedItems = [];

  bool get isInitialized => _isInitialized;
  bool get isScanning => _isScanning;
  bool get isCapturing => _isCapturing;
  bool get flashEnabled => _flashEnabled;
  String? get errorMessage => _errorMessage;
  List<DetectedClothing> get detectedItems =>
      List.unmodifiable(_detectedItems);

  Future<void> initialize() async {
    try {
      _errorMessage = null;
      notifyListeners();

      await _cameraService.initializeCamera();

      _isInitialized = true;
      notifyListeners();
    } catch (e) {
      _errorMessage = 'Unable to initialize camera.';
      _isInitialized = false;
      notifyListeners();
    }
  }

  Future<String?> captureAndScan() async {
    if (!_isInitialized || _isCapturing) {
      return null;
    }

    try {
      _isCapturing = true;
      _isScanning = true;
      _errorMessage = null;
      notifyListeners();

      final imagePath = await _cameraService.takePicture();

      if (imagePath == null || imagePath.isEmpty) {
        _errorMessage = 'Could not capture image.';
        return null;
      }

      final file = File(imagePath);

      if (!await file.exists()) {
        _errorMessage = 'Captured image was not found.';
        return null;
      }

      _detectedItems = await _clothingDetector.detect(file);

      if (_detectedItems.isEmpty) {
        final result = await _visionService.analyzeImage(file);

        if (result.isNotEmpty) {
          _detectedItems = result
              .map((item) => DetectedClothing.fromMap(item))
              .toList();
        }
      }

      return imagePath;
    } catch (e) {
      _errorMessage = 'Something went wrong while scanning.';
      return null;
    } finally {
      _isCapturing = false;
      _isScanning = false;
      notifyListeners();
    }
  }

  Future<void> toggleFlash() async {
    try {
      await _cameraService.toggleFlash();
      _flashEnabled = !_flashEnabled;

      notifyListeners();
    } catch (e) {
      notifyListeners();
    }
  }

  void clearDetections() {
    _detectedItems = [];
    _errorMessage = null;
    notifyListeners();
  }

  void clearError() {
    _errorMessage = null;
    notifyListeners();
  }

  Future<void> disposeCamera() async {
    await _cameraService.dispose();

    _isInitialized = false;
    _isScanning = false;
    _isCapturing = false;
    notifyListeners();
  }

  @override
  void dispose() {
    _cameraService.dispose();
    super.dispose();
  }
}