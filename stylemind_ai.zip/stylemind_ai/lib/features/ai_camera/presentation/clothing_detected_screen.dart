import 'dart:io';

import 'package:flutter/material.dart';

import '../../../core/constants/colors.dart';
import '../../../core/constants/strings.dart';
import '../../../core/widgets/app_button.dart';
import '../../../core/widgets/app_card.dart';

class ClothingDetectedScreen extends StatelessWidget {
  final String? imagePath;
  final List<Map<String, dynamic>> detectedItems;

  const ClothingDetectedScreen({
    super.key,
    this.imagePath,
    this.detectedItems = const [],
  });

  @override
  Widget build(BuildContext context) {
    final items = detectedItems.isEmpty
        ? [
            {
              'name': 'T-Shirt',
              'category': 'Tops',
              'confidence': 0.96,
            },
          ]
        : detectedItems;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: const Text(
          AppStrings.clothingDetected,
          style: TextStyle(fontWeight: FontWeight.w700),
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildImagePreview(context),
              const SizedBox(height: 24),

              Text(
                AppStrings.detectedItems,
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w800,
                    ),
              ),
              const SizedBox(height: 8),

              Text(
                AppStrings.aiDetectedClothing,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Theme.of(context)
                          .textTheme
                          .bodyMedium
                          ?.color
                          ?.withOpacity(0.65),
                    ),
              ),
              const SizedBox(height: 16),

              ...items.map(
                (item) => Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: _DetectedItemCard(item: item),
                ),
              ),

              const SizedBox(height: 16),

              AppButton(
                text: AppStrings.addToWardrobe,
                icon: Icons.add_rounded,
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text(
                        AppStrings.itemAddedToWardrobe,
                      ),
                    ),
                  );
                },
              ),

              const SizedBox(height: 12),

              AppButton(
                text: AppStrings.scanAgain,
                icon: Icons.refresh_rounded,
                outlined: true,
                onPressed: () => Navigator.pop(context),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildImagePreview(BuildContext context) {
    return AppCard(
      padding: EdgeInsets.zero,
      child: Container(
        height: 300,
        width: double.infinity,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              AppColors.primary.withOpacity(0.18),
              AppColors.secondary.withOpacity(0.08),
            ],
          ),
        ),
        child: imagePath == null
            ? const Center(
                child: Icon(
                  Icons.checkroom_rounded,
                  size: 80,
                  color: AppColors.primary,
                ),
              )
            : ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Image.file(
                  File(imagePath!),
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) {
                    return const Center(
                      child: Icon(
                        Icons.checkroom_rounded,
                        size: 80,
                        color: AppColors.primary,
                      ),
                    );
                  },
                ),
              ),
      ),
    );
  }
}

class _DetectedItemCard extends StatelessWidget {
  final Map<String, dynamic> item;

  const _DetectedItemCard({
    required this.item,
  });

  @override
  Widget build(BuildContext context) {
    final name = item['name']?.toString() ?? 'Clothing item';
    final category = item['category']?.toString() ?? 'Unknown';
    final confidence = item['confidence'] is num
        ? (item['confidence'] as num).toDouble()
        : 0.0;

    final percentage = (confidence * 100).round();

    return AppCard(
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.12),
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Icon(
              Icons.checkroom_rounded,
              color: AppColors.primary,
            ),
          ),
          const SizedBox(width: 14),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  category,
                  style: TextStyle(
                    color: Theme.of(context)
                        .textTheme
                        .bodyMedium
                        ?.color
                        ?.withOpacity(0.6),
                  ),
                ),
              ],
            ),
          ),

          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              const Icon(
                Icons.auto_awesome_rounded,
                size: 18,
                color: AppColors.secondary,
              ),
              const SizedBox(height: 4),
              Text(
                '$percentage%',
                style: const TextStyle(
                  fontWeight: FontWeight.w800,
                  color: AppColors.primary,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}