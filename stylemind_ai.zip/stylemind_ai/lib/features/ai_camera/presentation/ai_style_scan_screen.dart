import 'dart:io';

import 'package:flutter/material.dart';

import '../../../core/constants/colors.dart';
import '../../../core/constants/strings.dart';
import '../../../core/services/camera_service.dart';
import '../data/clothing_detector.dart';

class AiStyleScanScreen extends StatefulWidget {
  const AiStyleScanScreen({super.key});

  @override
  State<AiStyleScanScreen> createState() =>
      _AiStyleScanScreenState();
}

class _AiStyleScanScreenState extends State<AiStyleScanScreen> {
  final CameraService _cameraService = CameraService();
  final ClothingDetector _detector = ClothingDetector();

  bool _isScanning = false;
  bool _isCameraReady = false;
  String _status = 'Point your camera at a clothing item';
  List<DetectedClothing> _detections = [];

  @override
  void initState() {
    super.initState();
    _initializeCamera();
  }

  Future<void> _initializeCamera() async {
    try {
      await _cameraService.initializeCamera();

      if (!mounted) return;

      setState(() {
        _isCameraReady = _cameraService.isInitialized;
      });
    } catch (_) {
      if (!mounted) return;

      setState(() {
        _isCameraReady = false;
        _status = 'Camera is unavailable on this device.';
      });
    }
  }

  Future<void> _scanImage() async {
    if (_isScanning) return;

    setState(() {
      _isScanning = true;
      _status = 'AI is analyzing your style...';
      _detections = [];
    });

    try {
      final image = await _cameraService.takePicture();

      if (image == null) {
        setState(() {
          _isScanning = false;
          _status = 'No image captured';
        });
        return;
      }

      final imageFile = File(image.path);

      final results = await _detector.detect(imageFile);

      if (!mounted) return;

      setState(() {
        _detections = results;
        _isScanning = false;
        _status = results.isEmpty
            ? 'No clothing item detected'
            : '${results.length} item detected';
      });

      if (results.isNotEmpty) {
        _showDetectionResult(results.first);
      }
    } catch (_) {
      if (!mounted) return;

      setState(() {
        _isScanning = false;
        _status = 'Something went wrong. Try again.';
      });
    }
  }

  void _showDetectionResult(DetectedClothing item) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) {
        return Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Theme.of(context).scaffoldBackgroundColor,
            borderRadius: const BorderRadius.vertical(
              top: Radius.circular(28),
            ),
          ),
          child: SafeArea(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 42,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Theme.of(context)
                        .colorScheme
                        .onSurface
                        .withOpacity(0.15),
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                const SizedBox(height: 22),
                const Icon(
                  Icons.auto_awesome,
                  size: 34,
                  color: AppColors.primary,
                ),
                const SizedBox(height: 12),
                Text(
                  'AI DETECTED',
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1.2,
                      ),
                ),
                const SizedBox(height: 20),
                _InfoRow(
                  icon: Icons.checkroom_outlined,
                  label: 'Item',
                  value: item.name,
                ),
                _InfoRow(
                  icon: Icons.category_outlined,
                  label: 'Category',
                  value: item.category,
                ),
                _InfoRow(
                  icon: Icons.palette_outlined,
                  label: 'Color',
                  value: item.color,
                ),
                _InfoRow(
                  icon: Icons.analytics_outlined,
                  label: 'Confidence',
                  value: item.confidenceLabel,
                ),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: () {
                      Navigator.pop(context);
                      _openDetectedItem(item);
                    },
                    icon: const Icon(Icons.add),
                    label: const Text('ADD TO WARDROBE'),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _openDetectedItem(DetectedClothing item) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          '${item.name} is ready to add to your wardrobe.',
        ),
      ),
    );
  }

  @override
  void dispose() {
    _cameraService.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color(0xFF171323),
                    Colors.black,
                  ],
                ),
              ),
              child: Center(
                child: Icon(
                  Icons.camera_alt_outlined,
                  size: 90,
                  color: Colors.white.withOpacity(0.10),
                ),
              ),
            ),
          ),

          SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(
                    20,
                    16,
                    20,
                    0,
                  ),
                  child: Row(
                    children: [
                      _GlassButton(
                        icon: Icons.arrow_back,
                        onTap: () => Navigator.pop(context),
                      ),
                      const Spacer(),
                      Column(
                        children: [
                          Text(
                            AppStrings.aiStyleScan,
                            style: theme.textTheme.titleMedium
                                ?.copyWith(
                              color: Colors.white,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 1.1,
                            ),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            'AI POWERED',
                            style: theme.textTheme.labelSmall
                                ?.copyWith(
                              color: AppColors.secondary,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 1.5,
                            ),
                          ),
                        ],
                      ),
                      const Spacer(),
                      _GlassButton(
                        icon: Icons.help_outline,
                        onTap: () {},
                      ),
                    ],
                  ),
                ),

                const Spacer(),

                _ScanFrame(
                  isScanning: _isScanning,
                  detection: _detections.isNotEmpty
                      ? _detections.first
                      : null,
                ),

                const SizedBox(height: 26),

                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 30,
                  ),
                  child: Text(
                    _status,
                    textAlign: TextAlign.center,
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: Colors.white.withOpacity(0.85),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),

                const Spacer(),

                Padding(
                  padding: const EdgeInsets.fromLTRB(
                    24,
                    0,
                    24,
                    24,
                  ),
                  child: Row(
                    mainAxisAlignment:
                        MainAxisAlignment.spaceEvenly,
                    children: [
                      _CameraAction(
                        icon: Icons.photo_library_outlined,
                        label: 'Gallery',
                        onTap: () {},
                      ),
                      GestureDetector(
                        onTap: _scanImage,
                        child: Container(
                          width: 76,
                          height: 76,
                          padding: const EdgeInsets.all(5),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: AppColors.secondary,
                              width: 2,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: AppColors.primary
                                    .withOpacity(0.35),
                                blurRadius: 22,
                                spreadRadius: 3,
                              ),
                            ],
                          ),
                          child: Container(
                            decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.white,
                            ),
                            child: Icon(
                              _isScanning
                                  ? Icons.hourglass_top
                                  : Icons.camera_alt,
                              color: Colors.black,
                              size: 28,
                            ),
                          ),
                        ),
                      ),
                      _CameraAction(
                        icon: Icons.flip_camera_ios_outlined,
                        label: 'Flip',
                        onTap: () {},
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          if (_isScanning)
            Positioned.fill(
              child: IgnorePointer(
                child: Container(
                  color: Colors.black.withOpacity(0.18),
                  child: const Center(
                    child: CircularProgressIndicator(
                      color: AppColors.secondary,
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _ScanFrame extends StatelessWidget {
  final bool isScanning;
  final DetectedClothing? detection;

  const _ScanFrame({
    required this.isScanning,
    required this.detection,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 285,
      height: 390,
      child: Stack(
        children: [
          Positioned.fill(
            child: CustomPaint(
              painter: _FramePainter(
                active: isScanning || detection != null,
              ),
            ),
          ),
          if (detection != null)
            Positioned(
              left: 18,
              top: 18,
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 7,
                ),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.65),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: AppColors.secondary.withOpacity(0.7),
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.auto_awesome,
                      size: 15,
                      color: AppColors.secondary,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      detection!.name,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _FramePainter extends CustomPainter {
  final bool active;

  const _FramePainter({
    required this.active,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = active
          ? AppColors.secondary
          : Colors.white.withOpacity(0.55)
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;

    const length = 28.0;

    final path = Path();

    path
      ..moveTo(0, length)
      ..lineTo(0, 0)
      ..lineTo(length, 0)
      ..moveTo(size.width - length, 0)
      ..lineTo(size.width, 0)
      ..lineTo(size.width, length)
      ..moveTo(0, size.height - length)
      ..lineTo(0, size.height)
      ..lineTo(length, size.height)
      ..moveTo(
        size.width - length,
        size.height,
      )
      ..lineTo(size.width, size.height)
      ..lineTo(size.width, size.height - length);

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _FramePainter oldDelegate) {
    return oldDelegate.active != active;
  }
}

class _GlassButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;

  const _GlassButton({
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white.withOpacity(0.08),
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: SizedBox(
          width: 44,
          height: 44,
          child: Icon(
            icon,
            color: Colors.white,
            size: 21,
          ),
        ),
      ),
    );
  }
}

class _CameraAction extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _CameraAction({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        IconButton(
          onPressed: onTap,
          icon: Icon(
            icon,
            color: Colors.white,
            size: 25,
          ),
        ),
        Text(
          label,
          style: const TextStyle(
            color: Colors.white70,
            fontSize: 11,
          ),
        ),
      ],
    );
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _InfoRow({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Row(
        children: [
          Icon(
            icon,
            size: 20,
            color: AppColors.primary,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              label,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ),
          Text(
            value,
            style: Theme.of(context)
                .textTheme
                .bodyMedium
                ?.copyWith(
                  fontWeight: FontWeight.w700,
                ),
          ),
        ],
      ),
    );
  }
}