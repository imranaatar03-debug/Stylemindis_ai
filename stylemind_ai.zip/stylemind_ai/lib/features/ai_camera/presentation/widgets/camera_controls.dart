import 'package:flutter/material.dart';

import '../../../../core/constants/colors.dart';

class CameraControls extends StatelessWidget {
  final VoidCallback? onCapture;
  final VoidCallback? onGallery;
  final VoidCallback? onFlash;
  final VoidCallback? onClose;
  final bool flashEnabled;
  final bool isCapturing;

  const CameraControls({
    super.key,
    this.onCapture,
    this.onGallery,
    this.onFlash,
    this.onClose,
    this.flashEnabled = false,
    this.isCapturing = false,
  });

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _ControlButton(
                  icon: Icons.close_rounded,
                  onTap: onClose,
                ),
                _ControlButton(
                  icon: flashEnabled
                      ? Icons.flash_on_rounded
                      : Icons.flash_off_rounded,
                  onTap: onFlash,
                  active: flashEnabled,
                ),
              ],
            ),

            const SizedBox(height: 28),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _ControlButton(
                  icon: Icons.photo_library_rounded,
                  onTap: onGallery,
                ),

                _CaptureButton(
                  onTap: isCapturing ? null : onCapture,
                  isCapturing: isCapturing,
                ),

                const SizedBox(width: 52),
              ],
            ),

            const SizedBox(height: 14),

            const Text(
              'SCAN YOUR CLOTHING',
              style: TextStyle(
                color: Colors.white,
                fontSize: 11,
                fontWeight: FontWeight.w700,
                letterSpacing: 1.4,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ControlButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onTap;
  final bool active;

  const _ControlButton({
    required this.icon,
    this.onTap,
    this.active = false,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: 52,
        height: 52,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: active
              ? AppColors.primary.withOpacity(0.85)
              : Colors.black.withOpacity(0.55),
          border: Border.all(
            color: Colors.white.withOpacity(0.2),
          ),
          boxShadow: [
            if (active)
              BoxShadow(
                color: AppColors.primary.withOpacity(0.4),
                blurRadius: 18,
              ),
          ],
        ),
        child: Icon(
          icon,
          color: Colors.white,
          size: 23,
        ),
      ),
    );
  }
}

class _CaptureButton extends StatelessWidget {
  final VoidCallback? onTap;
  final bool isCapturing;

  const _CaptureButton({
    required this.onTap,
    required this.isCapturing,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: 78,
        height: 78,
        padding: const EdgeInsets.all(6),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.white.withOpacity(0.2),
          border: Border.all(
            color: Colors.white.withOpacity(0.8),
            width: 2,
          ),
        ),
        child: Container(
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                AppColors.primary,
                AppColors.secondary,
              ],
            ),
            boxShadow: [
              BoxShadow(
                color: AppColors.primary.withOpacity(0.45),
                blurRadius: 20,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Center(
            child: isCapturing
                ? const SizedBox(
                    width: 25,
                    height: 25,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.5,
                      valueColor: AlwaysStoppedAnimation<Color>(
                        Colors.white,
                      ),
                    ),
                  )
                : const Icon(
                    Icons.camera_alt_rounded,
                    color: Colors.white,
                    size: 29,
                  ),
          ),
        ),
      ),
    );
  }
}