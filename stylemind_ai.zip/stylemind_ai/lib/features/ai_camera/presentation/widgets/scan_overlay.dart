import 'package:flutter/material.dart';

import '../../../../core/constants/colors.dart';

class ScanOverlay extends StatefulWidget {
  final bool isScanning;
  final String? detectedLabel;

  const ScanOverlay({
    super.key,
    this.isScanning = true,
    this.detectedLabel,
  });

  @override
  State<ScanOverlay> createState() => _ScanOverlayState();
}

class _ScanOverlayState extends State<ScanOverlay>
    with SingleTickerProviderStateMixin {
  late final AnimationController _animationController;
  late final Animation<double> _scanAnimation;

  @override
  void initState() {
    super.initState();

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2200),
    )..repeat(reverse: true);

    _scanAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: IgnorePointer(
        child: Stack(
          children: [
            CustomPaint(
              painter: _OverlayPainter(
                color: AppColors.primary,
              ),
              size: Size.infinite,
            ),

            if (widget.isScanning)
              AnimatedBuilder(
                animation: _scanAnimation,
                builder: (context, child) {
                  return Positioned(
                    left: 30,
                    right: 30,
                    top: 50 + (_scanAnimation.value * 300),
                    child: Container(
                      height: 2,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.transparent,
                            AppColors.secondary.withOpacity(0.2),
                            AppColors.secondary,
                            AppColors.secondary.withOpacity(0.2),
                            Colors.transparent,
                          ],
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.secondary.withOpacity(0.6),
                            blurRadius: 12,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),

            if (widget.detectedLabel != null)
              Positioned(
                top: 24,
                left: 24,
                child: _DetectedLabel(
                  label: widget.detectedLabel!,
                ),
              ),

            Positioned(
              bottom: 28,
              left: 0,
              right: 0,
              child: Center(
                child: AnimatedOpacity(
                  opacity: widget.isScanning ? 1 : 0,
                  duration: const Duration(milliseconds: 250),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 9,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.55),
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(
                        color: Colors.white.withOpacity(0.12),
                      ),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SizedBox(
                          width: 8,
                          height: 8,
                          child: DecoratedBox(
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: AppColors.secondary,
                            ),
                          ),
                        ),
                        SizedBox(width: 9),
                        Text(
                          'AI SCANNING...',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DetectedLabel extends StatelessWidget {
  final String label;

  const _DetectedLabel({
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 13,
        vertical: 9,
      ),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.65),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: AppColors.secondary.withOpacity(0.55),
        ),
        boxShadow: [
          BoxShadow(
            color: AppColors.secondary.withOpacity(0.15),
            blurRadius: 14,
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(
            Icons.auto_awesome_rounded,
            size: 16,
            color: AppColors.secondary,
          ),
          const SizedBox(width: 8),
          Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w700,
              fontSize: 13,
            ),
          ),
        ],
      ),
    );
  }
}

class _OverlayPainter extends CustomPainter {
  final Color color;

  _OverlayPainter({
    required this.color,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withOpacity(0.85)
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    const left = 30.0;
    const right = 30.0;
    const top = 50.0;
    const bottom = 50.0;
    const corner = 28.0;

    final rect = Rect.fromLTRB(
      left,
      top,
      size.width - right,
      size.height - bottom,
    );

    final path = Path();

    // Top-left
    path.moveTo(rect.left + corner, rect.top);
    path.lineTo(rect.left, rect.top);
    path.lineTo(rect.left, rect.top + corner);

    // Top-right
    path.moveTo(rect.right - corner, rect.top);
    path.lineTo(rect.right, rect.top);
    path.lineTo(rect.right, rect.top + corner);

    // Bottom-left
    path.moveTo(rect.left, rect.bottom - corner);
    path.lineTo(rect.left, rect.bottom);
    path.lineTo(rect.left + corner, rect.bottom);

    // Bottom-right
    path.moveTo(rect.right - corner, rect.bottom);
    path.lineTo(rect.right, rect.bottom);
    path.lineTo(rect.right, rect.bottom - corner);

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _OverlayPainter oldDelegate) {
    return oldDelegate.color != color;
  }
}