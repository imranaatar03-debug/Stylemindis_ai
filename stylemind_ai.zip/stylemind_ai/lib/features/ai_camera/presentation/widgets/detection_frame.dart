import 'package:flutter/material.dart';

import '../../../../core/constants/colors.dart';

class DetectionFrame extends StatelessWidget {
  final Rect rect;
  final String label;
  final double confidence;
  final bool isSelected;

  const DetectionFrame({
    super.key,
    required this.rect,
    required this.label,
    this.confidence = 0.0,
    this.isSelected = false,
  });

  @override
  Widget build(BuildContext context) {
    final percentage = (confidence.clamp(0.0, 1.0) * 100).round();

    return Positioned(
      left: rect.left,
      top: rect.top,
      width: rect.width,
      height: rect.height,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          CustomPaint(
            size: Size(rect.width, rect.height),
            painter: _DetectionFramePainter(
              color: isSelected
                  ? AppColors.accent
                  : AppColors.secondary,
            ),
          ),

          Positioned(
            top: -38,
            left: 0,
            child: Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 10,
                vertical: 7,
              ),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.72),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: isSelected
                      ? AppColors.accent.withOpacity(0.7)
                      : AppColors.secondary.withOpacity(0.55),
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    Icons.auto_awesome_rounded,
                    size: 14,
                    color: isSelected
                        ? AppColors.accent
                        : AppColors.secondary,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    label,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  if (confidence > 0) ...[
                    const SizedBox(width: 7),
                    Text(
                      '$percentage%',
                      style: TextStyle(
                        color: isSelected
                            ? AppColors.accent
                            : AppColors.secondary,
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),

          if (isSelected)
            Positioned(
              right: -8,
              top: -8,
              child: Container(
                width: 22,
                height: 22,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppColors.accent,
                ),
                child: const Icon(
                  Icons.check_rounded,
                  size: 15,
                  color: Colors.white,
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _DetectionFramePainter extends CustomPainter {
  final Color color;

  const _DetectionFramePainter({
    required this.color,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 2.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    const cornerLength = 22.0;

    final path = Path();

    // Top-left
    path.moveTo(cornerLength, 0);
    path.lineTo(0, 0);
    path.lineTo(0, cornerLength);

    // Top-right
    path.moveTo(size.width - cornerLength, 0);
    path.lineTo(size.width, 0);
    path.lineTo(size.width, cornerLength);

    // Bottom-left
    path.moveTo(0, size.height - cornerLength);
    path.lineTo(0, size.height);
    path.lineTo(cornerLength, size.height);

    // Bottom-right
    path.moveTo(
      size.width - cornerLength,
      size.height,
    );
    path.lineTo(size.width, size.height);
    path.lineTo(
      size.width,
      size.height - cornerLength,
    );

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _DetectionFramePainter oldDelegate) {
    return oldDelegate.color != color;
  }
}