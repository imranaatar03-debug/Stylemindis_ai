import '../../../core/services/storage_service.dart';
import '../../../models/clothing_item_model.dart';
import '../../../models/outfit_model.dart';
import '../../wardrobe/data/wardrobe_repository.dart';

/// Persists generated/saved outfits and exposes the wardrobe items the
/// outfit generator picks from.
class OutfitRepository {
  final StorageService _storageService;
  final WardrobeRepository _wardrobeRepository;

  OutfitRepository({
    StorageService? storageService,
    WardrobeRepository? wardrobeRepository,
  })  : _storageService = storageService ?? StorageService(),
        _wardrobeRepository = wardrobeRepository ?? WardrobeRepository();

  static const String _outfitsKey = 'saved_outfits';

  Future<List<ClothingItemModel>> getWardrobeItems() async {
    return _wardrobeRepository.getWardrobeItems();
  }

  Future<List<OutfitModel>> getOutfits() async {
    final data = await _storageService.getJsonList(_outfitsKey);

    return data
        .map(
          (json) => OutfitModel.fromJson(
            Map<String, dynamic>.from(json),
          ),
        )
        .toList();
  }

  Future<OutfitModel?> getOutfitById(String id) async {
    final outfits = await getOutfits();

    try {
      return outfits.firstWhere(
        (outfit) => outfit.id == id,
      );
    } catch (_) {
      return null;
    }
  }

  Future<void> saveOutfit(OutfitModel outfit) async {
    final outfits = await getOutfits();

    final index = outfits.indexWhere(
      (item) => item.id == outfit.id,
    );

    if (index >= 0) {
      outfits[index] = outfit;
    } else {
      outfits.add(outfit);
    }

    await _saveAll(outfits);
  }

  Future<void> deleteOutfit(String id) async {
    final outfits = await getOutfits();

    outfits.removeWhere(
      (outfit) => outfit.id == id,
    );

    await _saveAll(outfits);
  }

  Future<void> toggleFavorite(String id) async {
    final outfits = await getOutfits();

    final index = outfits.indexWhere(
      (outfit) => outfit.id == id,
    );

    if (index == -1) return;

    final outfit = outfits[index];

    outfits[index] = outfit.copyWith(
      isFavorite: !outfit.isFavorite,
    );

    await _saveAll(outfits);
  }

  Future<List<OutfitModel>> getFavoriteOutfits() async {
    final outfits = await getOutfits();

    return outfits.where((outfit) => outfit.isFavorite).toList();
  }

  Future<void> clearOutfits() async {
    await _storageService.setJsonList(
      _outfitsKey,
      [],
    );
  }

  Future<void> _saveAll(
    List<OutfitModel> outfits,
  ) async {
    await _storageService.setJsonList(
      _outfitsKey,
      outfits.map((outfit) => outfit.toJson()).toList(),
    );
  }
}
