import '../../../models/clothing_item_model.dart';
import '../../../models/outfit_model.dart';
import '../domain/color_matching_engine.dart';
import '../domain/occasion_engine.dart';
import '../domain/outfit_engine.dart';
import '../domain/style_matching_engine.dart';

/// Builds a complete [OutfitModel] out of the user's wardrobe for a given
/// occasion/style, using the local matching engines (no network call —
/// "AI" here means an on-device rule/scoring engine, consistent with the
/// rest of this app's fully offline data layer).
class OutfitAiService {
  final OutfitEngine _outfitEngine;
  final ColorMatchingEngine _colorEngine;
  final StyleMatchingEngine _styleEngine;
  final OccasionEngine _occasionEngine;

  OutfitAiService({
    OutfitEngine? outfitEngine,
    ColorMatchingEngine? colorEngine,
    StyleMatchingEngine? styleEngine,
    OccasionEngine? occasionEngine,
  })  : _outfitEngine = outfitEngine ?? OutfitEngine(),
        _colorEngine = colorEngine ?? ColorMatchingEngine(),
        _styleEngine = styleEngine ?? StyleMatchingEngine(),
        _occasionEngine = occasionEngine ?? OccasionEngine();

  /// Picks a compatible set of items from [wardrobeItems] for the given
  /// [occasion]/[style] and returns them as a scored [OutfitModel], or
  /// null when the wardrobe has nothing usable.
  Future<OutfitModel?> generateOutfit({
    required List<ClothingItemModel> wardrobeItems,
    required String occasion,
    required String style,
  }) async {
    // Simulate the short "thinking" delay shown by the generating screen.
    await Future.delayed(const Duration(milliseconds: 900));

    final selected = _outfitEngine.generate(
      wardrobe: wardrobeItems,
      occasion: occasion,
      style: style,
    );

    if (selected.isEmpty) {
      return null;
    }

    final score = _calculateOutfitScore(
      items: selected,
      occasion: occasion,
      style: style,
    );

    final now = DateTime.now();

    return OutfitModel(
      id: now.microsecondsSinceEpoch.toString(),
      name: '$style • $occasion',
      items: selected,
      occasion: occasion,
      style: style,
      compatibilityScore: score,
      description:
          'AI-picked outfit for $occasion, matched to your $style style.',
      createdAt: now,
      updatedAt: now,
    );
  }

  int _calculateOutfitScore({
    required List<ClothingItemModel> items,
    required String occasion,
    required String style,
  }) {
    final colorScore = _colorEngine.calculateOutfitScore(
      items.map((item) => item.color).toList(),
    );

    final styleScore = _styleEngine.calculateOutfitScore(
      items.map((item) => item.style).toList(),
    );

    final occasionScore = _occasionEngine.calculateOutfitScore(
      items: items,
      occasion: occasion,
    );

    final overall =
        (colorScore * 0.4) + (styleScore * 0.3) + (occasionScore * 0.3);

    return overall.round().clamp(0, 100);
  }
}
