import 'package:flutter/foundation.dart';

import '../../../models/clothing_item_model.dart';
import '../../../models/outfit_model.dart';
import '../data/outfit_ai_service.dart';
import '../data/outfit_repository.dart';

class OutfitController extends ChangeNotifier {
  final OutfitRepository _repository;
  final OutfitAiService _aiService;

  OutfitController({
    OutfitRepository? repository,
    OutfitAiService? aiService,
  })  : _repository = repository ?? OutfitRepository(),
        _aiService = aiService ?? OutfitAiService();

  bool _isLoading = false;
  String? _error;

  List<ClothingItemModel> _wardrobeItems = [];
  OutfitModel? _currentOutfit;
  List<OutfitModel> _history = [];

  String _selectedOccasion = 'Casual day';
  String _selectedStyle = 'Casual';

  bool get isLoading => _isLoading;
  String? get error => _error;

  List<ClothingItemModel> get wardrobeItems =>
      List.unmodifiable(_wardrobeItems);

  OutfitModel? get currentOutfit => _currentOutfit;

  List<OutfitModel> get history => List.unmodifiable(_history);

  String get selectedOccasion => _selectedOccasion;
  String get selectedStyle => _selectedStyle;

  void setOccasion(String occasion) {
    _selectedOccasion = occasion;
    notifyListeners();
  }

  void setStyle(String style) {
    _selectedStyle = style;
    notifyListeners();
  }

  Future<void> initialize() async {
    _setLoading(true);
    _error = null;

    try {
      _wardrobeItems = await _repository.getWardrobeItems();
      _history = await _repository.getOutfits();
    } catch (e) {
      _error = 'Unable to load your wardrobe.';
    } finally {
      _setLoading(false);
    }
  }

  Future<OutfitModel?> generateOutfit() async {
    _setLoading(true);
    _error = null;

    try {
      if (_wardrobeItems.isEmpty) {
        _error = 'Add some clothes to your wardrobe first.';
        return null;
      }

      final outfit = await _aiService.generateOutfit(
        wardrobeItems: _wardrobeItems,
        occasion: _selectedOccasion,
        style: _selectedStyle,
      );

      if (outfit == null) {
        _error = 'Could not create an outfit. Try again.';
        return null;
      }

      _currentOutfit = outfit;

      await _repository.saveOutfit(outfit);

      _history = [
        outfit,
        ..._history.where((item) => item.id != outfit.id),
      ];

      return outfit;
    } catch (e) {
      _error = 'Something went wrong while creating your outfit.';
      return null;
    } finally {
      _setLoading(false);
    }
  }

  Future<OutfitModel?> generateAnother() async {
    return generateOutfit();
  }

  Future<void> toggleFavorite() async {
    final outfit = _currentOutfit;

    if (outfit == null) return;

    final updated = outfit.copyWith(
      isFavorite: !outfit.isFavorite,
    );

    _currentOutfit = updated;

    _history = _history.map((item) {
      return item.id == updated.id ? updated : item;
    }).toList();

    await _repository.saveOutfit(updated);

    notifyListeners();
  }

  Future<void> replaceItem({
    required int itemIndex,
    required ClothingItemModel replacement,
  }) async {
    final outfit = _currentOutfit;

    if (outfit == null) return;
    if (itemIndex < 0 || itemIndex >= outfit.items.length) return;

    final updatedItems = List.of(outfit.items);

    final oldItem = updatedItems[itemIndex];

    updatedItems[itemIndex] = oldItem.copyWith(
      imagePath: replacement.imagePath,
      category: replacement.category,
      color: replacement.color,
    );

    final updatedOutfit = outfit.copyWith(
      items: updatedItems,
    );

    _currentOutfit = updatedOutfit;

    _history = _history.map((item) {
      return item.id == updatedOutfit.id ? updatedOutfit : item;
    }).toList();

    await _repository.saveOutfit(updatedOutfit);

    notifyListeners();
  }

  void clearCurrentOutfit() {
    _currentOutfit = null;
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }

  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }
}