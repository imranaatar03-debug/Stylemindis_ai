import 'package:flutter/material.dart';

import '../../../../core/constants/colors.dart';
import '../../../../core/constants/strings.dart';
import '../../../../core/widgets/app_card.dart';
import '../../../../models/outfit_model.dart';
import 'outfit_item.dart';

class OutfitBoard extends StatelessWidget {
  final OutfitModel outfit;
  final VoidCallback? onReplaceItem;
  final VoidCallback? onGenerateAnother;

  const OutfitBoard({
    super.key,
    required this.outfit,
    this.onReplaceItem,
    this.onGenerateAnother,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        AppCard(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      outfit.name,
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            fontWeight: FontWeight.w700,
                          ),
                    ),
                  ),
                  _CompatibilityBadge(
                    score: outfit.compatibilityScore,
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                '${outfit.style} • ${outfit.occasion}',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Theme.of(context)
                          .textTheme
                          .bodyMedium
                          ?.color
                          ?.withOpacity(0.65),
                    ),
              ),
              const SizedBox(height: 18),
              _OutfitGrid(
                outfit: outfit,
                onReplaceItem: onReplaceItem,
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: onReplaceItem,
                icon: const Icon(Icons.swap_horiz_rounded),
                label: const Text(AppStrings.replaceItem),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: FilledButton.icon(
                onPressed: onGenerateAnother,
                icon: const Icon(Icons.auto_awesome_rounded),
                label: const Text(AppStrings.generateAnother),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _OutfitGrid extends StatelessWidget {
  final OutfitModel outfit;
  final VoidCallback? onReplaceItem;

  const _OutfitGrid({
    required this.outfit,
    this.onReplaceItem,
  });

  @override
  Widget build(BuildContext context) {
    if (outfit.items.isEmpty) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(28),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: AppColors.borderLight.withOpacity(0.6),
          ),
        ),
        child: const Center(
          child: Text(AppStrings.noItems),
        ),
      );
    }

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: outfit.items.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 0.82,
      ),
      itemBuilder: (context, index) {
        final item = outfit.items[index];

        return OutfitItem(
          item: item,
          onReplace: onReplaceItem,
        );
      },
    );
  }
}

class _CompatibilityBadge extends StatelessWidget {
  final double score;

  const _CompatibilityBadge({
    required this.score,
  });

  @override
  Widget build(BuildContext context) {
    final percentage = (score * 100).round();

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 7,
      ),
      decoration: BoxDecoration(
        color: AppColors.primary.withOpacity(0.12),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: AppColors.primary.withOpacity(0.25),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(
            Icons.auto_awesome_rounded,
            size: 15,
            color: AppColors.primary,
          ),
          const SizedBox(width: 5),
          Text(
            '$percentage%',
            style: const TextStyle(
              color: AppColors.primary,
              fontWeight: FontWeight.w700,
              fontSize: 13,
            ),
          ),
        ],
      ),
    );
  }
}