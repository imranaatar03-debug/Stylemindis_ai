import 'package:flutter/material.dart';

import '../../../../core/constants/colors.dart';

class CompatibilityScore extends StatelessWidget {
  final double score;
  final bool showLabel;

  const CompatibilityScore({
    super.key,
    required this.score,
    this.showLabel = true,
  });

  double get _normalizedScore {
    if (score > 1) {
      return (score / 100).clamp(0.0, 1.0);
    }

    return score.clamp(0.0, 1.0);
  }

  int get _percentage => (_normalizedScore * 100).round();

  String get _label {
    if (_percentage >= 90) return 'Excellent';
    if (_percentage >= 75) return 'Great match';
    if (_percentage >= 60) return 'Good match';
    if (_percentage >= 40) return 'Fair match';
    return 'Needs improvement';
  }

  Color get _scoreColor {
    if (_percentage >= 90) return AppColors.success;
    if (_percentage >= 75) return AppColors.primary;
    if (_percentage >= 60) return AppColors.secondary;
    if (_percentage >= 40) return AppColors.warning;
    return AppColors.error;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          color: _scoreColor.withOpacity(0.25),
        ),
        color: _scoreColor.withOpacity(0.06),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 76,
            height: 76,
            child: Stack(
              alignment: Alignment.center,
              children: [
                SizedBox(
                  width: 76,
                  height: 76,
                  child: CircularProgressIndicator(
                    value: _normalizedScore,
                    strokeWidth: 7,
                    backgroundColor: _scoreColor.withOpacity(0.12),
                    valueColor: AlwaysStoppedAnimation<Color>(_scoreColor),
                  ),
                ),
                Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      '$_percentage%',
                      style: TextStyle(
                        color: _scoreColor,
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'AI COMPATIBILITY',
                  style: TextStyle(
                    fontSize: 11,
                    letterSpacing: 1.2,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  _label,
                  style: TextStyle(
                    color: _scoreColor,
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                if (showLabel) ...[
                  const SizedBox(height: 5),
                  Text(
                    'Based on color, style and occasion.',
                    style: TextStyle(
                      fontSize: 12,
                      color: Theme.of(context)
                          .textTheme
                          .bodyMedium
                          ?.color
                          ?.withOpacity(0.6),
                    ),
                  ),
                ],
              ],
            ),
          ),
          Icon(
            Icons.auto_awesome_rounded,
            color: _scoreColor,
            size: 24,
          ),
        ],
      ),
    );
  }
}