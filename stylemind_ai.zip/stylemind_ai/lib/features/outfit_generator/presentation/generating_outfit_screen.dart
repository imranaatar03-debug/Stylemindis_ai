import 'package:flutter/material.dart';

import '../../../core/constants/colors.dart';
import '../../../core/constants/strings.dart';
import '../../../core/widgets/loading_widget.dart';
import '../../../models/clothing_item_model.dart';
import '../../../models/outfit_model.dart';
import '../../../models/user_preferences_model.dart';
import '../data/outfit_ai_service.dart';

class GeneratingOutfitScreen extends StatefulWidget {
  final List<ClothingItemModel>? wardrobe;
  final String? occasion;
  final String? style;
  final UserPreferencesModel? preferences;

  const GeneratingOutfitScreen({
    super.key,
    this.wardrobe,
    this.occasion,
    this.style,
    this.preferences,
  });

  @override
  State<GeneratingOutfitScreen> createState() =>
      _GeneratingOutfitScreenState();
}

class _GeneratingOutfitScreenState extends State<GeneratingOutfitScreen>
    with SingleTickerProviderStateMixin {
  final OutfitAiService _outfitAIService = OutfitAiService();

  late final AnimationController _animationController;
  late final Animation<double> _pulseAnimation;

  String _statusText = 'Analyzing your wardrobe...';
  double _progress = 0.0;
  bool _isGenerating = true;

  @override
  void initState() {
    super.initState();

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat(reverse: true);

    _pulseAnimation = Tween<double>(
      begin: 0.88,
      end: 1.08,
    ).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeInOut,
      ),
    );

    _startGeneration();
  }

  Future<void> _startGeneration() async {
    final wardrobe =
        widget.wardrobe ?? <ClothingItemModel>[];

    if (wardrobe.isEmpty) {
      await Future.delayed(
        const Duration(milliseconds: 700),
      );

      if (!mounted) return;

      setState(() {
        _isGenerating = false;
        _statusText = 'Your wardrobe is empty.';
        _progress = 1.0;
      });

      return;
    }

    try {
      await _updateProgress(
        0.20,
        'Analyzing your wardrobe...',
      );

      await _updateProgress(
        0.45,
        'Matching colors and styles...',
      );

      await _updateProgress(
        0.70,
        'Building your outfit...',
      );

      final resolvedOccasion = widget.occasion ??
          (widget.preferences != null &&
                  widget.preferences!.preferredOccasions.isNotEmpty
              ? widget.preferences!.preferredOccasions.first
              : 'Casual');

      final resolvedStyle = widget.style ??
          (widget.preferences != null &&
                  widget.preferences!.preferredStyles.isNotEmpty
              ? widget.preferences!.preferredStyles.first
              : 'Casual');

      final outfit = await _outfitAIService.generateOutfit(
        wardrobeItems: wardrobe,
        occasion: resolvedOccasion,
        style: resolvedStyle,
      );

      await _updateProgress(
        0.92,
        'Finalizing your look...',
      );

      await Future.delayed(
        const Duration(milliseconds: 350),
      );

      if (!mounted) return;

      if (outfit == null) {
        setState(() {
          _isGenerating = false;
          _progress = 1.0;
          _statusText =
              'We could not create an outfit yet.';
        });
        return;
      }

      setState(() {
        _isGenerating = false;
        _progress = 1.0;
        _statusText = 'Your outfit is ready!';
      });

      await Future.delayed(
        const Duration(milliseconds: 400),
      );

      if (!mounted) return;

      Navigator.pushReplacementNamed(
        context,
        '/outfit-result',
        arguments: outfit,
      );
    } catch (_) {
      if (!mounted) return;

      setState(() {
        _isGenerating = false;
        _progress = 1.0;
        _statusText =
            'Something went wrong. Please try again.';
      });
    }
  }

  Future<void> _updateProgress(
    double value,
    String text,
  ) async {
    if (!mounted) return;

    setState(() {
      _progress = value;
      _statusText = text;
    });

    await Future.delayed(
      const Duration(milliseconds: 650),
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !_isGenerating,
      child: Scaffold(
        backgroundColor:
            Theme.of(context).scaffoldBackgroundColor,
        body: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(28),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _buildAIAnimation(),
                  const SizedBox(height: 42),
                  _buildTitle(),
                  const SizedBox(height: 14),
                  _buildStatus(),
                  const SizedBox(height: 34),
                  _buildProgress(),
                  const SizedBox(height: 18),
                  if (_isGenerating)
                    const LoadingWidget(),
                  if (!_isGenerating &&
                      _progress >= 1.0)
                    _buildCompletionIcon(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildAIAnimation() {
    return AnimatedBuilder(
      animation: _pulseAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: _pulseAnimation.value,
          child: Container(
            width: 150,
            height: 150,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [
                  AppColors.primary.withOpacity(0.32),
                  AppColors.secondary.withOpacity(0.10),
                  Colors.transparent,
                ],
              ),
            ),
            child: Center(
              child: Container(
                width: 94,
                height: 94,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      AppColors.primary,
                      AppColors.secondary,
                    ],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.primary.withOpacity(0.35),
                      blurRadius: 35,
                      spreadRadius: 4,
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.auto_awesome_rounded,
                  color: Colors.white,
                  size: 42,
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildTitle() {
    return Text(
      AppStrings.generatingOutfit,
      textAlign: TextAlign.center,
      style: Theme.of(context).textTheme.headlineSmall?.copyWith(
            fontWeight: FontWeight.w900,
          ),
    );
  }

  Widget _buildStatus() {
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 250),
      child: Text(
        _statusText,
        key: ValueKey(_statusText),
        textAlign: TextAlign.center,
        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Theme.of(context)
                  .textTheme
                  .bodyMedium
                  ?.color
                  ?.withOpacity(0.65),
            ),
      ),
    );
  }

  Widget _buildProgress() {
    return Column(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: LinearProgressIndicator(
            minHeight: 7,
            value: _progress,
            backgroundColor:
                Theme.of(context).dividerColor.withOpacity(0.15),
            valueColor:
                const AlwaysStoppedAnimation<Color>(
              AppColors.primary,
            ),
          ),
        ),
        const SizedBox(height: 9),
        Align(
          alignment: Alignment.centerRight,
          child: Text(
            '${(_progress * 100).round()}%',
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w800,
              color: AppColors.primary,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildCompletionIcon() {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 14,
        vertical: 8,
      ),
      decoration: BoxDecoration(
        color: AppColors.success.withOpacity(0.10),
        borderRadius: BorderRadius.circular(20),
      ),
      child: const Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.check_circle_rounded,
            size: 18,
            color: AppColors.success,
          ),
          SizedBox(width: 7),
          Text(
            'READY',
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w800,
              letterSpacing: 1,
              color: AppColors.success,
            ),
          ),
        ],
      ),
    );
  }
}