import 'package:flutter/material.dart';

import '../../../core/constants/colors.dart';
import '../../../core/constants/strings.dart';
import '../../../core/widgets/app_button.dart';
import '../../../core/widgets/app_card.dart';
import '../../../models/outfit_model.dart';
import '../data/outfit_repository.dart';

class OutfitResultScreen extends StatefulWidget {
  final OutfitModel? outfit;

  const OutfitResultScreen({
    super.key,
    this.outfit,
  });

  @override
  State<OutfitResultScreen> createState() =>
      _OutfitResultScreenState();
}

class _OutfitResultScreenState extends State<OutfitResultScreen> {
  final OutfitRepository _repository = OutfitRepository();

  late OutfitModel? _outfit;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _outfit = widget.outfit;
  }

  Future<void> _toggleFavorite() async {
    if (_outfit == null) return;

    setState(() {
      _outfit = _outfit!.copyWith(
        isFavorite: !_outfit!.isFavorite,
      );
    });

    await _repository.saveOutfit(_outfit!);
  }

  Future<void> _saveOutfit() async {
    if (_outfit == null || _saving) return;

    setState(() {
      _saving = true;
    });

    await _repository.saveOutfit(_outfit!);

    if (!mounted) return;

    setState(() {
      _saving = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Outfit saved successfully.'),
      ),
    );
  }

  void _generateAnother() {
    Navigator.pushReplacementNamed(
      context,
      '/create-outfit',
    );
  }

  @override
  Widget build(BuildContext context) {
    final outfit = _outfit;

    return Scaffold(
      backgroundColor:
          Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: const Text(
          AppStrings.outfitResult,
          style: TextStyle(
            fontWeight: FontWeight.w800,
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            onPressed: outfit == null
                ? null
                : _toggleFavorite,
            icon: Icon(
              outfit?.isFavorite == true
                  ? Icons.favorite_rounded
                  : Icons.favorite_border_rounded,
              color: outfit?.isFavorite == true
                  ? AppColors.accent
                  : null,
            ),
          ),
        ],
      ),
      body: outfit == null
          ? _buildEmptyState()
          : SafeArea(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(
                  20,
                  10,
                  20,
                  30,
                ),
                child: Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,
                  children: [
                    _buildHeader(outfit),
                    const SizedBox(height: 20),
                    _buildOutfitBoard(outfit),
                    const SizedBox(height: 20),
                    _buildScoreCard(outfit),
                    const SizedBox(height: 24),
                    _buildActions(),
                  ],
                ),
              ),
            ),
    );
  }

  Widget _buildHeader(OutfitModel outfit) {
    return AppCard(
      child: Row(
        children: [
          Container(
            width: 54,
            height: 54,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [
                  AppColors.primary,
                  AppColors.secondary,
                ],
              ),
              borderRadius: BorderRadius.circular(17),
            ),
            child: const Icon(
              Icons.auto_awesome_rounded,
              color: Colors.white,
              size: 27,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  outfit.name,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  '${outfit.style} • ${outfit.occasion}',
                  style: TextStyle(
                    fontSize: 13,
                    color: Theme.of(context)
                        .textTheme
                        .bodyMedium
                        ?.color
                        ?.withOpacity(0.6),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOutfitBoard(OutfitModel outfit) {
    if (outfit.items.isEmpty) {
      return AppCard(
        child: SizedBox(
          height: 220,
          child: Center(
            child: Text(
              'No clothing items in this outfit.',
              style: TextStyle(
                color: Theme.of(context)
                    .textTheme
                    .bodyMedium
                    ?.color
                    ?.withOpacity(0.6),
              ),
            ),
          ),
        ),
      );
    }

    return AppCard(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          const Text(
            'YOUR LOOK',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w800,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 14),
          GridView.builder(
            shrinkWrap: true,
            physics:
                const NeverScrollableScrollPhysics(),
            itemCount: outfit.items.length,
            gridDelegate:
                const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 0.88,
            ),
            itemBuilder: (context, index) {
              final item = outfit.items[index];

              return _OutfitItemCard(
                imagePath: item.imagePath,
                category: item.category,
                color: item.color,
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildScoreCard(OutfitModel outfit) {
    final score =
        outfit.compatibilityScore.clamp(0, 100);

    return AppCard(
      child: Row(
        children: [
          SizedBox(
            width: 72,
            height: 72,
            child: Stack(
              alignment: Alignment.center,
              children: [
                CircularProgressIndicator(
                  value: score / 100,
                  strokeWidth: 7,
                  backgroundColor:
                      Theme.of(context)
                          .dividerColor
                          .withOpacity(0.12),
                  valueColor:
                      const AlwaysStoppedAnimation<Color>(
                    AppColors.primary,
                  ),
                ),
                Text(
                  '$score%',
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                    color: AppColors.primary,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 18),
          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                const Text(
                  'AI COMPATIBILITY',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.7,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  _scoreDescription(score),
                  style: TextStyle(
                    fontSize: 13,
                    height: 1.4,
                    color: Theme.of(context)
                        .textTheme
                        .bodyMedium
                        ?.color
                        ?.withOpacity(0.65),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActions() {
    return Column(
      children: [
        AppButton(
          text: _saving
              ? 'Saving...'
              : AppStrings.saveOutfit,
          icon: Icons.bookmark_rounded,
          onPressed: _saving ? null : _saveOutfit,
        ),
        const SizedBox(height: 12),
        AppButton(
          text: AppStrings.generateAnother,
          icon: Icons.refresh_rounded,
          outlined: true,
          onPressed: _generateAnother,
        ),
      ],
    );
  }

  Widget _buildEmptyState() {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(30),
        child: Column(
          mainAxisAlignment:
              MainAxisAlignment.center,
          children: [
            Icon(
              Icons.checkroom_rounded,
              size: 70,
              color: AppColors.primary,
            ),
            SizedBox(height: 20),
            Text(
              'No outfit available',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _scoreDescription(int score) {
    if (score >= 90) {
      return 'Excellent match. Your pieces work very well together.';
    }

    if (score >= 80) {
      return 'Great match. The outfit has strong overall compatibility.';
    }

    if (score >= 70) {
      return 'Good match with a balanced combination of pieces.';
    }

    return 'A decent combination. You can try another look for more options.';
  }
}

class _OutfitItemCard extends StatelessWidget {
  final String? imagePath;
  final String category;
  final String color;

  const _OutfitItemCard({
    required this.imagePath,
    required this.category,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).scaffoldBackgroundColor,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: Theme.of(context)
              .dividerColor
              .withOpacity(0.15),
        ),
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Expanded(
            child: ClipRRect(
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(18),
              ),
              child: _buildImage(),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(
              11,
              9,
              11,
              11,
            ),
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  category,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  color,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 11,
                    color: Theme.of(context)
                        .textTheme
                        .bodyMedium
                        ?.color
                        ?.withOpacity(0.55),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildImage() {
    if (imagePath == null ||
        imagePath!.trim().isEmpty) {
      return Container(
        width: double.infinity,
        color: AppColors.primary.withOpacity(0.08),
        child: const Center(
          child: Icon(
            Icons.checkroom_rounded,
            size: 42,
            color: AppColors.primary,
          ),
        ),
      );
    }

    return Image.network(
      imagePath!,
      width: double.infinity,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) {
        return Container(
          width: double.infinity,
          color: AppColors.primary.withOpacity(0.08),
          child: const Center(
            child: Icon(
              Icons.checkroom_rounded,
              size: 42,
              color: AppColors.primary,
            ),
          ),
        );
      },
    );
  }
}