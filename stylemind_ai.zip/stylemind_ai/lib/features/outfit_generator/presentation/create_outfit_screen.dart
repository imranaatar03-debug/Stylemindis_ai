import 'package:flutter/material.dart';

import '../../../core/constants/colors.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/constants/strings.dart';
import '../../../core/widgets/app_button.dart';
import '../../../core/widgets/app_card.dart';
import '../../wardrobe/data/wardrobe_repository.dart';
import '../../../models/clothing_item_model.dart';

class CreateOutfitScreen extends StatefulWidget {
  const CreateOutfitScreen({super.key});

  @override
  State<CreateOutfitScreen> createState() => _CreateOutfitScreenState();
}

class _CreateOutfitScreenState extends State<CreateOutfitScreen> {
  final WardrobeRepository _wardrobeRepository = WardrobeRepository();

  List<ClothingItemModel> _wardrobe = [];

  String _selectedOccasion = 'Casual';
  String _selectedStyle = 'Casual';

  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadWardrobe();
  }

  Future<void> _loadWardrobe() async {
    try {
      final items = await _wardrobeRepository.getWardrobeItems();

      if (!mounted) return;

      setState(() {
        _wardrobe = items;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;

      setState(() {
        _loading = false;
      });
    }
  }

  void _generateOutfit() {
    if (_wardrobe.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Add some clothes to your wardrobe first.',
          ),
        ),
      );
      return;
    }

    Navigator.pushNamed(
      context,
      '/generating-outfit',
      arguments: {
        'wardrobe': _wardrobe,
        'occasion': _selectedOccasion,
        'style': _selectedStyle,
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: const Text(
          AppStrings.createOutfit,
          style: TextStyle(
            fontWeight: FontWeight.w800,
          ),
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: _loading
            ? const Center(
                child: CircularProgressIndicator(
                  color: AppColors.primary,
                ),
              )
            : SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(
                  20,
                  12,
                  20,
                  30,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildHeroCard(),
                    const SizedBox(height: 28),
                    _buildSectionTitle(
                      'Choose occasion',
                      'Where are you going?',
                    ),
                    const SizedBox(height: 14),
                    _buildOccasionSelector(),
                    const SizedBox(height: 28),
                    _buildSectionTitle(
                      'Choose your style',
                      'What look do you want?',
                    ),
                    const SizedBox(height: 14),
                    _buildStyleSelector(),
                    const SizedBox(height: 28),
                    _buildWardrobeInfo(),
                    const SizedBox(height: 30),
                    AppButton(
                      text: AppStrings.generateOutfit,
                      icon: Icons.auto_awesome_rounded,
                      onPressed: _generateOutfit,
                    ),
                  ],
                ),
              ),
      ),
    );
  }

  Widget _buildHeroCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(26),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            AppColors.primary.withOpacity(0.20),
            AppColors.secondary.withOpacity(0.08),
          ],
        ),
        border: Border.all(
          color: AppColors.primary.withOpacity(0.18),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 58,
            height: 58,
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.15),
              borderRadius: BorderRadius.circular(18),
            ),
            child: const Icon(
              Icons.auto_awesome_rounded,
              color: AppColors.primary,
              size: 30,
            ),
          ),
          const SizedBox(width: 16),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'AI OUTFIT GENERATOR',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.8,
                  ),
                ),
                SizedBox(height: 7),
                Text(
                  'Let AI create a look using the clothes you already own.',
                  style: TextStyle(
                    fontSize: 13,
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(
    String title,
    String subtitle,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontSize: 19,
            fontWeight: FontWeight.w800,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          subtitle,
          style: TextStyle(
            fontSize: 13,
            color: Theme.of(context)
                .textTheme
                .bodyMedium
                ?.color
                ?.withOpacity(0.58),
          ),
        ),
      ],
    );
  }

  Widget _buildOccasionSelector() {
    final occasions = AppConstants.supportedOccasions;

    return Wrap(
      spacing: 10,
      runSpacing: 10,
      children: occasions.map((occasion) {
        final selected =
            _selectedOccasion.toLowerCase() ==
                occasion.toLowerCase();

        return _SelectionChip(
          label: occasion,
          selected: selected,
          icon: _occasionIcon(occasion),
          onTap: () {
            setState(() {
              _selectedOccasion = occasion;
            });
          },
        );
      }).toList(),
    );
  }

  Widget _buildStyleSelector() {
    final styles = AppConstants.supportedStyles;

    return Wrap(
      spacing: 10,
      runSpacing: 10,
      children: styles.map((style) {
        final selected =
            _selectedStyle.toLowerCase() ==
                style.toLowerCase();

        return _SelectionChip(
          label: style,
          selected: selected,
          icon: _styleIcon(style),
          onTap: () {
            setState(() {
              _selectedStyle = style;
            });
          },
        );
      }).toList(),
    );
  }

  Widget _buildWardrobeInfo() {
    return AppCard(
      child: Row(
        children: [
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: AppColors.secondary.withOpacity(0.12),
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Icon(
              Icons.checkroom_rounded,
              color: AppColors.secondary,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'YOUR WARDROBE',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.6,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  '${_wardrobe.length} clothing items available for AI styling.',
                  style: TextStyle(
                    fontSize: 13,
                    color: Theme.of(context)
                        .textTheme
                        .bodyMedium
                        ?.color
                        ?.withOpacity(0.65),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  IconData _occasionIcon(String occasion) {
    final value = occasion.toLowerCase();

    if (value.contains('school')) {
      return Icons.school_rounded;
    }

    if (value.contains('sport')) {
      return Icons.directions_run_rounded;
    }

    if (value.contains('family')) {
      return Icons.groups_rounded;
    }

    if (value.contains('special')) {
      return Icons.star_rounded;
    }

    if (value.contains('friends')) {
      return Icons.people_alt_rounded;
    }

    return Icons.wb_sunny_rounded;
  }

  IconData _styleIcon(String style) {
    final value = style.toLowerCase();

    if (value.contains('street')) {
      return Icons.streetview_rounded;
    }

    if (value.contains('sport')) {
      return Icons.sports_soccer_rounded;
    }

    if (value.contains('minimal')) {
      return Icons.blur_on_rounded;
    }

    if (value.contains('classic')) {
      return Icons.auto_awesome_rounded;
    }

    return Icons.checkroom_rounded;
  }
}

class _SelectionChip extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  const _SelectionChip({
    required this.label,
    required this.icon,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        padding: const EdgeInsets.symmetric(
          horizontal: 14,
          vertical: 12,
        ),
        decoration: BoxDecoration(
          color: selected
              ? AppColors.primary.withOpacity(0.14)
              : Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: selected
                ? AppColors.primary
                : Theme.of(context)
                    .dividerColor
                    .withOpacity(0.25),
            width: selected ? 1.4 : 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              size: 18,
              color: selected
                  ? AppColors.primary
                  : Theme.of(context)
                      .textTheme
                      .bodyMedium
                      ?.color
                      ?.withOpacity(0.65),
            ),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                fontSize: 13,
                fontWeight:
                    selected ? FontWeight.w800 : FontWeight.w600,
                color: selected
                    ? AppColors.primary
                    : Theme.of(context)
                        .textTheme
                        .bodyMedium
                        ?.color,
              ),
            ),
          ],
        ),
      ),
    );
  }
}