class ColorMatchingEngine {
  /// Calculates how well two colors work together.
  /// Returns a score from 0 to 100.
  int calculateCompatibility(
    String firstColor,
    String secondColor,
  ) {
    final first = _normalize(firstColor);
    final second = _normalize(secondColor);

    if (first.isEmpty || second.isEmpty) {
      return 50;
    }

    if (first == second) {
      return _isNeutral(first) ? 85 : 75;
    }

    if (_isNeutral(first) || _isNeutral(second)) {
      return 95;
    }

    if (_areComplementary(first, second)) {
      return 92;
    }

    if (_areAnalogous(first, second)) {
      return 88;
    }

    if (_isEarthTone(first) && _isEarthTone(second)) {
      return 90;
    }

    if (_isWarm(first) && _isWarm(second)) {
      return 82;
    }

    if (_isCool(first) && _isCool(second)) {
      return 82;
    }

    return 60;
  }

  /// Returns the average compatibility of multiple colors.
  int calculateOutfitScore(List<String> colors) {
    if (colors.length < 2) {
      return 100;
    }

    var total = 0;
    var combinations = 0;

    for (var i = 0; i < colors.length; i++) {
      for (var j = i + 1; j < colors.length; j++) {
        total += calculateCompatibility(
          colors[i],
          colors[j],
        );
        combinations++;
      }
    }

    if (combinations == 0) {
      return 100;
    }

    return (total / combinations).round().clamp(0, 100);
  }

  /// Checks whether two colors are generally compatible.
  bool areCompatible(
    String firstColor,
    String secondColor, {
    int minimumScore = 70,
  }) {
    return calculateCompatibility(
          firstColor,
          secondColor,
        ) >=
        minimumScore;
  }

  String _normalize(String color) {
    final value = color.trim().toLowerCase();

    const aliases = {
      'grey': 'gray',
      'off white': 'white',
      'off-white': 'white',
      'ivory': 'cream',
      'tan': 'beige',
      'maroon': 'burgundy',
      'wine': 'burgundy',
      'olive green': 'olive',
      'dark blue': 'navy',
      'light blue': 'sky blue',
    };

    return aliases[value] ?? value;
  }

  bool _isNeutral(String color) {
    const neutrals = [
      'black',
      'white',
      'gray',
      'navy',
      'beige',
      'cream',
      'brown',
      'charcoal',
    ];

    return neutrals.contains(color);
  }

  bool _isEarthTone(String color) {
    const earthTones = [
      'brown',
      'beige',
      'cream',
      'olive',
      'khaki',
      'rust',
      'terracotta',
      'camel',
      'tan',
      'burgundy',
    ];

    return earthTones.contains(color);
  }

  bool _isWarm(String color) {
    const warmColors = [
      'red',
      'orange',
      'yellow',
      'coral',
      'pink',
      'burgundy',
      'rust',
      'terracotta',
    ];

    return warmColors.contains(color);
  }

  bool _isCool(String color) {
    const coolColors = [
      'blue',
      'sky blue',
      'navy',
      'cyan',
      'teal',
      'green',
      'mint',
      'purple',
      'lavender',
    ];

    return coolColors.contains(color);
  }

  bool _areComplementary(
    String first,
    String second,
  ) {
    const pairs = {
      'red': {'green', 'olive'},
      'green': {'red', 'burgundy'},
      'blue': {'orange', 'rust'},
      'orange': {'blue', 'navy'},
      'yellow': {'purple', 'lavender'},
      'purple': {'yellow'},
      'pink': {'green', 'olive'},
      'teal': {'coral', 'rust'},
    };

    return pairs[first]?.contains(second) == true ||
        pairs[second]?.contains(first) == true;
  }

  bool _areAnalogous(
    String first,
    String second,
  ) {
    const groups = [
      {
        'red',
        'burgundy',
        'pink',
        'coral',
        'orange',
        'rust',
      },
      {
        'yellow',
        'beige',
        'cream',
        'olive',
        'green',
      },
      {
        'blue',
        'sky blue',
        'navy',
        'teal',
        'cyan',
      },
      {
        'purple',
        'lavender',
        'pink',
      },
    ];

    return groups.any(
      (group) =>
          group.contains(first) &&
          group.contains(second),
    );
  }
}