import '../../../models/clothing_item_model.dart';

class OutfitEngine {
  List<ClothingItemModel> generate({
    required List<ClothingItemModel> wardrobe,
    required String occasion,
    required String style,
  }) {
    if (wardrobe.isEmpty) {
      return [];
    }

    final normalizedOccasion = occasion.toLowerCase();
    final normalizedStyle = style.toLowerCase();

    final tops = _filterByCategory(
      wardrobe,
      ['top', 'tops', 't-shirt', 'shirt', 'hoodie', 'jacket'],
    );

    final bottoms = _filterByCategory(
      wardrobe,
      ['bottom', 'bottoms', 'pants', 'jeans', 'shorts', 'cargo'],
    );

    final shoes = _filterByCategory(
      wardrobe,
      ['shoe', 'shoes', 'sneakers', 'footwear'],
    );

    final accessories = _filterByCategory(
      wardrobe,
      ['accessory', 'accessories', 'bag', 'hat'],
    );

    final selected = <ClothingItemModel>[];

    final bestTop = _chooseBestItem(
      tops,
      style: normalizedStyle,
      occasion: normalizedOccasion,
    );

    final bestBottom = _chooseBestItem(
      bottoms,
      style: normalizedStyle,
      occasion: normalizedOccasion,
    );

    final bestShoes = _chooseBestItem(
      shoes,
      style: normalizedStyle,
      occasion: normalizedOccasion,
    );

    if (bestTop != null) {
      selected.add(bestTop);
    }

    if (bestBottom != null) {
      selected.add(bestBottom);
    }

    if (bestShoes != null) {
      selected.add(bestShoes);
    }

    if (_shouldAddAccessory(normalizedStyle, normalizedOccasion) &&
        accessories.isNotEmpty) {
      final accessory = _chooseBestItem(
        accessories,
        style: normalizedStyle,
        occasion: normalizedOccasion,
      );

      if (accessory != null) {
        selected.add(accessory);
      }
    }

    // Fallback: if the wardrobe has unusual categories,
    // still return useful clothing items.
    if (selected.length < 2) {
      for (final item in wardrobe) {
        if (!selected.any((selectedItem) => selectedItem.id == item.id)) {
          selected.add(item);
        }

        if (selected.length >= 3) {
          break;
        }
      }
    }

    return selected;
  }

  List<ClothingItemModel> _filterByCategory(
    List<ClothingItemModel> wardrobe,
    List<String> categories,
  ) {
    return wardrobe.where((item) {
      final category = item.category.toLowerCase().trim();

      return categories.any(
        (value) =>
            category == value ||
            category.contains(value) ||
            value.contains(category),
      );
    }).toList();
  }

  ClothingItemModel? _chooseBestItem(
    List<ClothingItemModel> items, {
    required String style,
    required String occasion,
  }) {
    if (items.isEmpty) {
      return null;
    }

    ClothingItemModel? bestItem;
    var bestScore = -1;

    for (final item in items) {
      var score = 0;

      final itemStyle = item.style.toLowerCase();
      final itemOccasion = item.occasion.toLowerCase();
      final itemColor = item.color.toLowerCase();

      // Style compatibility.
      if (itemStyle == style) {
        score += 40;
      } else if (itemStyle.contains(style) ||
          style.contains(itemStyle)) {
        score += 25;
      }

      // Occasion compatibility.
      if (itemOccasion == occasion) {
        score += 30;
      } else if (itemOccasion.contains(occasion) ||
          occasion.contains(itemOccasion)) {
        score += 15;
      }

      // Small color bonuses for versatile colors.
      if (_isVersatileColor(itemColor)) {
        score += 10;
      }

      // Prefer items already marked as favorites.
      if (item.isFavorite) {
        score += 5;
      }

      // Prefer recently added wardrobe pieces.
      score += _recencyScore(item.createdAt);

      if (score > bestScore) {
        bestScore = score;
        bestItem = item;
      }
    }

    return bestItem;
  }

  bool _shouldAddAccessory(
    String style,
    String occasion,
  ) {
    if (style == 'streetwear' ||
        style == 'classic' ||
        style == 'minimal') {
      return true;
    }

    if (occasion == 'friends' ||
        occasion == 'special event') {
      return true;
    }

    return false;
  }

  bool _isVersatileColor(String color) {
    const versatileColors = [
      'black',
      'white',
      'grey',
      'gray',
      'navy',
      'beige',
      'cream',
      'brown',
    ];

    return versatileColors.any(
      (value) => color.contains(value),
    );
  }

  int _recencyScore(DateTime createdAt) {
    final daysSinceCreated =
        DateTime.now().difference(createdAt).inDays;

    if (daysSinceCreated <= 7) {
      return 5;
    }

    if (daysSinceCreated <= 30) {
      return 3;
    }

    return 0;
  }
}