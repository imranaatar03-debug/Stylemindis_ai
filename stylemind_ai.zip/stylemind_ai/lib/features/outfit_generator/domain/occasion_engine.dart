import '../../../models/clothing_item_model.dart';

class OccasionEngine {
  /// Calculates how suitable a clothing item is for an occasion.
  /// Returns a score from 0 to 100.
  int calculateItemScore({
    required ClothingItemModel item,
    required String occasion,
  }) {
    final itemOccasion = _normalize(item.occasion);
    final requestedOccasion = _normalize(occasion);

    if (itemOccasion.isEmpty || requestedOccasion.isEmpty) {
      return 50;
    }

    if (itemOccasion == requestedOccasion) {
      return 100;
    }

    final compatibleOccasions =
        _compatibleOccasions[requestedOccasion] ?? {};

    if (compatibleOccasions.contains(itemOccasion)) {
      return 85;
    }

    // Clothing marked as "casual" is reasonably versatile.
    if (itemOccasion == 'casual') {
      return 75;
    }

    return 50;
  }

  /// Sorts wardrobe items according to their suitability
  /// for the requested occasion.
  List<ClothingItemModel> rankItems({
    required List<ClothingItemModel> wardrobe,
    required String occasion,
  }) {
    final ranked = List<ClothingItemModel>.from(wardrobe);

    ranked.sort((a, b) {
      final scoreA = calculateItemScore(
        item: a,
        occasion: occasion,
      );

      final scoreB = calculateItemScore(
        item: b,
        occasion: occasion,
      );

      return scoreB.compareTo(scoreA);
    });

    return ranked;
  }

  /// Calculates the overall occasion score of an outfit.
  int calculateOutfitScore({
    required List<ClothingItemModel> items,
    required String occasion,
  }) {
    if (items.isEmpty) {
      return 0;
    }

    final scores = items.map(
      (item) => calculateItemScore(
        item: item,
        occasion: occasion,
      ),
    );

    final total = scores.fold<int>(
      0,
      (sum, score) => sum + score,
    );

    return (total / items.length).round().clamp(0, 100);
  }

  /// Returns true when an item is suitable enough
  /// for the requested occasion.
  bool isSuitable({
    required ClothingItemModel item,
    required String occasion,
    int minimumScore = 70,
  }) {
    return calculateItemScore(
          item: item,
          occasion: occasion,
        ) >=
        minimumScore;
  }

  String _normalize(String occasion) {
    final value = occasion.trim().toLowerCase();

    const aliases = {
      'school day': 'school',
      'school': 'school',
      'casual day': 'casual',
      'casual': 'casual',
      'friends': 'friends',
      'friends outing': 'friends',
      'family': 'family event',
      'family event': 'family event',
      'sport': 'sport',
      'sports': 'sport',
      'special': 'special event',
      'special event': 'special event',
    };

    return aliases[value] ?? value;
  }

  static const Map<String, Set<String>> _compatibleOccasions = {
    'school': {
      'casual',
      'friends',
    },
    'casual': {
      'school',
      'friends',
      'family event',
    },
    'friends': {
      'casual',
      'school',
      'family event',
    },
    'family event': {
      'casual',
      'friends',
      'special event',
    },
    'sport': {
      'casual',
    },
    'special event': {
      'family event',
    },
  };
}