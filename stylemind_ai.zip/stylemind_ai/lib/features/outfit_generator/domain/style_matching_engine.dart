class StyleMatchingEngine {
  /// Calculates how well two styles work together.
  /// Returns a score from 0 to 100.
  int calculateCompatibility(
    String firstStyle,
    String secondStyle,
  ) {
    final first = _normalize(firstStyle);
    final second = _normalize(secondStyle);

    if (first.isEmpty || second.isEmpty) {
      return 50;
    }

    if (first == second) {
      return 100;
    }

    if (_compatiblePairs[first]?.contains(second) == true ||
        _compatiblePairs[second]?.contains(first) == true) {
      return 90;
    }

    if (_neutralStyles.contains(first) ||
        _neutralStyles.contains(second)) {
      return 82;
    }

    return 60;
  }

  /// Calculates the overall style score for an outfit.
  int calculateOutfitScore(List<String> styles) {
    final validStyles = styles
        .map(_normalize)
        .where((style) => style.isNotEmpty)
        .toList();

    if (validStyles.length < 2) {
      return 100;
    }

    var total = 0;
    var combinations = 0;

    for (var i = 0; i < validStyles.length; i++) {
      for (var j = i + 1; j < validStyles.length; j++) {
        total += calculateCompatibility(
          validStyles[i],
          validStyles[j],
        );
        combinations++;
      }
    }

    if (combinations == 0) {
      return 100;
    }

    return (total / combinations).round().clamp(0, 100);
  }

  /// Returns true when the two styles meet the minimum score.
  bool areCompatible(
    String firstStyle,
    String secondStyle, {
    int minimumScore = 70,
  }) {
    return calculateCompatibility(
          firstStyle,
          secondStyle,
        ) >=
        minimumScore;
  }

  /// Gives a style score based on the requested style.
  int matchRequestedStyle({
    required String itemStyle,
    required String requestedStyle,
  }) {
    final item = _normalize(itemStyle);
    final requested = _normalize(requestedStyle);

    if (item.isEmpty || requested.isEmpty) {
      return 50;
    }

    if (item == requested) {
      return 100;
    }

    if (_compatiblePairs[item]?.contains(requested) == true ||
        _compatiblePairs[requested]?.contains(item) == true) {
      return 85;
    }

    if (_neutralStyles.contains(item)) {
      return 80;
    }

    return 55;
  }

  String _normalize(String style) {
    final value = style.trim().toLowerCase();

    const aliases = {
      'street': 'streetwear',
      'street wear': 'streetwear',
      'sport': 'sporty',
      'sports': 'sporty',
        'classic style': 'classic',
      'minimalist': 'minimal',
      'casual style': 'casual',
    };

    return aliases[value] ?? value;
  }

  static const Set<String> _neutralStyles = {
    'minimal',
    'classic',
    'casual',
  };

  static const Map<String, Set<String>> _compatiblePairs = {
    'casual': {
      'streetwear',
      'sporty',
      'minimal',
    },
    'streetwear': {
      'casual',
      'sporty',
    },
    'sporty': {
      'casual',
      'streetwear',
    },
    'minimal': {
      'casual',
      'classic',
    },
    'classic': {
      'minimal',
      'casual',
    },
  };
}