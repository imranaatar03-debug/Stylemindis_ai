import 'package:flutter/material.dart';

import '../../../core/constants/colors.dart';
import '../../../core/constants/strings.dart';
import '../../../core/widgets/app_button.dart';
import '../../../core/widgets/app_card.dart';
import 'style_preferences_controller.dart';

class ColorPreferencesScreen extends StatefulWidget {
  const ColorPreferencesScreen({super.key});

  @override
  State<ColorPreferencesScreen> createState() =>
      _ColorPreferencesScreenState();
}

class _ColorPreferencesScreenState extends State<ColorPreferencesScreen> {
  final List<String> colors = [
    'Black',
    'White',
    'Gray',
    'Navy',
    'Blue',
    'Red',
    'Green',
    'Brown',
    'Beige',
    'Cream',
    'Pink',
    'Purple',
    'Orange',
    'Yellow',
  ];

  final Set<String> selectedColors = {};
  final Set<String> dislikedColors = {};

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text(AppStrings.colorPreferences),
        centerTitle: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                AppStrings.chooseFavoriteColors,
                style: theme.textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 8),

              Text(
                AppStrings.colorPreferencesSubtitle,
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onSurface.withOpacity(0.65),
                ),
              ),

              const SizedBox(height: 28),

              Text(
                AppStrings.favoriteColors,
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 14),

              Wrap(
                spacing: 10,
                runSpacing: 10,
                children: colors.map((color) {
                  final selected = selectedColors.contains(color);

                  return ChoiceChip(
                    label: Text(color),
                    selected: selected,
                    onSelected: (_) {
                      setState(() {
                        if (selected) {
                          selectedColors.remove(color);
                        } else {
                          selectedColors.add(color);
                          dislikedColors.remove(color);
                        }
                      });
                    },
                    selectedColor: AppColors.primary.withOpacity(0.2),
                    checkmarkColor: AppColors.primary,
                    labelStyle: TextStyle(
                      color: selected
                          ? AppColors.primary
                          : theme.colorScheme.onSurface,
                      fontWeight:
                          selected ? FontWeight.w600 : FontWeight.normal,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  );
                }).toList(),
              ),

              const SizedBox(height: 32),

              Text(
                AppStrings.dislikedColors,
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 8),

              Text(
                'Select colors you prefer to avoid.',
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onSurface.withOpacity(0.6),
                ),
              ),

              const SizedBox(height: 14),

              ...colors.map((color) {
                final selected = dislikedColors.contains(color);

                return Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: AppCard(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 13,
                    ),
                    onTap: () {
                      setState(() {
                        if (selected) {
                          dislikedColors.remove(color);
                        } else {
                          dislikedColors.add(color);
                          selectedColors.remove(color);
                        }
                      });
                    },
                    child: Row(
                      children: [
                        Icon(
                          selected
                              ? Icons.remove_circle
                              : Icons.add_circle_outline,
                          color: selected
                              ? AppColors.accent
                              : theme.colorScheme.onSurface
                                  .withOpacity(0.45),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            color,
                            style: theme.textTheme.bodyLarge?.copyWith(
                              fontWeight: selected
                                  ? FontWeight.w600
                                  : FontWeight.normal,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }),

              const SizedBox(height: 20),

              AppButton(
                text: AppStrings.savePreferences,
                icon: Icons.check_rounded,
                fullWidth: true,
                onPressed: () async {
                  final controller = StylePreferencesController();

                  await controller.saveColorPreferences(
                    favoriteColors: selectedColors.toList(),
                    dislikedColors: dislikedColors.toList(),
                  );

                  if (!mounted) return;

                  Navigator.pop(context);
                },
              ),

              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}