import 'package:flutter/foundation.dart';

import '../../../core/services/storage_service.dart';
import '../../../models/user_preferences_model.dart';

class StylePreferencesController extends ChangeNotifier {
  final StorageService _storage = StorageService();

  UserPreferencesModel _preferences = const UserPreferencesModel();

  UserPreferencesModel get preferences => _preferences;

  Future<void> initialize() async {
    final data = await _storage.getJson('user_preferences');

    if (data != null) {
      _preferences = UserPreferencesModel.fromJson(data);
      notifyListeners();
    }
  }

  Future<void> savePreferences({
    List<String>? preferredStyles,
    List<String>? preferredColors,
    List<String>? dislikedColors,
    List<String>? preferredOccasions,
    List<String>? favoriteBrands,
    List<String>? preferredCategories,
    String? preferredSeason,
    String? preferredFit,
    bool? useWeatherRecommendations,
    bool? useAiVisualization,
    bool? notificationsEnabled,
    bool? personalizedRecommendations,
  }) async {
    _preferences = _preferences.copyWith(
      preferredStyles: preferredStyles,
      preferredColors: preferredColors,
      dislikedColors: dislikedColors,
      preferredOccasions: preferredOccasions,
      favoriteBrands: favoriteBrands,
      preferredCategories: preferredCategories,
      preferredSeason: preferredSeason,
      preferredFit: preferredFit,
      useWeatherRecommendations: useWeatherRecommendations,
      useAiVisualization: useAiVisualization,
      notificationsEnabled: notificationsEnabled,
      personalizedRecommendations: personalizedRecommendations,
    );

    await _storage.setJson(
      'user_preferences',
      _preferences.toJson(),
    );

    notifyListeners();
  }

  Future<void> saveColorPreferences({
    required List<String> favoriteColors,
    required List<String> dislikedColors,
  }) async {
    await savePreferences(
      preferredColors: favoriteColors,
      dislikedColors: dislikedColors,
    );
  }

  Future<void> saveStylePreferences({
    required List<String> styles,
    required List<String> occasions,
  }) async {
    await savePreferences(
      preferredStyles: styles,
      preferredOccasions: occasions,
    );
  }

  Future<void> setWeatherRecommendations(bool enabled) async {
    await savePreferences(
      useWeatherRecommendations: enabled,
    );
  }

  Future<void> setAiVisualization(bool enabled) async {
    await savePreferences(
      useAiVisualization: enabled,
    );
  }

  Future<void> setNotifications(bool enabled) async {
    await savePreferences(
      notificationsEnabled: enabled,
    );
  }

  Future<void> setPersonalizedRecommendations(bool enabled) async {
    await savePreferences(
      personalizedRecommendations: enabled,
    );
  }

  Future<void> clearPreferences() async {
    _preferences = const UserPreferencesModel();

    await _storage.remove('user_preferences');

    notifyListeners();
  }
}