import 'package:flutter/foundation.dart';

import '../../../core/services/storage_service.dart';

class OnboardingController extends ChangeNotifier {
  final StorageService _storageService = StorageService();

  bool _isCompleted = false;
  bool _isLoading = false;

  bool get isCompleted => _isCompleted;
  bool get isLoading => _isLoading;

  Future<void> initialize() async {
    _isLoading = true;
    notifyListeners();

    _isCompleted = await _storageService.isOnboardingCompleted();

    _isLoading = false;
    notifyListeners();
  }

  Future<void> completeOnboarding() async {
    _isLoading = true;
    notifyListeners();

    await _storageService.setOnboardingCompleted(true);

    _isCompleted = true;
    _isLoading = false;

    notifyListeners();
  }

  Future<void> resetOnboarding() async {
    _isLoading = true;
    notifyListeners();

    await _storageService.setOnboardingCompleted(false);

    _isCompleted = false;
    _isLoading = false;

    notifyListeners();
  }
}