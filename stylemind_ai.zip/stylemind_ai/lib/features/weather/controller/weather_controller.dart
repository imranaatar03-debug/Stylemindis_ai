import 'package:flutter/foundation.dart';

import '../../../models/weather_model.dart';
import '../data/weather_service.dart';

class WeatherController extends ChangeNotifier {
  final FeatureWeatherService _weatherService;

  WeatherController({
    FeatureWeatherService? weatherService,
  }) : _weatherService =
            weatherService ?? FeatureWeatherService();

  WeatherModel? _weather;
  bool _isLoading = false;
  String? _error;
  String? _city;

  WeatherModel? get weather => _weather;

  bool get isLoading => _isLoading;

  String? get error => _error;

  String? get city => _city;

  bool get hasWeather => _weather != null;

  Future<void> loadWeather({
    required double latitude,
    required double longitude,
  }) async {
    _setLoading(true);
    _error = null;

    try {
      final result = await _weatherService.getWeather(
        latitude: latitude,
        longitude: longitude,
      );

      if (result == null) {
        _error = 'Unable to load weather data.';
      } else {
        _weather = result;
        _city = null;
      }
    } catch (_) {
      _error = 'Unable to load weather data.';
    } finally {
      _setLoading(false);
    }
  }

  Future<void> loadWeatherForCity(String city) async {
    final trimmedCity = city.trim();

    if (trimmedCity.isEmpty) {
      _error = 'Please enter a city name.';
      notifyListeners();
      return;
    }

    _setLoading(true);
    _error = null;

    try {
      final result =
          await _weatherService.getWeatherForCity(
        trimmedCity,
      );

      if (result == null) {
        _error = 'Weather data was not found for this city.';
      } else {
        _weather = result;
        _city = trimmedCity;
      }
    } catch (_) {
      _error = 'Unable to load weather data.';
    } finally {
      _setLoading(false);
    }
  }

  void clearWeather() {
    _weather = null;
    _city = null;
    _error = null;
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }

  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }
}