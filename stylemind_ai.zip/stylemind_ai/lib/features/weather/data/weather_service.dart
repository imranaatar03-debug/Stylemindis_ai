import '../../../core/services/weather_service.dart';
import '../../../models/weather_model.dart';

class FeatureWeatherService {
  final WeatherService _weatherService;

  FeatureWeatherService({
    WeatherService? weatherService,
  }) : _weatherService = weatherService ?? WeatherService();

  Future<WeatherModel?> getWeather({
    required double latitude,
    required double longitude,
  }) async {
    try {
      return await _weatherService.getWeather(
        latitude: latitude,
        longitude: longitude,
      );
    } catch (_) {
      return null;
    }
  }

  Future<WeatherModel?> getWeatherForCity(
    String city,
  ) async {
    try {
      return await _weatherService.getWeatherByCity(city);
    } catch (_) {
      return null;
    }
  }
}