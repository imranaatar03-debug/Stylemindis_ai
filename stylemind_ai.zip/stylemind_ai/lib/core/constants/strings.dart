class AppStrings {
  AppStrings._();

  // ========================================
  // APP
  // ========================================

  static const String appName = 'STYLEMIND AI';

  static const String appTagline =
      'Your Wardrobe. Your Style. Powered by AI.';

  static const String shortTagline =
      'Your Clothes. Smarter Style.';

  // ========================================
  // SPLASH
  // ========================================

  static const String splashTitle =
      'STYLEMIND AI';

  static const String splashSubtitle =
      'Your Personal AI Stylist';

  // ========================================
  // ONBOARDING
  // ========================================

  static const String onboardingTitle1 =
      'Your Personal AI Stylist';

  static const String onboardingDescription1 =
      'Discover better outfits using the clothes you already own.';

  static const String onboardingTitle2 =
      'Scan Your Clothes';

  static const String onboardingDescription2 =
      'Use your camera to build your smart digital wardrobe.';

  static const String onboardingTitle3 =
      'Create Your Perfect Outfit';

  static const String onboardingDescription3 =
      'Let AI combine your clothes into stylish outfits made for you.';

  static const String skip =
      'SKIP';

  static const String next =
      'NEXT';

  static const String getStarted =
      'GET STARTED';

  // ========================================
  // AUTHENTICATION
  // ========================================

  static const String welcomeBack =
      'Welcome Back';

  static const String createYourAccount =
      'Create Your Account';

  static const String login =
      'Log In';

  static const String signUp =
      'Create Account';

  static const String email =
      'Email';

  static const String password =
      'Password';

  static const String confirmPassword =
      'Confirm Password';

  static const String forgotPassword =
      'Forgot Password?';

  static const String continueWithGoogle =
      'Continue with Google';

  static const String continueWithApple =
      'Continue with Apple';

  static const String continueWithEmail =
      'Continue with Email';

  static const String dontHaveAccount =
      "Don't have an account?";

  static const String alreadyHaveAccount =
      'Already have an account?';

  // ========================================
  // STYLE PROFILE
  // ========================================

  static const String discoverYourStyle =
      "Let's Discover Your Style";

  static const String chooseYourStyles =
      'Choose the styles that feel like you.';

  static const String favoriteColors =
      'Your Favorite Colors';

  static const String chooseYourColors =
      'Select the colors you enjoy wearing.';

  static const String noPreference =
      'NO PREFERENCE';

  static const String continueText =
      'CONTINUE';

  // ========================================
  // STYLES
  // ========================================

  static const String casual =
      'Casual';

  static const String streetwear =
      'Streetwear';

  static const String sporty =
      'Sporty';

  static const String minimal =
      'Minimal';

  static const String classic =
      'Classic';

  static const String smartCasual =
      'Smart Casual';

  // ========================================
  // HOME
  // ========================================

  static const String goodMorning =
      'Good Morning 👋';

  static const String goodAfternoon =
      'Good Afternoon 👋';

  static const String goodEvening =
      'Good Evening 👋';

  static const String readyForOutfit =
      'Ready to find your perfect outfit?';

  static const String createMyOutfit =
      'CREATE MY OUTFIT';

  static const String quickActions =
      'QUICK ACTIONS';

  static const String recentOutfits =
      'RECENT OUTFITS';

  static const String styleInsights =
      'STYLE INSIGHTS';

  static const String wardrobeSummary =
      'WARDROBE SUMMARY';

  static const String surpriseMe =
      'SURPRISE ME';

  // ========================================
  // CAMERA
  // ========================================

  static const String aiStyleScan =
      'AI STYLE SCAN';

  static const String doesThisMatch =
      'DOES THIS MATCH?';

  static const String scanYourClothes =
      'Scan your clothes';

  static const String capture =
      'CAPTURE';

  static const String autoScan =
      'AUTO SCAN';

  static const String flash =
      'FLASH';

  static const String cameraSwitch =
      'SWITCH CAMERA';

  static const String scanning =
      'Scanning...';

  static const String analyzing =
      'Analyzing...';

  static const String clothingDetected =
      'Clothing Detected';

  static const String addToWardrobe =
      'ADD TO WARDROBE';

  static const String editDetails =
      'EDIT DETAILS';

  static const String scanAgain =
      'SCAN AGAIN';

  // ========================================
  // WARDROBE
  // ========================================

  static const String myWardrobe =
      'MY WARDROBE';

  static const String all =
      'ALL';

  static const String tops =
      'TOPS';

  static const String bottoms =
      'BOTTOMS';

  static const String shoes =
      'SHOES';

  static const String outerwear =
      'OUTERWEAR';

  static const String accessories =
      'ACCESSORIES';

  static const String addItem =
      'ADD ITEM';

  static const String scanWithCamera =
      'SCAN WITH CAMERA';

  static const String uploadPhoto =
      'UPLOAD PHOTO';

  static const String editClothing =
      'EDIT CLOTHING';

  static const String deleteClothing =
      'DELETE CLOTHING';

  static const String wardrobeEmpty =
      'Your wardrobe is empty';

  static const String startAddingClothes =
      'Start adding clothes to build your smart wardrobe.';

  // ========================================
  // OUTFIT GENERATOR
  // ========================================

  static const String createYourOutfit =
      'Create Your Outfit';

  static const String whereAreYouGoing =
      'Where are you going?';

  static const String chooseYourStyle =
      'Choose Your Style';

  static const String generateWithAI =
      'GENERATE WITH AI';

  static const String aiAnalyzingWardrobe =
      'AI is analyzing your wardrobe...';

  static const String findingBestCombinations =
      'Finding the best combinations...';

  static const String creatingYourLook =
      'Creating your look...';

  // ========================================
  // OCCASIONS
  // ========================================

  static const String school =
      'School';

  static const String casualDay =
      'Casual Day';

  static const String friends =
      'Friends';

  static const String familyEvent =
      'Family Event';

  static const String sport =
      'Sport';

  static const String specialEvent =
      'Special Event';

  // ========================================
  // OUTFIT RESULT
  // ========================================

  static const String outfit =
      'OUTFIT';

  static const String top =
      'TOP';

  static const String bottom =
      'BOTTOM';

  static const String shoe =
      'SHOES';

  static const String jacket =
      'JACKET';

  static const String optional =
      'OPTIONAL';

  static const String styleScore =
      'STYLE SCORE';

  static const String whyThisWorks =
      'WHY THIS WORKS';

  static const String saveOutfit =
      'SAVE OUTFIT';

  static const String generateAnother =
      'GENERATE ANOTHER';

  static const String changeItem =
      'CHANGE ITEM';

  static const String share =
      'SHARE';

  static const String moreAIOutfits =
      'MORE AI OUTFITS';

  // ========================================
  // MATCHING
  // ========================================

  static const String checkingYourWardrobe =
      'Checking your wardrobe...';

  static const String bestMatches =
      'BEST MATCHES';

  static const String matchesWellWith =
      'matches well with';

  static const String createCompleteOutfit =
      'CREATE COMPLETE OUTFIT';

  // ========================================
  // AI CHAT
  // ========================================

  static const String styleMindAI =
      'STYLEMIND AI';

  static const String personalStyleAssistant =
      'Your Personal Style Assistant';

  static const String whatShouldIWear =
      'What should I wear today?';

  static const String whatMatchesMySneakers =
      'What matches my white sneakers?';

  static const String createSchoolOutfit =
      'Create a school outfit.';

  static const String giveMeStreetwear =
      'Give me a streetwear outfit.';

  // ========================================
  // CALENDAR
  // ========================================

  static const String outfitCalendar =
      'OUTFIT CALENDAR';

  static const String planYourOutfits =
      'Plan your outfits';

  static const String selectDay =
      'Select a day';

  static const String planOutfit =
      'PLAN OUTFIT';

  // ========================================
  // FAVORITES
  // ========================================

  static const String favorites =
      'FAVORITES';

  static const String favoriteOutfits =
      'Favorite Outfits';

  static const String createSimilar =
      'CREATE SIMILAR OUTFIT';

  // ========================================
  // PROFILE
  // ========================================

  static const String profile =
      'PROFILE';

  static const String myStyle =
      'MY STYLE';

  static const String colorPreferences =
      'COLOR PREFERENCES';

  static const String notifications =
      'NOTIFICATIONS';

  static const String privacy =
      'PRIVACY';

  static const String cameraPermissions =
      'CAMERA PERMISSIONS';

  static const String settings =
      'SETTINGS';

  // ========================================
  // PRIVACY
  // ========================================

  static const String privacyTitle =
      'Your Privacy Matters';

  static const String privacyDescription =
      'Your photos and wardrobe data are under your control.';

  static const String deletePhotos =
      'DELETE UPLOADED PHOTOS';

  static const String deleteWardrobe =
      'DELETE WARDROBE';

  static const String deleteAccount =
      'DELETE ACCOUNT DATA';

  // ========================================
  // WEATHER
  // ========================================

  static const String weather =
      'WEATHER';

  static const String weatherRecommendations =
      'Weather-based recommendations';

  static const String lightweightClothing =
      'Lightweight clothing';

  static const String jacketRecommendation =
      'A jacket may be useful today';

  static const String rainRecommendation =
      'Consider weather-friendly shoes';

  // ========================================
  // COMMON
  // ========================================

  static const String save =
      'SAVE';

  static const String cancel =
      'CANCEL';

  static const String delete =
      'DELETE';

  static const String edit =
      'EDIT';

  static const String close =
      'CLOSE';

  static const String done =
      'DONE';

  static const String retry =
      'RETRY';

  static const String loading =
      'Loading...';

  static const String somethingWentWrong =
      'Something went wrong. Please try again.';

  // ========================================
  // NAVIGATION LABELS
  // ========================================

  static const String home = 'Home';

  static const String wardrobe = 'Wardrobe';

  static const String outfits = 'Outfits';

  static const String styleProfile = 'Style Profile';

  static const String seeAll = 'See all';

  // ========================================
  // AUTH
  // ========================================

  static const String loginSubtitle =
      'Welcome back. Sign in to continue.';

  static const String signupSubtitle =
      'Create an account to build your smart wardrobe.';

  static const String createAccount = 'CREATE ACCOUNT';

  static const String signup = 'Sign up';

  static const String name = 'Name';

  static const String nameHint = 'Enter your full name';

  static const String nameRequired = 'Please enter your name.';

  static const String nameTooShort =
      'Name must be at least 2 characters.';

  static const String emailHint = 'Enter your email';

  static const String emailRequired = 'Please enter your email.';

  static const String invalidEmail =
      'Please enter a valid email address.';

  static const String passwordHint = 'Enter your password';

  static const String passwordRequired =
      'Please enter your password.';

  static const String passwordTooShort =
      'Password must be at least 6 characters.';

  static const String confirmPasswordHint = 'Confirm your password';

  static const String confirmPasswordRequired =
      'Please confirm your password.';

  static const String passwordsDoNotMatch =
      'Passwords do not match.';

  static const String invalidCredentials =
      'Incorrect email or password.';

  static const String accountAlreadyExists =
      'An account with this email already exists.';

  static const String backToLogin = 'Back to login';

  static const String forgotPasswordTitle = 'Forgot Password?';

  static const String forgotPasswordSubtitle =
      'Enter your email and we will send you a reset link.';

  static const String sendResetLink = 'SEND RESET LINK';

  static const String resetEmailSent =
      'A password reset link has been sent to your email.';

  static const String emailNotFound =
      'No account was found with this email.';

  // ========================================
  // ONBOARDING (GENERIC)
  // ========================================

  static const String onboardingTitle = 'Welcome to STYLEMIND AI';

  static const String onboardingDescription =
      'Your wardrobe, your style, powered by AI.';

  // ========================================
  // WARDROBE (ADDITIONAL)
  // ========================================

  static const String addClothing = 'ADD CLOTHING';

  static const String emptyWardrobe = 'Your wardrobe is empty';

  static const String emptyWardrobeDescription =
      'Start adding clothes to build your smart wardrobe.';

  static const String noItems = 'No items found';

  // ========================================
  // OUTFIT GENERATOR (ADDITIONAL)
  // ========================================

  static const String generateOutfit = 'GENERATE OUTFIT';

  static const String generatingOutfit = 'Generating your outfit...';

  static const String outfitResult = 'Outfit Result';

  static const String replaceItem = 'REPLACE ITEM';

  // ========================================
  // AI CAMERA (ADDITIONAL)
  // ========================================

  static const String aiDetectedClothing = 'AI Detected Clothing';

  static const String detectedItems = 'Detected Items';

  static const String itemAddedToWardrobe =
      'Item added to your wardrobe.';

  // ========================================
  // OUTFITS / HISTORY / FAVORITES (ADDITIONAL)
  // ========================================

  static const String outfitHistory = 'Outfit History';

  static const String history = 'History';

  static const String removeFromFavorites = 'Remove from favorites';

  static const String createOutfit = 'CREATE OUTFIT';

  // ========================================
  // STYLE PROFILE (ADDITIONAL)
  // ========================================

  static const String styleProfileSubtitle =
      'Tell us about your style so we can personalize your outfits.';

  static const String preferredStyle = 'Preferred Style';

  static const String preferredOccasion = 'Preferred Occasion';

  static const String yourStyle = 'Your Style';

  static const String chooseFavoriteColors =
      'Choose your favorite colors';

  static const String colorPreferencesSubtitle =
      'Select the colors you love and the ones you prefer to avoid.';

  static const String dislikedColors = 'Disliked Colors';

  static const String savePreferences = 'SAVE PREFERENCES';
}