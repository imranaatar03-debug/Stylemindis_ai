import 'package:flutter/material.dart';

class AppColors {
  AppColors._();

  // ========================================
  // BRAND COLORS
  // ========================================

  static const Color primary =
      Color(0xFF7C6CFF);

  static const Color primaryLight =
      Color(0xFFA89DFF);

  static const Color primaryDark =
      Color(0xFF5A4BD6);

  static const Color secondary =
      Color(0xFF00D4FF);

  static const Color accent =
      Color(0xFFFF4FD8);

  // ========================================
  // AI COLORS
  // ========================================

  static const Color aiGlow =
      Color(0xFF8B7CFF);

  static const Color aiGlowLight =
      Color(0xFFB9B0FF);

  static const Color aiScan =
      Color(0xFF00E5FF);

  static const Color aiSuccess =
      Color(0xFF36D399);

  // ========================================
  // DARK MODE
  // ========================================

  static const Color darkBackground =
      Color(0xFF090A0F);

  static const Color darkSurface =
      Color(0xFF12141C);

  static const Color darkCard =
      Color(0xFF191B25);

  static const Color darkCardLight =
      Color(0xFF222531);

  static const Color darkBorder =
      Color(0xFF2A2D3A);

  // ========================================
  // LIGHT MODE
  // ========================================

  static const Color lightBackground =
      Color(0xFFF7F7FA);

  static const Color lightSurface =
      Color(0xFFFFFFFF);

  static const Color lightCard =
      Color(0xFFFFFFFF);

  static const Color lightBorder =
      Color(0xFFE8E8EF);

  // ========================================
  // TEXT COLORS
  // ========================================

  static const Color textPrimaryDark =
      Color(0xFFFFFFFF);

  static const Color textSecondaryDark =
      Color(0xFFA6A8B5);

  static const Color textMutedDark =
      Color(0xFF6F7280);

  static const Color textPrimaryLight =
      Color(0xFF161720);

  static const Color textSecondaryLight =
      Color(0xFF6E7180);

  static const Color textMutedLight =
      Color(0xFF9B9EAA);

  // ========================================
  // GENERIC ALIASES (used across light/dark widgets)
  // ========================================

  static const Color darkText = textPrimaryDark;

  static const Color darkSecondaryText = textSecondaryDark;

  static const Color lightText = textPrimaryLight;

  static const Color lightSecondaryText = textSecondaryLight;

  static const Color border = lightBorder;

  static const Color borderLight = lightBorder;

  static const Color cardLight = lightCard;

  // ========================================
  // STATUS COLORS
  // ========================================

  static const Color success =
      Color(0xFF22C55E);

  static const Color warning =
      Color(0xFFF59E0B);

  static const Color error =
      Color(0xFFEF4444);

  static const Color info =
      Color(0xFF3B82F6);

  // ========================================
  // COMMON COLORS
  // ========================================

  static const Color white =
      Color(0xFFFFFFFF);

  static const Color black =
      Color(0xFF000000);

  static const Color transparent =
      Colors.transparent;
}