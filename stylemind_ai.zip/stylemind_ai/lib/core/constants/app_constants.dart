class AppConstants {
  AppConstants._();

  // ========================================
  // APP INFORMATION
  // ========================================

  static const String appName = 'STYLEMIND AI';

  static const String appVersion = '1.0.0';

  static const String appBuild = '1';

  // ========================================
  // DESIGN
  // ========================================

  static const double defaultBorderRadius = 20.0;

  static const double smallBorderRadius = 12.0;

  static const double largeBorderRadius = 28.0;

  static const double cardPadding = 16.0;

  static const double screenPadding = 20.0;

  static const double sectionSpacing = 28.0;

  static const double itemSpacing = 12.0;

  // ========================================
  // ANIMATIONS
  // ========================================

  static const Duration fastAnimation =
      Duration(milliseconds: 180);

  static const Duration normalAnimation =
      Duration(milliseconds: 300);

  static const Duration slowAnimation =
      Duration(milliseconds: 600);

  static const Duration pageTransition =
      Duration(milliseconds: 350);

  // ========================================
  // ONBOARDING
  // ========================================

  static const int onboardingPages = 3;

  // ========================================
  // WARDROBE
  // ========================================

  static const int maxWardrobeItems = 500;

  static const int wardrobeGridColumns = 2;

  // ========================================
  // OUTFITS
  // ========================================

  static const int minGeneratedOutfits = 3;

  static const int maxGeneratedOutfits = 5;

  // ========================================
  // IMAGE SETTINGS
  // ========================================

  static const int imageQuality = 85;

  static const int maxImageWidth = 1600;

  static const int maxImageHeight = 1600;

  // ========================================
  // CAMERA
  // ========================================

  static const double cameraPreviewAspectRatio =
      9 / 16;

  static const int detectionConfidenceThreshold =
      70;

  // ========================================
  // AI
  // ========================================

  static const int defaultStyleScore = 85;

  static const int maximumStyleScore = 100;

  // ========================================
  // PAGINATION
  // ========================================

  static const int defaultPageSize = 20;

  static const int outfitHistoryPageSize = 15;

  // ========================================
  // STORAGE KEYS
  // ========================================

  static const String onboardingCompletedKey =
      'onboarding_completed';

  static const String userProfileKey =
      'user_profile';

  static const String wardrobeKey =
      'wardrobe';

  static const String outfitsKey =
      'outfits';

  static const String favoritesKey =
      'favorites';

  static const String themeModeKey =
      'theme_mode';

  // ========================================
  // FILE PATHS
  // ========================================

  static const String wardrobeImagesPath =
      'wardrobe_images';

  static const String outfitImagesPath =
      'outfit_images';

  static const String profileImagesPath =
      'profile_images';

  static const String visualizationImagesPath =
      'visualization_images';

  // ========================================
  // NETWORK
  // ========================================

  static const Duration networkTimeout =
      Duration(seconds: 15);

  static const Duration networkRetryDelay =
      Duration(seconds: 2);

  // ========================================
  // WEATHER
  // ========================================

  static const Duration weatherCacheDuration =
      Duration(minutes: 30);

  /// OpenWeatherMap API key, supplied at build time with:
  ///   flutter run --dart-define=WEATHER_API_KEY=your_key_here
  /// Defaults to empty, in which case [WeatherService] simply reports
  /// that weather data is unavailable instead of crashing.
  static const String weatherApiKey = String.fromEnvironment(
    'WEATHER_API_KEY',
    defaultValue: '',
  );

  // ========================================
  // NOTIFICATIONS
  // ========================================

  static const String outfitNotificationChannel =
      'outfit_recommendations';

  static const String weatherNotificationChannel =
      'weather_recommendations';

  // ========================================
  // PRIVACY
  // ========================================

  static const bool weatherEnabledByDefault =
      false;

  static const bool notificationsEnabledByDefault =
      true;

  // ========================================
  // SUPPORTED IMAGE FORMATS
  // ========================================

  static const List<String> supportedImageFormats = [
    'jpg',
    'jpeg',
    'png',
    'webp',
  ];

  // ========================================
  // SUPPORTED CLOTHING CATEGORIES
  // ========================================

  static const List<String> clothingCategories = [
    'tops',
    'bottoms',
    'shoes',
    'outerwear',
    'accessories',
  ];

  // ========================================
  // SUPPORTED STYLES
  // ========================================

  static const List<String> supportedStyles = [
    'Casual',
    'Streetwear',
    'Sporty',
    'Minimal',
    'Classic',
    'Smart Casual',
  ];

  // ========================================
  // SUPPORTED OCCASIONS
  // ========================================

  static const List<String> supportedOccasions = [
    'School',
    'Casual Day',
    'Friends',
    'Family Event',
    'Sport',
    'Special Event',
  ];
}