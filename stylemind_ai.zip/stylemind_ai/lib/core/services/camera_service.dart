import 'dart:io';

import 'package:camera/camera.dart';

class CameraService {
  CameraController? _controller;

  List<CameraDescription> _cameras = [];

  // ========================================
  // GETTERS
  // ========================================

  CameraController? get controller => _controller;

  bool get isInitialized =>
      _controller?.value.isInitialized ?? false;

  bool get isRecordingVideo =>
      _controller?.value.isRecordingVideo ?? false;

  bool get hasCamera => _cameras.isNotEmpty;

  // ========================================
  // INITIALIZE CAMERAS
  // ========================================

  Future<void> initializeCameras() async {
    try {
      _cameras = await availableCameras();
    } catch (e) {
      throw CameraException(
        'CAMERA_INITIALIZATION_ERROR',
        'Unable to access device cameras: $e',
      );
    }
  }

  // ========================================
  // INITIALIZE CAMERA
  // ========================================

  Future<void> initializeCamera({
    CameraLensDirection direction =
        CameraLensDirection.back,
  }) async {
    if (_cameras.isEmpty) {
      await initializeCameras();
    }

    if (_cameras.isEmpty) {
      throw CameraException(
        'NO_CAMERA_AVAILABLE',
        'No camera is available on this device.',
      );
    }

    CameraDescription selectedCamera;

    try {
      selectedCamera = _cameras.firstWhere(
        (camera) => camera.lensDirection == direction,
      );
    } catch (_) {
      selectedCamera = _cameras.first;
    }

    await disposeController();

    _controller = CameraController(
      selectedCamera,
      ResolutionPreset.high,
      enableAudio: false,
      imageFormatGroup: Platform.isIOS
          ? ImageFormatGroup.bgra8888
          : ImageFormatGroup.yuv420,
    );

    try {
      await _controller!.initialize();
    } catch (e) {
      await disposeController();

      throw CameraException(
        'CAMERA_SETUP_ERROR',
        'Unable to initialize camera: $e',
      );
    }
  }

  // ========================================
  // SWITCH CAMERA
  // ========================================

  Future<void> switchCamera() async {
    if (_cameras.length < 2) {
      return;
    }

    final currentDirection =
        _controller?.description.lensDirection;

    final newDirection =
        currentDirection == CameraLensDirection.front
            ? CameraLensDirection.back
            : CameraLensDirection.front;

    await initializeCamera(direction: newDirection);
  }

  // ========================================
  // TAKE PHOTO
  // ========================================

  Future<XFile?> takePicture() async {
    if (!isInitialized) {
      return null;
    }

    if (_controller!.value.isTakingPicture) {
      return null;
    }

    try {
      return await _controller!.takePicture();
    } catch (e) {
      throw CameraException(
        'TAKE_PICTURE_ERROR',
        'Unable to capture image: $e',
      );
    }
  }

  // ========================================
  // START VIDEO RECORDING
  // ========================================

  Future<void> startVideoRecording() async {
    if (!isInitialized) {
      throw CameraException(
        'CAMERA_NOT_INITIALIZED',
        'Camera has not been initialized.',
      );
    }

    if (isRecordingVideo) {
      return;
    }

    try {
      await _controller!.startVideoRecording();
    } catch (e) {
      throw CameraException(
        'VIDEO_RECORDING_ERROR',
        'Unable to start video recording: $e',
      );
    }
  }

  // ========================================
  // STOP VIDEO RECORDING
  // ========================================

  Future<XFile?> stopVideoRecording() async {
    if (!isInitialized || !isRecordingVideo) {
      return null;
    }

    try {
      return await _controller!.stopVideoRecording();
    } catch (e) {
      throw CameraException(
        'STOP_RECORDING_ERROR',
        'Unable to stop video recording: $e',
      );
    }
  }

  // ========================================
  // FLASH
  // ========================================

  Future<void> setFlashMode(FlashMode mode) async {
    if (!isInitialized) {
      return;
    }

    try {
      await _controller!.setFlashMode(mode);
    } catch (e) {
      throw CameraException(
        'FLASH_ERROR',
        'Unable to change flash mode: $e',
      );
    }
  }

  Future<void> toggleFlash() async {
    if (!isInitialized) {
      return;
    }

    final currentMode = _controller!.value.flashMode;

    final newMode =
        currentMode == FlashMode.off
            ? FlashMode.auto
            : FlashMode.off;

    await setFlashMode(newMode);
  }

  // ========================================
  // ZOOM
  // ========================================

  Future<void> setZoom(double zoom) async {
    if (!isInitialized) {
      return;
    }

    try {
      final minZoom =
          await _controller!.getMinZoomLevel();

      final maxZoom =
          await _controller!.getMaxZoomLevel();

      final safeZoom =
          zoom.clamp(minZoom, maxZoom);

      await _controller!.setZoomLevel(safeZoom);
    } catch (e) {
      throw CameraException(
        'ZOOM_ERROR',
        'Unable to change camera zoom: $e',
      );
    }
  }

  // ========================================
  // FOCUS
  // ========================================

  Future<void> setFocusPoint(
    Offset point,
  ) async {
    if (!isInitialized) {
      return;
    }

    try {
      await _controller!.setFocusPoint(point);
    } catch (_) {
      // Some devices do not support manual focus.
    }
  }

  // ========================================
  // EXPOSURE
  // ========================================

  Future<void> setExposurePoint(
    Offset point,
  ) async {
    if (!isInitialized) {
      return;
    }

    try {
      await _controller!.setExposurePoint(point);
    } catch (_) {
      // Some devices do not support manual exposure.
    }
  }

  // ========================================
  // CAMERA DESCRIPTION
  // ========================================

  CameraLensDirection? get currentLensDirection {
    return _controller?.description.lensDirection;
  }

  bool get isFrontCamera {
    return currentLensDirection ==
        CameraLensDirection.front;
  }

  bool get isBackCamera {
    return currentLensDirection ==
        CameraLensDirection.back;
  }

  // ========================================
  // DISPOSE
  // ========================================

  Future<void> disposeController() async {
    final controller = _controller;

    if (controller == null) {
      return;
    }

    _controller = null;

    try {
      await controller.dispose();
    } catch (_) {
      // Ignore dispose errors.
    }
  }

  Future<void> dispose() async {
    await disposeController();
  }
}