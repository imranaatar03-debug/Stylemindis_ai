import 'dart:convert';

import 'package:http/http.dart' as http;

import '../../models/weather_model.dart';
import '../constants/app_constants.dart';

class WeatherService {
  WeatherService({
    String? apiKey,
  }) : apiKey = apiKey ?? AppConstants.weatherApiKey;

  final String apiKey;

  // ========================================
  // API CONFIGURATION
  // ========================================

  static const String _baseUrl =
      'https://api.openweathermap.org/data/2.5/weather';

  // ========================================
  // GET WEATHER
  // ========================================

  Future<WeatherModel> getWeather({
    required double latitude,
    required double longitude,
  }) async {
    if (apiKey.trim().isEmpty) {
      throw Exception(
        'Weather API key is not configured.',
      );
    }

    final uri = Uri.parse(_baseUrl).replace(
      queryParameters: {
        'lat': latitude.toString(),
        'lon': longitude.toString(),
        'appid': apiKey,
        'units': 'metric',
      },
    );

    try {
      final response = await http
          .get(uri)
          .timeout(AppConstants.networkTimeout);

      if (response.statusCode != 200) {
        throw Exception(
          'Weather request failed: ${response.statusCode}',
        );
      }

      final data = jsonDecode(response.body);

      if (data is! Map<String, dynamic>) {
        throw Exception(
          'Invalid weather response.',
        );
      }

      return _mapOpenWeatherResponse(data);
    } catch (e) {
      throw Exception(
        'Unable to load weather data: $e',
      );
    }
  }

  // ========================================
  // GET WEATHER BY CITY
  // ========================================

  Future<WeatherModel> getWeatherByCity(
    String city,
  ) async {
    if (apiKey.trim().isEmpty) {
      throw Exception(
        'Weather API key is not configured.',
      );
    }

    if (city.trim().isEmpty) {
      throw Exception(
        'City name cannot be empty.',
      );
    }

    final uri = Uri.parse(_baseUrl).replace(
      queryParameters: {
        'q': city.trim(),
        'appid': apiKey,
        'units': 'metric',
      },
    );

    try {
      final response = await http
          .get(uri)
          .timeout(AppConstants.networkTimeout);

      if (response.statusCode != 200) {
        throw Exception(
          'Weather request failed: ${response.statusCode}',
        );
      }

      final data = jsonDecode(response.body);

      if (data is! Map<String, dynamic>) {
        throw Exception(
          'Invalid weather response.',
        );
      }

      return _mapOpenWeatherResponse(data);
    } catch (e) {
      throw Exception(
        'Unable to load weather data: $e',
      );
    }
  }

  // ========================================
  // RESPONSE MAPPING
  // ========================================

  /// Maps a raw OpenWeatherMap "current weather" JSON response onto
  /// [WeatherModel]. This is deliberately separate from
  /// [WeatherModel.fromJson], which instead round-trips the model's own
  /// flat shape for local caching (see [toJson]).
  WeatherModel _mapOpenWeatherResponse(Map<String, dynamic> data) {
    final main = data['main'] as Map<String, dynamic>? ?? {};
    final wind = data['wind'] as Map<String, dynamic>? ?? {};
    final sys = data['sys'] as Map<String, dynamic>? ?? {};
    final weatherList = data['weather'] as List<dynamic>? ?? [];
    final weather = weatherList.isNotEmpty
        ? weatherList.first as Map<String, dynamic>
        : <String, dynamic>{};

    return WeatherModel(
      city: data['name'] as String? ?? '',
      country: sys['country'] as String? ?? '',
      temperature: (main['temp'] as num?)?.toDouble() ?? 0.0,
      feelsLike: (main['feels_like'] as num?)?.toDouble() ?? 0.0,
      minTemperature: (main['temp_min'] as num?)?.toDouble() ?? 0.0,
      maxTemperature: (main['temp_max'] as num?)?.toDouble() ?? 0.0,
      humidity: (main['humidity'] as num?)?.toInt() ?? 0,
      windSpeed: (wind['speed'] as num?)?.toDouble() ?? 0.0,
      condition: weather['main'] as String? ?? '',
      description: weather['description'] as String? ?? '',
      icon: weather['icon'] as String? ?? '',
      updatedAt: DateTime.now(),
    );
  }

  // ========================================
  // WEATHER RECOMMENDATIONS
  // ========================================

  List<String> getClothingRecommendations(
    WeatherModel weather,
  ) {
    final recommendations = <String>[];

    if (weather.temperature <= 10) {
      recommendations.add(
        'Warm layers are recommended.',
      );
      recommendations.add(
        'Consider wearing a jacket or coat.',
      );
    } else if (weather.temperature <= 18) {
      recommendations.add(
        'A light jacket may be useful today.',
      );
    } else if (weather.temperature <= 25) {
      recommendations.add(
        'Lightweight clothing should work well.',
      );
    } else {
      recommendations.add(
        'Choose lightweight and breathable clothing.',
      );
    }

    if (weather.isRainy) {
      recommendations.add(
        'Consider weather-friendly shoes.',
      );
    }

    if (weather.windSpeed >= 8) {
      recommendations.add(
        'A wind-resistant outer layer may be useful.',
      );
    }

    return recommendations;
  }

  // ========================================
  // WEATHER CACHE DURATION
  // ========================================

  Duration get cacheDuration {
    return AppConstants.weatherCacheDuration;
  }
}