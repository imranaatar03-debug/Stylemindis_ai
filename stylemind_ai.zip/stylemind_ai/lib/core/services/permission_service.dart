import 'package:permission_handler/permission_handler.dart';

class PermissionService {
  PermissionService._();

  static final PermissionService instance =
      PermissionService._();

  // ========================================
  // CAMERA PERMISSION
  // ========================================

  Future<PermissionStatus> getCameraStatus() async {
    return Permission.camera.status;
  }

  Future<bool> requestCameraPermission() async {
    final status = await Permission.camera.request();

    return status.isGranted;
  }

  Future<bool> isCameraGranted() async {
    final status = await Permission.camera.status;

    return status.isGranted;
  }

  // ========================================
  // NOTIFICATION PERMISSION
  // ========================================

  Future<PermissionStatus> getNotificationStatus() async {
    return Permission.notification.status;
  }

  Future<bool> requestNotificationPermission() async {
    final status =
        await Permission.notification.request();

    return status.isGranted;
  }

  Future<bool> areNotificationsGranted() async {
    final status =
        await Permission.notification.status;

    return status.isGranted;
  }

  // ========================================
  // PHOTO / GALLERY PERMISSION
  // ========================================

  Future<PermissionStatus> getPhotosStatus() async {
    return Permission.photos.status;
  }

  Future<bool> requestPhotosPermission() async {
    final status = await Permission.photos.request();

    return status.isGranted;
  }

  Future<bool> arePhotosGranted() async {
    final status = await Permission.photos.status;

    return status.isGranted;
  }

  // ========================================
  // LOCATION PERMISSION
  // ========================================

  Future<PermissionStatus> getLocationStatus() async {
    return Permission.locationWhenInUse.status;
  }

  Future<bool> requestLocationPermission() async {
    final status =
        await Permission.locationWhenInUse.request();

    return status.isGranted;
  }

  Future<bool> isLocationGranted() async {
    final status =
        await Permission.locationWhenInUse.status;

    return status.isGranted;
  }

  // ========================================
  // OPEN APP SETTINGS
  // ========================================

  Future<bool> openSettings() async {
    return openAppSettings();
  }

  // ========================================
  // GENERIC PERMISSION STATUS
  // ========================================

  Future<bool> isGranted(
    Permission permission,
  ) async {
    final status = await permission.status;

    return status.isGranted;
  }

  Future<bool> isPermanentlyDenied(
    Permission permission,
  ) async {
    final status = await permission.status;

    return status.isPermanentlyDenied;
  }
}