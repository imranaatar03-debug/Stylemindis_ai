import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../constants/app_constants.dart';

class StorageService {
  StorageService();

  StorageService._internal();

  static final StorageService instance = StorageService._internal();

  SharedPreferences? _preferences;

  // ========================================
  // INITIALIZATION
  // ========================================

  Future<void> initialize() async {
    _preferences ??= await SharedPreferences.getInstance();
  }

  Future<SharedPreferences> get _prefs async {
    if (_preferences == null) {
      await initialize();
    }

    return _preferences!;
  }

  // ========================================
  // GENERIC VALUES
  // ========================================

  Future<bool> setString(
    String key,
    String value,
  ) async {
    final prefs = await _prefs;
    return prefs.setString(key, value);
  }

  Future<String?> getString(String key) async {
    final prefs = await _prefs;
    return prefs.getString(key);
  }

  Future<bool> setBool(
    String key,
    bool value,
  ) async {
    final prefs = await _prefs;
    return prefs.setBool(key, value);
  }

  Future<bool?> getBool(String key) async {
    final prefs = await _prefs;
    return prefs.getBool(key);
  }

  Future<bool> setInt(
    String key,
    int value,
  ) async {
    final prefs = await _prefs;
    return prefs.setInt(key, value);
  }

  Future<int?> getInt(String key) async {
    final prefs = await _prefs;
    return prefs.getInt(key);
  }

  // ========================================
  // GENERIC JSON LISTS
  // ========================================

  /// Stores an arbitrary list of JSON-encodable maps under [key].
  ///
  /// Used by repositories/services (wardrobe, outfits, auth accounts,
  /// profile data, ...) that need their own independent list storage
  /// instead of the dedicated wardrobe/outfits/favorites helpers below.
  Future<bool> setJsonList(
    String key,
    List<Map<String, dynamic>> value,
  ) async {
    return setString(key, jsonEncode(value));
  }

  /// Reads back a list stored with [setJsonList]. Returns an empty list
  /// when the key is missing or the stored value can't be decoded.
  Future<List<Map<String, dynamic>>> getJsonList(String key) async {
    final value = await getString(key);

    if (value == null || value.isEmpty) {
      return [];
    }

    try {
      final decoded = jsonDecode(value);

      if (decoded is List) {
        return decoded
            .whereType<Map>()
            .map((item) => Map<String, dynamic>.from(item))
            .toList();
      }

      return [];
    } catch (_) {
      return [];
    }
  }

  /// Stores a single JSON-encodable map under [key].
  Future<bool> setJson(
    String key,
    Map<String, dynamic> value,
  ) async {
    return setString(key, jsonEncode(value));
  }

  /// Reads back a map stored with [setJson]. Returns null when the key
  /// is missing or the stored value can't be decoded as a JSON object.
  Future<Map<String, dynamic>?> getJson(String key) async {
    final value = await getString(key);

    if (value == null || value.isEmpty) {
      return null;
    }

    try {
      final decoded = jsonDecode(value);

      if (decoded is Map<String, dynamic>) {
        return decoded;
      }

      return null;
    } catch (_) {
      return null;
    }
  }

  // ========================================
  // ONBOARDING
  // ========================================

  Future<void> setOnboardingCompleted(
    bool completed,
  ) async {
    await setBool(
      AppConstants.onboardingCompletedKey,
      completed,
    );
  }

  Future<bool> isOnboardingCompleted() async {
    return await getBool(
          AppConstants.onboardingCompletedKey,
        ) ??
        false;
  }

  // ========================================
  // USER PROFILE
  // ========================================

  Future<bool> saveUserProfile(
    Map<String, dynamic> profile,
  ) async {
    return setString(
      AppConstants.userProfileKey,
      jsonEncode(profile),
    );
  }

  Future<Map<String, dynamic>?> getUserProfile() async {
    final value = await getString(
      AppConstants.userProfileKey,
    );

    if (value == null || value.isEmpty) {
      return null;
    }

    try {
      final decoded = jsonDecode(value);

      if (decoded is Map<String, dynamic>) {
        return decoded;
      }

      return null;
    } catch (_) {
      return null;
    }
  }

  // ========================================
  // WARDROBE
  // ========================================

  Future<bool> saveWardrobe(
    List<Map<String, dynamic>> wardrobe,
  ) async {
    return setString(
      AppConstants.wardrobeKey,
      jsonEncode(wardrobe),
    );
  }

  Future<List<Map<String, dynamic>>> getWardrobe() async {
    final value = await getString(
      AppConstants.wardrobeKey,
    );

    if (value == null || value.isEmpty) {
      return [];
    }

    try {
      final decoded = jsonDecode(value);

      if (decoded is List) {
        return decoded
            .whereType<Map>()
            .map(
              (item) => Map<String, dynamic>.from(item),
            )
            .toList();
      }

      return [];
    } catch (_) {
      return [];
    }
  }

  // ========================================
  // OUTFITS
  // ========================================

  Future<bool> saveOutfits(
    List<Map<String, dynamic>> outfits,
  ) async {
    return setString(
      AppConstants.outfitsKey,
      jsonEncode(outfits),
    );
  }

  Future<List<Map<String, dynamic>>> getOutfits() async {
    final value = await getString(
      AppConstants.outfitsKey,
    );

    if (value == null || value.isEmpty) {
      return [];
    }

    try {
      final decoded = jsonDecode(value);

      if (decoded is List) {
        return decoded
            .whereType<Map>()
            .map(
              (item) => Map<String, dynamic>.from(item),
            )
            .toList();
      }

      return [];
    } catch (_) {
      return [];
    }
  }

  // ========================================
  // FAVORITES
  // ========================================

  Future<bool> saveFavorites(
    List<String> favoriteIds,
  ) async {
    return setString(
      AppConstants.favoritesKey,
      jsonEncode(favoriteIds),
    );
  }

  Future<List<String>> getFavorites() async {
    final value = await getString(
      AppConstants.favoritesKey,
    );

    if (value == null || value.isEmpty) {
      return [];
    }

    try {
      final decoded = jsonDecode(value);

      if (decoded is List) {
        return decoded
            .whereType<String>()
            .toList();
      }

      return [];
    } catch (_) {
      return [];
    }
  }

  // ========================================
  // THEME
  // ========================================

  Future<bool> saveThemeMode(String mode) async {
    return setString(
      AppConstants.themeModeKey,
      mode,
    );
  }

  Future<String?> getThemeMode() async {
    return getString(
      AppConstants.themeModeKey,
    );
  }

  // ========================================
  // REMOVE DATA
  // ========================================

  Future<bool> remove(String key) async {
    final prefs = await _prefs;
    return prefs.remove(key);
  }

  Future<bool> clearUserProfile() async {
    return remove(AppConstants.userProfileKey);
  }

  Future<bool> clearWardrobe() async {
    return remove(AppConstants.wardrobeKey);
  }

  Future<bool> clearOutfits() async {
    return remove(AppConstants.outfitsKey);
  }

  Future<bool> clearFavorites() async {
    return remove(AppConstants.favoritesKey);
  }

  // ========================================
  // DELETE ALL APP DATA
  // ========================================

  Future<bool> clearAllData() async {
    final prefs = await _prefs;

    return prefs.clear();
  }
}