import 'package:flutter_local_notifications/flutter_local_notifications.dart';

import '../constants/app_constants.dart';

class NotificationService {
  NotificationService._();

  static final NotificationService instance =
      NotificationService._();

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  bool _initialized = false;

  // ========================================
  // INITIALIZE
  // ========================================

  Future<void> initialize() async {
    if (_initialized) {
      return;
    }

    const androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const iosSettings = DarwinInitializationSettings(
      requestAlertPermission: false,
      requestBadgePermission: false,
      requestSoundPermission: false,
    );

    const settings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _plugin.initialize(settings);

    await _createNotificationChannels();

    _initialized = true;
  }

  // ========================================
  // NOTIFICATION CHANNELS
  // ========================================

  Future<void> _createNotificationChannels() async {
    const androidPlugin =
        AndroidFlutterLocalNotificationsPlugin();

    const outfitChannel = AndroidNotificationChannel(
      AppConstants.outfitNotificationChannel,
      'Outfit Recommendations',
      description:
          'Notifications about daily outfit recommendations.',
      importance: Importance.high,
    );

    const weatherChannel = AndroidNotificationChannel(
      AppConstants.weatherNotificationChannel,
      'Weather Recommendations',
      description:
          'Weather-based clothing recommendations.',
      importance: Importance.defaultImportance,
    );

    await androidPlugin.createNotificationChannel(
      outfitChannel,
    );

    await androidPlugin.createNotificationChannel(
      weatherChannel,
    );
  }

  // ========================================
  // REQUEST PERMISSION
  // ========================================

  Future<bool> requestPermission() async {
    if (!_initialized) {
      await initialize();
    }

    bool granted = false;

    final androidPlugin =
        _plugin.resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>();

    if (androidPlugin != null) {
      granted =
          await androidPlugin.requestNotificationsPermission() ??
          false;
    }

    final iosPlugin =
        _plugin.resolvePlatformSpecificImplementation<
            IOSFlutterLocalNotificationsPlugin>();

    if (iosPlugin != null) {
      granted =
          await iosPlugin.requestPermissions(
                alert: true,
                badge: true,
                sound: true,
              ) ??
          false;
    }

    return granted;
  }

  // ========================================
  // SHOW OUTFIT NOTIFICATION
  // ========================================

  Future<void> showOutfitRecommendation({
    required String title,
    required String body,
  }) async {
    if (!_initialized) {
      await initialize();
    }

    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        AppConstants.outfitNotificationChannel,
        'Outfit Recommendations',
        channelDescription:
            'Notifications about daily outfit recommendations.',
        importance: Importance.high,
        priority: Priority.high,
      ),
      iOS: DarwinNotificationDetails(),
    );

    await _plugin.show(
      1001,
      title,
      body,
      details,
    );
  }

  // ========================================
  // SHOW WEATHER NOTIFICATION
  // ========================================

  Future<void> showWeatherRecommendation({
    required String title,
    required String body,
  }) async {
    if (!_initialized) {
      await initialize();
    }

    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        AppConstants.weatherNotificationChannel,
        'Weather Recommendations',
        channelDescription:
            'Weather-based clothing recommendations.',
        importance: Importance.defaultImportance,
        priority: Priority.defaultPriority,
      ),
      iOS: DarwinNotificationDetails(),
    );

    await _plugin.show(
      1002,
      title,
      body,
      details,
    );
  }

  // ========================================
  // SHOW CUSTOM NOTIFICATION
  // ========================================

  Future<void> showNotification({
    required int id,
    required String title,
    required String body,
  }) async {
    if (!_initialized) {
      await initialize();
    }

    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        AppConstants.outfitNotificationChannel,
        'STYLEMIND AI',
        channelDescription:
            'STYLEMIND AI notifications.',
        importance: Importance.high,
        priority: Priority.high,
      ),
      iOS: DarwinNotificationDetails(),
    );

    await _plugin.show(
      id,
      title,
      body,
      details,
    );
  }

  // ========================================
  // CANCEL NOTIFICATION
  // ========================================

  Future<void> cancel(int id) async {
    await _plugin.cancel(id);
  }

  // ========================================
  // CANCEL ALL
  // ========================================

  Future<void> cancelAll() async {
    await _plugin.cancelAll();
  }

  // ========================================
  // DISPOSE
  // ========================================

  Future<void> dispose() async {
    await cancelAll();
    _initialized = false;
  }
}