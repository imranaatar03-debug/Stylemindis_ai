import 'dart:io';
import 'dart:typed_data';

import 'package:image/image.dart' as img;

import '../constants/app_constants.dart';

class ImageUtils {
  ImageUtils._();

  // ========================================
  // CHECK SUPPORTED FORMAT
  // ========================================

  static bool isSupportedFormat(String path) {
    final extension = _getExtension(path);

    return AppConstants.supportedImageFormats
        .contains(extension);
  }

  // ========================================
  // GET EXTENSION
  // ========================================

  static String _getExtension(String path) {
    final cleanPath = path.split('?').first;

    if (!cleanPath.contains('.')) {
      return '';
    }

    return cleanPath
        .split('.')
        .last
        .toLowerCase();
  }

  // ========================================
  // READ IMAGE BYTES
  // ========================================

  static Future<Uint8List> readBytes(
    String path,
  ) async {
    final file = File(path);

    if (!await file.exists()) {
      throw Exception(
        'Image file does not exist.',
      );
    }

    return file.readAsBytes();
  }

  // ========================================
  // DECODE IMAGE
  // ========================================

  static Future<img.Image?> decode(
    String path,
  ) async {
    final bytes = await readBytes(path);

    return img.decodeImage(bytes);
  }

  // ========================================
  // RESIZE IMAGE
  // ========================================

  static Future<Uint8List> resize(
    String path, {
    int maxWidth = AppConstants.maxImageWidth,
    int maxHeight = AppConstants.maxImageHeight,
  }) async {
    final bytes = await readBytes(path);

    final decoded = img.decodeImage(bytes);

    if (decoded == null) {
      throw Exception(
        'Unable to decode image.',
      );
    }

    final resized = img.copyResize(
      decoded,
      width: decoded.width > maxWidth
          ? maxWidth
          : decoded.width,
      height: decoded.height > maxHeight
          ? maxHeight
          : decoded.height,
      maintainAspect: true,
    );

    return Uint8List.fromList(
      img.encodeJpg(
        resized,
        quality: AppConstants.imageQuality,
      ),
    );
  }

  // ========================================
  // COMPRESS IMAGE
  // ========================================

  static Future<Uint8List> compress(
    String path, {
    int quality = AppConstants.imageQuality,
  }) async {
    final bytes = await readBytes(path);

    final decoded = img.decodeImage(bytes);

    if (decoded == null) {
      throw Exception(
        'Unable to decode image.',
      );
    }

    final safeQuality =
        quality.clamp(1, 100);

    return Uint8List.fromList(
      img.encodeJpg(
        decoded,
        quality: safeQuality,
      ),
    );
  }

  // ========================================
  // GET IMAGE DIMENSIONS
  // ========================================

  static Future<ImageDimensions?> getDimensions(
    String path,
  ) async {
    final decoded = await decode(path);

    if (decoded == null) {
      return null;
    }

    return ImageDimensions(
      width: decoded.width,
      height: decoded.height,
    );
  }

  // ========================================
  // CHECK IMAGE
  // ========================================

  static Future<bool> isValidImage(
    String path,
  ) async {
    try {
      if (!isSupportedFormat(path)) {
        return false;
      }

      final decoded = await decode(path);

      return decoded != null;
    } catch (_) {
      return false;
    }
  }

  // ========================================
  // DELETE IMAGE
  // ========================================

  static Future<bool> deleteImage(
    String path,
  ) async {
    try {
      final file = File(path);

      if (!await file.exists()) {
        return false;
      }

      await file.delete();

      return true;
    } catch (_) {
      return false;
    }
  }

  // ========================================
  // IMAGE FILE SIZE
  // ========================================

  static Future<int> getFileSize(
    String path,
  ) async {
    final file = File(path);

    if (!await file.exists()) {
      return 0;
    }

    return file.length();
  }

  // ========================================
  // BYTES TO MEGABYTES
  // ========================================

  static double bytesToMegabytes(
    int bytes,
  ) {
    return bytes / (1024 * 1024);
  }
}

// ========================================
// IMAGE DIMENSIONS MODEL
// ========================================

class ImageDimensions {
  const ImageDimensions({
    required this.width,
    required this.height,
  });

  final int width;
  final int height;

  double get aspectRatio {
    if (height == 0) {
      return 0;
    }

    return width / height;
  }

  bool get isLandscape {
    return width > height;
  }

  bool get isPortrait {
    return height > width;
  }

  bool get isSquare {
    return width == height;
  }
}