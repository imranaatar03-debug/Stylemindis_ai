import '../../models/clothing_item_model.dart';
import '../../models/outfit_model.dart';

class OutfitUtils {
  OutfitUtils._();

  // ========================================
  // OUTFIT COMPLETENESS
  // ========================================

  static bool isComplete(OutfitModel outfit) {
    return outfit.items.isNotEmpty;
  }

  // ========================================
  // COUNT ITEMS
  // ========================================

  static int itemCount(OutfitModel outfit) {
    return outfit.items.length;
  }

  // ========================================
  // CHECK CLOTHING CATEGORY
  // ========================================

  static bool containsCategory(
    OutfitModel outfit,
    String category,
  ) {
    return outfit.items.any(
      (item) =>
          item.category.toLowerCase() ==
          category.toLowerCase(),
    );
  }

  // ========================================
  // REQUIRED CATEGORIES
  // ========================================

  static List<String> missingCategories(
    OutfitModel outfit,
  ) {
    const requiredCategories = [
      'tops',
      'bottoms',
      'shoes',
    ];

    return requiredCategories
        .where(
          (category) =>
              !containsCategory(outfit, category),
        )
        .toList();
  }

  // ========================================
  // OUTFIT SCORE
  // ========================================

  static int calculateScore(
    OutfitModel outfit,
  ) {
    if (outfit.items.isEmpty) {
      return 0;
    }

    int score = 50;

    if (containsCategory(outfit, 'tops')) {
      score += 15;
    }

    if (containsCategory(outfit, 'bottoms')) {
      score += 15;
    }

    if (containsCategory(outfit, 'shoes')) {
      score += 15;
    }

    if (containsCategory(outfit, 'outerwear')) {
      score += 5;
    }

    return score.clamp(0, 100);
  }

  // ========================================
  // CATEGORY COMPATIBILITY
  // ========================================

  static bool areCategoriesCompatible(
    ClothingItemModel first,
    ClothingItemModel second,
  ) {
    if (first.category.toLowerCase() ==
        second.category.toLowerCase()) {
      return false;
    }

    return true;
  }

  // ========================================
  // FIND COMPATIBLE ITEMS
  // ========================================

  static List<ClothingItemModel> findCompatibleItems({
    required ClothingItemModel selectedItem,
    required List<ClothingItemModel> wardrobe,
  }) {
    return wardrobe.where((item) {
      if (item.id == selectedItem.id) {
        return false;
      }

      return areCategoriesCompatible(
        selectedItem,
        item,
      );
    }).toList();
  }

  // ========================================
  // SORT BY CATEGORY
  // ========================================

  static Map<String, List<ClothingItemModel>>
      groupByCategory(
    List<ClothingItemModel> wardrobe,
  ) {
    final result =
        <String, List<ClothingItemModel>>{};

    for (final item in wardrobe) {
      result
          .putIfAbsent(
            item.category,
            () => [],
          )
          .add(item);
    }

    return result;
  }

  // ========================================
  // GET TOPS
  // ========================================

  static List<ClothingItemModel> getTops(
    List<ClothingItemModel> wardrobe,
  ) {
    return wardrobe
        .where(
          (item) =>
              item.category.toLowerCase() ==
              'tops',
        )
        .toList();
  }

  // ========================================
  // GET BOTTOMS
  // ========================================

  static List<ClothingItemModel> getBottoms(
    List<ClothingItemModel> wardrobe,
  ) {
    return wardrobe
        .where(
          (item) =>
              item.category.toLowerCase() ==
              'bottoms',
        )
        .toList();
  }

  // ========================================
  // GET SHOES
  // ========================================

  static List<ClothingItemModel> getShoes(
    List<ClothingItemModel> wardrobe,
  ) {
    return wardrobe
        .where(
          (item) =>
              item.category.toLowerCase() ==
              'shoes',
        )
        .toList();
  }

  // ========================================
  // GET OUTERWEAR
  // ========================================

  static List<ClothingItemModel> getOuterwear(
    List<ClothingItemModel> wardrobe,
  ) {
    return wardrobe
        .where(
          (item) =>
              item.category.toLowerCase() ==
              'outerwear',
        )
        .toList();
  }

  // ========================================
  // GET ACCESSORIES
  // ========================================

  static List<ClothingItemModel> getAccessories(
    List<ClothingItemModel> wardrobe,
  ) {
    return wardrobe
        .where(
          (item) =>
              item.category.toLowerCase() ==
              'accessories',
        )
        .toList();
  }

  // ========================================
  // OUTFIT DESCRIPTION
  // ========================================

  static String buildDescription(
    OutfitModel outfit,
  ) {
    final categories = outfit.items
        .map((item) => item.category)
        .toSet()
        .toList();

    if (categories.isEmpty) {
      return 'No clothing items selected.';
    }

    return 'This outfit combines '
        '${categories.join(', ')} '
        'from your wardrobe.';
  }
}