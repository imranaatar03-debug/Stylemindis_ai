import 'package:flutter/material.dart';

import '../constants/colors.dart';

class ColorUtils {
  ColorUtils._();

  // ========================================
  // COLOR FROM HEX
  // ========================================

  static Color fromHex(String hex) {
    final value = hex.replaceAll('#', '').trim();

    if (value.length == 6) {
      return Color(
        int.parse('FF$value', radix: 16),
      );
    }

    if (value.length == 8) {
      return Color(
        int.parse(value, radix: 16),
      );
    }

    return AppColors.primary;
  }

  // ========================================
  // COLOR TO HEX
  // ========================================

  static String toHex(
    Color color, {
    bool includeAlpha = false,
  }) {
    final alpha = color.alpha
        .toRadixString(16)
        .padLeft(2, '0');

    final red = color.red
        .toRadixString(16)
        .padLeft(2, '0');

    final green = color.green
        .toRadixString(16)
        .padLeft(2, '0');

    final blue = color.blue
        .toRadixString(16)
        .padLeft(2, '0');

    if (includeAlpha) {
      return '#$alpha$red$green$blue'
          .toUpperCase();
    }

    return '#$red$green$blue'.toUpperCase();
  }

  // ========================================
  // LIGHT OR DARK TEXT
  // ========================================

  static Color readableTextColor(
    Color background,
  ) {
    return background.computeLuminance() > 0.5
        ? AppColors.black
        : AppColors.white;
  }

  // ========================================
  // CHECK BRIGHTNESS
  // ========================================

  static bool isLight(Color color) {
    return color.computeLuminance() > 0.5;
  }

  static bool isDark(Color color) {
    return !isLight(color);
  }

  // ========================================
  // COLOR SIMILARITY
  // ========================================

  static double similarity(
    Color first,
    Color second,
  ) {
    final redDifference =
        (first.red - second.red).abs();

    final greenDifference =
        (first.green - second.green).abs();

    final blueDifference =
        (first.blue - second.blue).abs();

    final totalDifference =
        redDifference +
        greenDifference +
        blueDifference;

    const maximumDifference = 765.0;

    return 1 -
        (totalDifference / maximumDifference);
  }

  // ========================================
  // COLOR DISTANCE
  // ========================================

  static double distance(
    Color first,
    Color second,
  ) {
    final redDifference =
        first.red - second.red;

    final greenDifference =
        first.green - second.green;

    final blueDifference =
        first.blue - second.blue;

    return (
      redDifference * redDifference +
      greenDifference * greenDifference +
      blueDifference * blueDifference
    ).toDouble();
  }

  // ========================================
  // MIX COLORS
  // ========================================

  static Color mix(
    Color first,
    Color second, {
    double amount = 0.5,
  }) {
    final value = amount.clamp(0.0, 1.0);

    return Color.lerp(
          first,
          second,
          value,
        ) ??
        first;
  }

  // ========================================
  // ADD OPACITY
  // ========================================

  static Color withOpacity(
    Color color,
    double opacity,
  ) {
    return color.withOpacity(opacity.clamp(0.0, 1.0));
  }

  // ========================================
  // WARDROBE COLOR NAMES
  // ========================================

  static Color fromClothingColor(
    String colorName,
  ) {
    switch (colorName.toLowerCase().trim()) {
      case 'black':
        return const Color(0xFF111111);

      case 'white':
        return const Color(0xFFF5F5F5);

      case 'gray':
      case 'grey':
        return const Color(0xFF808080);

      case 'red':
        return const Color(0xFFE53935);

      case 'blue':
        return const Color(0xFF2979FF);

      case 'navy':
        return const Color(0xFF172A46);

      case 'green':
        return const Color(0xFF43A047);

      case 'yellow':
        return const Color(0xFFFDD835);

      case 'orange':
        return const Color(0xFFFB8C00);

      case 'purple':
        return const Color(0xFF8E44AD);

      case 'pink':
        return const Color(0xFFE91E63);

      case 'brown':
        return const Color(0xFF795548);

      case 'beige':
        return const Color(0xFFD8C3A5);

      case 'cream':
        return const Color(0xFFFFF4D6);

      default:
        return AppColors.darkCardLight;
    }
  }

  // ========================================
  // COLOR COMPATIBILITY (by clothing color name)
  // ========================================

  /// Rough 0.0-1.0 compatibility score between two clothing color names
  /// (e.g. "navy", "beige"), used by the outfit/match-scoring engines.
  /// Falls back to perceptual [similarity] between the resolved colors.
  static double getColorCompatibility(
    String firstColorName,
    String secondColorName,
  ) {
    final first = fromClothingColor(firstColorName);
    final second = fromClothingColor(secondColorName);

    return similarity(first, second).clamp(0.0, 1.0);
  }

  // ========================================
  // COLOR CATEGORY
  // ========================================

  static String getColorCategory(Color color) {
    final hsv = HSVColor.fromColor(color);

    if (hsv.value < 0.2) {
      return 'Black';
    }

    if (hsv.saturation < 0.15 &&
        hsv.value > 0.85) {
      return 'White';
    }

    if (hsv.saturation < 0.2) {
      return 'Gray';
    }

    final hue = hsv.hue;

    if (hue < 15 || hue >= 345) {
      return 'Red';
    }

    if (hue < 45) {
      return 'Orange';
    }

    if (hue < 75) {
      return 'Yellow';
    }

    if (hue < 165) {
      return 'Green';
    }

    if (hue < 255) {
      return 'Blue';
    }

    if (hue < 285) {
      return 'Purple';
    }

    return 'Pink';
  }
}