import 'package:flutter/material.dart';

import '../constants/colors.dart';
import 'app_button.dart';

/// A reusable "nothing here yet" placeholder shown across list/grid
/// screens (wardrobe, outfits, favorites, history, chat, etc).
///
/// A call to action can be supplied either as a ready-made [action] widget
/// or as an [actionLabel] + [onAction] pair, in which case an [AppButton]
/// is built automatically. [message] and [description] are interchangeable
/// aliases for the subtitle text.
class EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? message;
  final String? description;
  final String? actionLabel;
  final VoidCallback? onAction;
  final Widget? action;

  const EmptyState({
    super.key,
    required this.icon,
    required this.title,
    this.message,
    this.description,
    this.actionLabel,
    this.onAction,
    this.action,
  });

  @override
  Widget build(BuildContext context) {
    final subtitle = message ?? description;

    Widget? actionWidget = action;
    if (actionWidget == null && actionLabel != null) {
      actionWidget = AppButton(
        text: actionLabel!,
        onPressed: onAction,
      );
    }

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 84,
              height: 84,
              decoration: BoxDecoration(
                color: AppColors.primary.withOpacity(0.10),
                shape: BoxShape.circle,
              ),
              child: Icon(
                icon,
                size: 40,
                color: AppColors.primary,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
              ),
            ),
            if (subtitle != null) ...[
              const SizedBox(height: 8),
              Text(
                subtitle,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 14,
                  color: Theme.of(context)
                      .textTheme
                      .bodyMedium
                      ?.color
                      ?.withOpacity(0.7),
                ),
              ),
            ],
            if (actionWidget != null) ...[
              const SizedBox(height: 24),
              actionWidget,
            ],
          ],
        ),
      ),
    );
  }
}
