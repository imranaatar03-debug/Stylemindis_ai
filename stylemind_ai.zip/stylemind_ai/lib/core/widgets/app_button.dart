import 'package:flutter/material.dart';

import '../constants/colors.dart';

/// A reusable button used throughout STYLEMIND AI.
///
/// Supports a filled (primary) style and an outlined style, an optional
/// leading [icon], a busy/[loading] state, a [fullWidth] layout and an
/// [enabled] flag that is independent from whether [onPressed] is null.
class AppButton extends StatelessWidget {
  final String text;
  final VoidCallback? onPressed;
  final IconData? icon;
  final bool fullWidth;
  final double height;
  final bool outlined;
  final bool enabled;
  final bool loading;

  const AppButton({
    super.key,
    required this.text,
    required this.onPressed,
    this.icon,
    this.fullWidth = false,
    this.height = 52,
    this.outlined = false,
    this.enabled = true,
    this.loading = false,
  });

  bool get _isEnabled => enabled && onPressed != null && !loading;

  @override
  Widget build(BuildContext context) {
    final child = loading
        ? SizedBox(
            width: 22,
            height: 22,
            child: CircularProgressIndicator(
              strokeWidth: 2.4,
              valueColor: AlwaysStoppedAnimation<Color>(
                outlined ? AppColors.primary : Colors.white,
              ),
            ),
          )
        : Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (icon != null) ...[
                Icon(icon, size: 20),
                const SizedBox(width: 8),
              ],
              Text(
                text,
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.2,
                ),
              ),
            ],
          );

    final button = outlined
        ? OutlinedButton(
            onPressed: _isEnabled ? onPressed : null,
            style: OutlinedButton.styleFrom(
              foregroundColor: AppColors.primary,
              disabledForegroundColor:
                  AppColors.primary.withOpacity(0.4),
              side: BorderSide(
                color: _isEnabled
                    ? AppColors.primary
                    : AppColors.primary.withOpacity(0.4),
                width: 1.5,
              ),
              minimumSize: Size(fullWidth ? double.infinity : 0, height),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
            ),
            child: child,
          )
        : ElevatedButton(
            onPressed: _isEnabled ? onPressed : null,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              foregroundColor: Colors.white,
              disabledBackgroundColor:
                  AppColors.primary.withOpacity(0.35),
              disabledForegroundColor: Colors.white70,
              elevation: 0,
              minimumSize: Size(fullWidth ? double.infinity : 0, height),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
            ),
            child: child,
          );

    return fullWidth
        ? SizedBox(width: double.infinity, child: button)
        : button;
  }
}
