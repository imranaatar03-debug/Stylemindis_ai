class ClothingItemModel {
  final String id;
  final String name;
  final String category;
  final String subcategory;
  final String imagePath;
  final String brand;
  final String color;
  final List<String> colors;
  final String? pattern;
  final String material;
  final String size;
  final String? season;
  final List<String> styles;
  final List<String> occasions;
  final bool isFavorite;
  final bool isAvailable;
  final double? price;
  final String? notes;
  final double aiConfidence;
  final DateTime createdAt;
  final DateTime updatedAt;

  const ClothingItemModel({
    required this.id,
    required this.name,
    required this.category,
    this.subcategory = '',
    required this.imagePath,
    this.brand = '',
    this.color = '',
    this.colors = const [],
    this.pattern,
    this.material = '',
    this.size = '',
    this.season,
    this.styles = const [],
    this.occasions = const [],
    this.isFavorite = false,
    this.isAvailable = true,
    this.price,
    this.notes,
    this.aiConfidence = 0.0,
    required this.createdAt,
    required this.updatedAt,
  });

  /// The item's primary style tag, derived from [styles].
  ///
  /// Convenience accessor used by the outfit/matching engines, which
  /// reason about a single dominant style rather than the full list.
  String get style => styles.isNotEmpty ? styles.first : '';

  /// The item's primary occasion tag, derived from [occasions].
  ///
  /// Convenience accessor used by the outfit/matching engines, which
  /// reason about a single dominant occasion rather than the full list.
  String get occasion => occasions.isNotEmpty ? occasions.first : '';

  ClothingItemModel copyWith({
    String? id,
    String? name,
    String? category,
    String? subcategory,
    String? imagePath,
    String? brand,
    String? color,
    List<String>? colors,
    String? pattern,
    String? material,
    String? size,
    String? season,
    List<String>? styles,
    List<String>? occasions,
    bool? isFavorite,
    bool? isAvailable,
    double? price,
    String? notes,
    double? aiConfidence,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return ClothingItemModel(
      id: id ?? this.id,
      name: name ?? this.name,
      category: category ?? this.category,
      subcategory: subcategory ?? this.subcategory,
      imagePath: imagePath ?? this.imagePath,
      brand: brand ?? this.brand,
      color: color ?? this.color,
      colors: colors ?? this.colors,
      pattern: pattern ?? this.pattern,
      material: material ?? this.material,
      size: size ?? this.size,
      season: season ?? this.season,
      styles: styles ?? this.styles,
      occasions: occasions ?? this.occasions,
      isFavorite: isFavorite ?? this.isFavorite,
      isAvailable: isAvailable ?? this.isAvailable,
      price: price ?? this.price,
      notes: notes ?? this.notes,
      aiConfidence: aiConfidence ?? this.aiConfidence,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'category': category,
      'subcategory': subcategory,
      'imagePath': imagePath,
      'brand': brand,
      'color': color,
      'colors': colors,
      'pattern': pattern,
      'material': material,
      'size': size,
      'season': season,
      'styles': styles,
      'occasions': occasions,
      'isFavorite': isFavorite,
      'isAvailable': isAvailable,
      'price': price,
      'notes': notes,
      'aiConfidence': aiConfidence,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
    };
  }

  factory ClothingItemModel.fromJson(Map<String, dynamic> json) {
    return ClothingItemModel(
      id: json['id'] as String? ?? '',
      name: json['name'] as String? ?? '',
      category: json['category'] as String? ?? '',
      subcategory: json['subcategory'] as String? ?? '',
      imagePath: json['imagePath'] as String? ?? '',
      brand: json['brand'] as String? ?? '',
      color: json['color'] as String? ?? '',
      colors: List<String>.from(
        json['colors'] ?? const [],
      ),
      pattern: json['pattern'] as String?,
      material: json['material'] as String? ?? '',
      size: json['size'] as String? ?? '',
      season: json['season'] as String?,
      styles: List<String>.from(
        json['styles'] ?? const [],
      ),
      occasions: List<String>.from(
        json['occasions'] ?? const [],
      ),
      isFavorite: json['isFavorite'] as bool? ?? false,
      isAvailable: json['isAvailable'] as bool? ?? true,
      price: (json['price'] as num?)?.toDouble(),
      notes: json['notes'] as String?,
      aiConfidence:
          (json['aiConfidence'] as num?)?.toDouble() ?? 0.0,
      createdAt: DateTime.tryParse(
            json['createdAt'] as String? ?? '',
          ) ??
          DateTime.now(),
      updatedAt: DateTime.tryParse(
            json['updatedAt'] as String? ?? '',
          ) ??
          DateTime.now(),
    );
  }

  @override
  String toString() {
    return 'ClothingItemModel('
        'id: $id, '
        'name: $name, '
        'category: $category, '
        'color: $color'
        ')';
  }
}