class UserModel {
  final String id;
  final String name;
  final String email;
  final String? profileImage;
  final int? age;
  final String? gender;
  final double? height;
  final double? weight;
  final String? bodyType;
  final String? location;
  final String? preferredLanguage;
  final String? preferredStyle;
  final List<String> favoriteColors;
  final List<String> dislikedColors;
  final List<String> preferredStyles;
  final List<String> preferredOccasions;
  final DateTime createdAt;
  final DateTime updatedAt;

  const UserModel({
    required this.id,
    required this.name,
    required this.email,
    this.profileImage,
    this.age,
    this.gender,
    this.height,
    this.weight,
    this.bodyType,
    this.location,
    this.preferredLanguage,
    this.preferredStyle,
    this.favoriteColors = const [],
    this.dislikedColors = const [],
    this.preferredStyles = const [],
    this.preferredOccasions = const [],
    required this.createdAt,
    required this.updatedAt,
  });

  UserModel copyWith({
    String? id,
    String? name,
    String? email,
    String? profileImage,
    int? age,
    String? gender,
    double? height,
    double? weight,
    String? bodyType,
    String? location,
    String? preferredLanguage,
    String? preferredStyle,
    List<String>? favoriteColors,
    List<String>? dislikedColors,
    List<String>? preferredStyles,
    List<String>? preferredOccasions,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return UserModel(
      id: id ?? this.id,
      name: name ?? this.name,
      email: email ?? this.email,
      profileImage: profileImage ?? this.profileImage,
      age: age ?? this.age,
      gender: gender ?? this.gender,
      height: height ?? this.height,
      weight: weight ?? this.weight,
      bodyType: bodyType ?? this.bodyType,
      location: location ?? this.location,
      preferredLanguage:
          preferredLanguage ?? this.preferredLanguage,
      preferredStyle:
          preferredStyle ?? this.preferredStyle,
      favoriteColors:
          favoriteColors ?? this.favoriteColors,
      dislikedColors:
          dislikedColors ?? this.dislikedColors,
      preferredStyles:
          preferredStyles ?? this.preferredStyles,
      preferredOccasions:
          preferredOccasions ?? this.preferredOccasions,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'email': email,
      'profileImage': profileImage,
      'age': age,
      'gender': gender,
      'height': height,
      'weight': weight,
      'bodyType': bodyType,
      'location': location,
      'preferredLanguage': preferredLanguage,
      'preferredStyle': preferredStyle,
      'favoriteColors': favoriteColors,
      'dislikedColors': dislikedColors,
      'preferredStyles': preferredStyles,
      'preferredOccasions': preferredOccasions,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
    };
  }

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'] as String? ?? '',
      name: json['name'] as String? ?? '',
      email: json['email'] as String? ?? '',
      profileImage: json['profileImage'] as String?,
      age: (json['age'] as num?)?.toInt(),
      gender: json['gender'] as String?,
      height: (json['height'] as num?)?.toDouble(),
      weight: (json['weight'] as num?)?.toDouble(),
      bodyType: json['bodyType'] as String?,
      location: json['location'] as String?,
      preferredLanguage:
          json['preferredLanguage'] as String?,
      preferredStyle:
          json['preferredStyle'] as String?,
      favoriteColors:
          List<String>.from(json['favoriteColors'] ?? const []),
      dislikedColors:
          List<String>.from(json['dislikedColors'] ?? const []),
      preferredStyles:
          List<String>.from(json['preferredStyles'] ?? const []),
      preferredOccasions:
          List<String>.from(json['preferredOccasions'] ?? const []),
      createdAt: DateTime.tryParse(
            json['createdAt'] as String? ?? '',
          ) ??
          DateTime.now(),
      updatedAt: DateTime.tryParse(
            json['updatedAt'] as String? ?? '',
          ) ??
          DateTime.now(),
    );
  }

  @override
  String toString() {
    return 'UserModel(id: $id, name: $name, email: $email)';
  }
}