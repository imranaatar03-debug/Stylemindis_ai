class OutfitItemModel {
  final String id;
  final String outfitId;
  final String clothingItemId;
  final String category;
  final int position;
  final DateTime createdAt;

  const OutfitItemModel({
    required this.id,
    required this.outfitId,
    required this.clothingItemId,
    required this.category,
    this.position = 0,
    required this.createdAt,
  });

  OutfitItemModel copyWith({
    String? id,
    String? outfitId,
    String? clothingItemId,
    String? category,
    int? position,
    DateTime? createdAt,
  }) {
    return OutfitItemModel(
      id: id ?? this.id,
      outfitId: outfitId ?? this.outfitId,
      clothingItemId: clothingItemId ?? this.clothingItemId,
      category: category ?? this.category,
      position: position ?? this.position,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'outfitId': outfitId,
      'clothingItemId': clothingItemId,
      'category': category,
      'position': position,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory OutfitItemModel.fromJson(Map<String, dynamic> json) {
    return OutfitItemModel(
      id: json['id'] as String? ?? '',
      outfitId: json['outfitId'] as String? ?? '',
      clothingItemId:
          json['clothingItemId'] as String? ?? '',
      category: json['category'] as String? ?? '',
      position: (json['position'] as num?)?.toInt() ?? 0,
      createdAt: DateTime.tryParse(
            json['createdAt'] as String? ?? '',
          ) ??
          DateTime.now(),
    );
  }

  @override
  String toString() {
    return 'OutfitItemModel('
        'id: $id, '
        'outfitId: $outfitId, '
        'clothingItemId: $clothingItemId, '
        'category: $category, '
        'position: $position'
        ')';
  }
}