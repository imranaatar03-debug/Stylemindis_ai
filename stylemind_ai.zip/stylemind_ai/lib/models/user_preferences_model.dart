class UserPreferencesModel {
  final List<String> preferredStyles;
  final List<String> preferredColors;
  final List<String> dislikedColors;
  final List<String> preferredOccasions;
  final List<String> favoriteBrands;
  final List<String> preferredCategories;
  final String? preferredSeason;
  final String? preferredFit;
  final bool useWeatherRecommendations;
  final bool useAiVisualization;
  final bool notificationsEnabled;
  final bool personalizedRecommendations;

  const UserPreferencesModel({
    this.preferredStyles = const [],
    this.preferredColors = const [],
    this.dislikedColors = const [],
    this.preferredOccasions = const [],
    this.favoriteBrands = const [],
    this.preferredCategories = const [],
    this.preferredSeason,
    this.preferredFit,
    this.useWeatherRecommendations = false,
    this.useAiVisualization = true,
    this.notificationsEnabled = true,
    this.personalizedRecommendations = true,
  });

  UserPreferencesModel copyWith({
    List<String>? preferredStyles,
    List<String>? preferredColors,
    List<String>? dislikedColors,
    List<String>? preferredOccasions,
    List<String>? favoriteBrands,
    List<String>? preferredCategories,
    String? preferredSeason,
    String? preferredFit,
    bool? useWeatherRecommendations,
    bool? useAiVisualization,
    bool? notificationsEnabled,
    bool? personalizedRecommendations,
  }) {
    return UserPreferencesModel(
      preferredStyles: preferredStyles ?? this.preferredStyles,
      preferredColors: preferredColors ?? this.preferredColors,
      dislikedColors: dislikedColors ?? this.dislikedColors,
      preferredOccasions:
          preferredOccasions ?? this.preferredOccasions,
      favoriteBrands: favoriteBrands ?? this.favoriteBrands,
      preferredCategories:
          preferredCategories ?? this.preferredCategories,
      preferredSeason: preferredSeason ?? this.preferredSeason,
      preferredFit: preferredFit ?? this.preferredFit,
      useWeatherRecommendations:
          useWeatherRecommendations ??
              this.useWeatherRecommendations,
      useAiVisualization:
          useAiVisualization ?? this.useAiVisualization,
      notificationsEnabled:
          notificationsEnabled ?? this.notificationsEnabled,
      personalizedRecommendations:
          personalizedRecommendations ??
              this.personalizedRecommendations,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'preferredStyles': preferredStyles,
      'preferredColors': preferredColors,
      'dislikedColors': dislikedColors,
      'preferredOccasions': preferredOccasions,
      'favoriteBrands': favoriteBrands,
      'preferredCategories': preferredCategories,
      'preferredSeason': preferredSeason,
      'preferredFit': preferredFit,
      'useWeatherRecommendations':
          useWeatherRecommendations,
      'useAiVisualization': useAiVisualization,
      'notificationsEnabled': notificationsEnabled,
      'personalizedRecommendations':
          personalizedRecommendations,
    };
  }

  factory UserPreferencesModel.fromJson(
    Map<String, dynamic> json,
  ) {
    return UserPreferencesModel(
      preferredStyles: List<String>.from(
        json['preferredStyles'] ?? const [],
      ),
      preferredColors: List<String>.from(
        json['preferredColors'] ?? const [],
      ),
      dislikedColors: List<String>.from(
        json['dislikedColors'] ?? const [],
      ),
      preferredOccasions: List<String>.from(
        json['preferredOccasions'] ?? const [],
      ),
      favoriteBrands: List<String>.from(
        json['favoriteBrands'] ?? const [],
      ),
      preferredCategories: List<String>.from(
        json['preferredCategories'] ?? const [],
      ),
      preferredSeason:
          json['preferredSeason'] as String?,
      preferredFit: json['preferredFit'] as String?,
      useWeatherRecommendations:
          json['useWeatherRecommendations'] as bool? ??
              false,
      useAiVisualization:
          json['useAiVisualization'] as bool? ?? true,
      notificationsEnabled:
          json['notificationsEnabled'] as bool? ?? true,
      personalizedRecommendations:
          json['personalizedRecommendations'] as bool? ??
              true,
    );
  }

  @override
  String toString() {
    return 'UserPreferencesModel('
        'styles: ${preferredStyles.length}, '
        'colors: ${preferredColors.length}, '
        'occasions: ${preferredOccasions.length}'
        ')';
  }
}