import 'clothing_item_model.dart';

class OutfitModel {
  final String id;
  final String name;
  final List<ClothingItemModel> items;
  final String? occasion;
  final String? style;
  final int compatibilityScore;
  final String? description;
  final String? imagePath;
  final bool isFavorite;
  final bool isSaved;
  final DateTime createdAt;
  final DateTime updatedAt;

  const OutfitModel({
    required this.id,
    required this.name,
    this.items = const [],
    this.occasion,
    this.style,
    this.compatibilityScore = 0,
    this.description,
    this.imagePath,
    this.isFavorite = false,
    this.isSaved = false,
    required this.createdAt,
    required this.updatedAt,
  });

  OutfitModel copyWith({
    String? id,
    String? name,
    List<ClothingItemModel>? items,
    String? occasion,
    String? style,
    int? compatibilityScore,
    String? description,
    String? imagePath,
    bool? isFavorite,
    bool? isSaved,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return OutfitModel(
      id: id ?? this.id,
      name: name ?? this.name,
      items: items ?? this.items,
      occasion: occasion ?? this.occasion,
      style: style ?? this.style,
      compatibilityScore:
          compatibilityScore ?? this.compatibilityScore,
      description: description ?? this.description,
      imagePath: imagePath ?? this.imagePath,
      isFavorite: isFavorite ?? this.isFavorite,
      isSaved: isSaved ?? this.isSaved,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'items': items.map((item) => item.toJson()).toList(),
      'occasion': occasion,
      'style': style,
      'compatibilityScore': compatibilityScore,
      'description': description,
      'imagePath': imagePath,
      'isFavorite': isFavorite,
      'isSaved': isSaved,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
    };
  }

  factory OutfitModel.fromJson(Map<String, dynamic> json) {
    final itemsJson = json['items'];

    return OutfitModel(
      id: json['id'] as String? ?? '',
      name: json['name'] as String? ?? '',
      items: itemsJson is List
          ? itemsJson
              .whereType<Map>()
              .map(
                (item) => ClothingItemModel.fromJson(
                  Map<String, dynamic>.from(item),
                ),
              )
              .toList()
          : const [],
      occasion: json['occasion'] as String?,
      style: json['style'] as String?,
      compatibilityScore:
          (json['compatibilityScore'] as num?)?.toInt() ?? 0,
      description: json['description'] as String?,
      imagePath: json['imagePath'] as String?,
      isFavorite: json['isFavorite'] as bool? ?? false,
      isSaved: json['isSaved'] as bool? ?? false,
      createdAt: DateTime.tryParse(
            json['createdAt'] as String? ?? '',
          ) ??
          DateTime.now(),
      updatedAt: DateTime.tryParse(
            json['updatedAt'] as String? ?? '',
          ) ??
          DateTime.now(),
    );
  }

  int get itemCount => items.length;

  bool get isComplete {
    final categories = items.map((item) => item.category).toSet();

    return categories.contains('tops') &&
        categories.contains('bottoms') &&
        categories.contains('shoes');
  }

  @override
  String toString() {
    return 'OutfitModel('
        'id: $id, '
        'name: $name, '
        'items: ${items.length}, '
        'score: $compatibilityScore'
        ')';
  }
}