class WeatherModel {
  final String city;
  final String country;
  final double temperature;
  final double feelsLike;
  final double minTemperature;
  final double maxTemperature;
  final int humidity;
  final double windSpeed;
  final String condition;
  final String description;
  final String icon;
  final DateTime updatedAt;

  const WeatherModel({
    required this.city,
    required this.country,
    required this.temperature,
    required this.feelsLike,
    required this.minTemperature,
    required this.maxTemperature,
    required this.humidity,
    required this.windSpeed,
    required this.condition,
    required this.description,
    required this.icon,
    required this.updatedAt,
  });

  WeatherModel copyWith({
    String? city,
    String? country,
    double? temperature,
    double? feelsLike,
    double? minTemperature,
    double? maxTemperature,
    int? humidity,
    double? windSpeed,
    String? condition,
    String? description,
    String? icon,
    DateTime? updatedAt,
  }) {
    return WeatherModel(
      city: city ?? this.city,
      country: country ?? this.country,
      temperature: temperature ?? this.temperature,
      feelsLike: feelsLike ?? this.feelsLike,
      minTemperature: minTemperature ?? this.minTemperature,
      maxTemperature: maxTemperature ?? this.maxTemperature,
      humidity: humidity ?? this.humidity,
      windSpeed: windSpeed ?? this.windSpeed,
      condition: condition ?? this.condition,
      description: description ?? this.description,
      icon: icon ?? this.icon,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'city': city,
      'country': country,
      'temperature': temperature,
      'feelsLike': feelsLike,
      'minTemperature': minTemperature,
      'maxTemperature': maxTemperature,
      'humidity': humidity,
      'windSpeed': windSpeed,
      'condition': condition,
      'description': description,
      'icon': icon,
      'updatedAt': updatedAt.toIso8601String(),
    };
  }

  factory WeatherModel.fromJson(Map<String, dynamic> json) {
    return WeatherModel(
      city: json['city'] as String? ?? '',
      country: json['country'] as String? ?? '',
      temperature:
          (json['temperature'] as num?)?.toDouble() ?? 0.0,
      feelsLike:
          (json['feelsLike'] as num?)?.toDouble() ?? 0.0,
      minTemperature:
          (json['minTemperature'] as num?)?.toDouble() ?? 0.0,
      maxTemperature:
          (json['maxTemperature'] as num?)?.toDouble() ?? 0.0,
      humidity:
          (json['humidity'] as num?)?.toInt() ?? 0,
      windSpeed:
          (json['windSpeed'] as num?)?.toDouble() ?? 0.0,
      condition:
          json['condition'] as String? ?? '',
      description:
          json['description'] as String? ?? '',
      icon:
          json['icon'] as String? ?? '',
      updatedAt: DateTime.tryParse(
            json['updatedAt'] as String? ?? '',
          ) ??
          DateTime.now(),
    );
  }

  bool get isCold => temperature < 15;

  bool get isMild =>
      temperature >= 15 && temperature < 25;

  bool get isHot => temperature >= 25;

  bool get isRainy {
    final value = condition.toLowerCase();

    return value.contains('rain') ||
        value.contains('drizzle') ||
        value.contains('thunderstorm');
  }

  bool get isCloudy {
    final value = condition.toLowerCase();

    return value.contains('cloud') ||
        value.contains('overcast');
  }

  bool get isClear {
    final value = condition.toLowerCase();

    return value.contains('clear') ||
        value.contains('sun');
  }

  @override
  String toString() {
    return 'WeatherModel('
        'city: $city, '
        'temperature: $temperature, '
        'condition: $condition'
        ')';
  }
}