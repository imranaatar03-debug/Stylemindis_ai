import 'package:flutter/material.dart';

import '../features/ai_camera/presentation/ai_style_scan_screen.dart';
import '../features/auth/presentation/forgot_password_screen.dart';
import '../features/auth/presentation/login_screen.dart';
import '../features/auth/presentation/signup_screen.dart';
import '../features/onboarding/presentation/onboarding_screen.dart';
import '../features/outfit_generator/presentation/create_outfit_screen.dart';
import '../features/outfit_generator/presentation/generating_outfit_screen.dart';
import '../features/outfit_generator/presentation/outfit_result_screen.dart';
import '../features/outfits/presentation/favorites_screen.dart';
import '../features/outfits/presentation/outfits_screen.dart';
import '../features/profile/presentation/privacy_screen.dart';
import '../features/profile/presentation/profile_screen.dart';
import '../features/splash/presentation/splash_screen.dart';
import '../features/style_profile/presentation/color_preferences_screen.dart';
import '../features/style_profile/presentation/style_profile_screen.dart';
import '../features/wardrobe/presentation/add_clothing_screen.dart';
import '../features/wardrobe/presentation/clothing_details_screen.dart';
import '../features/wardrobe/presentation/wardrobe_screen.dart';
import '../models/clothing_item_model.dart';
import '../models/outfit_model.dart';
import '../navigation/bottom_navigation.dart';

class AppRoutes {
  AppRoutes._();

  static const String initialRoute = '/';

  static const String splash = '/';
  static const String onboarding = '/onboarding';
  static const String login = '/login';
  static const String signup = '/signup';
  static const String forgotPassword = '/forgot-password';
  static const String home = '/home';
  static const String wardrobe = '/wardrobe';
  static const String addClothing = '/add-clothing';
  static const String clothingDetails = '/clothing-details';
  static const String createOutfit = '/create-outfit';
  static const String generatingOutfit = '/generating-outfit';
  static const String outfitResult = '/outfit-result';
  static const String outfits = '/outfits';
  static const String favorites = '/favorites';
  static const String aiStyleScan = '/ai-style-scan';
  static const String profile = '/profile';
  static const String styleProfile = '/style-profile';
  static const String colorPreferences = '/color-preferences';
  static const String privacy = '/privacy';

  /// Screens registered via the static [routes] table.
  ///
  /// [clothingDetails] expects a `String` item id as its route argument.
  /// [generatingOutfit] expects a `Map` with `wardrobe`
  /// (`List<ClothingItemModel>`), `occasion` and `style` (`String`) keys.
  /// [outfitResult] optionally accepts an [OutfitModel] as its route
  /// argument; when omitted the screen falls back to its own empty state.
  static final Map<String, WidgetBuilder> routes = {
    splash: (context) => const SplashScreen(),
    onboarding: (context) => const OnboardingScreen(),
    login: (context) => const LoginScreen(),
    signup: (context) => const SignupScreen(),
    forgotPassword: (context) => const ForgotPasswordScreen(),
    home: (context) => const BottomNavigation(),
    wardrobe: (context) => const WardrobeScreen(),
    addClothing: (context) => const AddClothingScreen(),
    clothingDetails: (context) {
      final args = ModalRoute.of(context)?.settings.arguments;
      return ClothingDetailsScreen(itemId: args is String ? args : '');
    },
    createOutfit: (context) => const CreateOutfitScreen(),
    generatingOutfit: (context) {
      final args = ModalRoute.of(context)?.settings.arguments;
      final map = args is Map ? args : const {};
      final rawWardrobe = map['wardrobe'];

      return GeneratingOutfitScreen(
        wardrobe: rawWardrobe is List<ClothingItemModel>
            ? rawWardrobe
            : null,
        occasion: map['occasion'] is String
            ? map['occasion'] as String
            : null,
        style: map['style'] is String ? map['style'] as String : null,
      );
    },
    outfitResult: (context) {
      final args = ModalRoute.of(context)?.settings.arguments;
      return OutfitResultScreen(
        outfit: args is OutfitModel ? args : null,
      );
    },
    outfits: (context) => const OutfitsScreen(),
    favorites: (context) => const FavoritesScreen(),
    aiStyleScan: (context) => const AiStyleScanScreen(),
    profile: (context) => const ProfileScreen(),
    styleProfile: (context) => const StyleProfileScreen(),
    colorPreferences: (context) => const ColorPreferencesScreen(),
    privacy: (context) => const PrivacyScreen(),
  };
}

