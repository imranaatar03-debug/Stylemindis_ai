import 'package:flutter/material.dart';

import '../theme/theme.dart';
import 'routes.dart';

class StyleMindApp extends StatelessWidget {
  const StyleMindApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'STYLEMIND AI',

      debugShowCheckedModeBanner: false,

      theme: StyleMindTheme.light,

      darkTheme: StyleMindTheme.dark,

      themeMode: ThemeMode.system,

      initialRoute: AppRoutes.initialRoute,

      routes: AppRoutes.routes,
    );
  }
}