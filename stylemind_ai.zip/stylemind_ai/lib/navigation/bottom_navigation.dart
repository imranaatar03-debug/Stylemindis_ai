import 'package:flutter/material.dart';

import '../core/constants/colors.dart';
import '../core/constants/strings.dart';
import '../features/ai_camera/presentation/ai_style_scan_screen.dart';
import '../features/home/presentation/home_screen.dart';
import '../features/outfits/presentation/outfits_screen.dart';
import '../features/profile/presentation/profile_screen.dart';
import '../features/wardrobe/presentation/wardrobe_screen.dart';

class BottomNavigation extends StatefulWidget {
  const BottomNavigation({
    super.key,
    this.initialIndex = 0,
  });

  final int initialIndex;

  @override
  State<BottomNavigation> createState() =>
      _BottomNavigationState();
}

class _BottomNavigationState
    extends State<BottomNavigation> {
  late int _currentIndex;

  final List<Widget> _screens = const [
    HomeScreen(),
    WardrobeScreen(),
    AiStyleScanScreen(),
    OutfitsScreen(),
    ProfileScreen(),
  ];

  @override
  void initState() {
    super.initState();

    _currentIndex = widget.initialIndex.clamp(
      0,
      _screens.length - 1,
    );
  }

  void _onItemTapped(int index) {
    if (_currentIndex == index) return;

    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      extendBody: true,
      body: IndexedStack(
        index: _currentIndex,
        children: _screens,
      ),
      bottomNavigationBar: SafeArea(
        minimum: const EdgeInsets.fromLTRB(
          12,
          0,
          12,
          12,
        ),
        child: Container(
          height: 72,
          decoration: BoxDecoration(
            color: theme.cardColor.withOpacity(0.96),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(
              color: AppColors.border.withOpacity(0.6),
            ),
            boxShadow: [
              BoxShadow(
                color: AppColors.primary.withOpacity(0.12),
                blurRadius: 30,
                spreadRadius: 2,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Row(
            children: [
              Expanded(
                child: _NavigationItem(
                  icon: Icons.home_outlined,
                  activeIcon: Icons.home_rounded,
                  label: AppStrings.home,
                  selected: _currentIndex == 0,
                  onTap: () => _onItemTapped(0),
                ),
              ),
              Expanded(
                child: _NavigationItem(
                  icon: Icons.checkroom_outlined,
                  activeIcon: Icons.checkroom_rounded,
                  label: AppStrings.wardrobe,
                  selected: _currentIndex == 1,
                  onTap: () => _onItemTapped(1),
                ),
              ),
              Expanded(
                child: _CameraNavigationItem(
                  selected: _currentIndex == 2,
                  onTap: () => _onItemTapped(2),
                ),
              ),
              Expanded(
                child: _NavigationItem(
                  icon: Icons.style_outlined,
                  activeIcon: Icons.style_rounded,
                  label: AppStrings.outfits,
                  selected: _currentIndex == 3,
                  onTap: () => _onItemTapped(3),
                ),
              ),
              Expanded(
                child: _NavigationItem(
                  icon: Icons.person_outline_rounded,
                  activeIcon: Icons.person_rounded,
                  label: AppStrings.profile,
                  selected: _currentIndex == 4,
                  onTap: () => _onItemTapped(4),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _NavigationItem extends StatelessWidget {
  const _NavigationItem({
    required this.icon,
    required this.activeIcon,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final IconData icon;
  final IconData activeIcon;
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = selected
        ? AppColors.primary
        : Theme.of(context)
            .textTheme
            .bodySmall
            ?.color
            ?.withOpacity(0.65);

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 220),
            padding: const EdgeInsets.symmetric(
              horizontal: 12,
              vertical: 5,
            ),
            decoration: BoxDecoration(
              color: selected
                  ? AppColors.primary.withOpacity(0.12)
                  : Colors.transparent,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(
              selected ? activeIcon : icon,
              size: 23,
              color: color,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 10,
              fontWeight:
                  selected ? FontWeight.w700 : FontWeight.w500,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}

class _CameraNavigationItem extends StatelessWidget {
  const _CameraNavigationItem({
    required this.selected,
    required this.onTap,
  });

  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          width: 58,
          height: 58,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                AppColors.primary,
                AppColors.secondary,
              ],
            ),
            boxShadow: [
              BoxShadow(
                color: AppColors.primary.withOpacity(
                  selected ? 0.45 : 0.28,
                ),
                blurRadius: selected ? 22 : 14,
                spreadRadius: selected ? 3 : 1,
              ),
            ],
            border: Border.all(
              color: Colors.white.withOpacity(0.85),
              width: 3,
            ),
          ),
          child: const Icon(
            Icons.auto_awesome_rounded,
            color: Colors.white,
            size: 27,
          ),
        ),
      ),
    );
  }
}