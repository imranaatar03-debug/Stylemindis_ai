import 'package:flutter/material.dart';

import '../core/constants/colors.dart';

class LightTheme {
  LightTheme._();

  static ThemeData get theme {
    final base = ThemeData.light();

    return base.copyWith(
      brightness: Brightness.light,
      scaffoldBackgroundColor:
          AppColors.lightBackground,
      canvasColor:
          AppColors.lightBackground,
      cardColor:
          AppColors.lightCard,
      primaryColor:
          AppColors.primary,

      colorScheme: const ColorScheme.light(
        primary: AppColors.primary,
        secondary: AppColors.secondary,
        surface: AppColors.lightCard,
        error: AppColors.error,
        onPrimary: Colors.white,
        onSecondary: Colors.black,
        onSurface: AppColors.lightText,
        onError: Colors.white,
      ),

      appBarTheme: const AppBarTheme(
        backgroundColor:
            AppColors.lightBackground,
        foregroundColor:
            AppColors.lightText,
        elevation: 0,
        centerTitle: false,
      ),

      dividerTheme: const DividerThemeData(
        color: AppColors.lightBorder,
        thickness: 1,
      ),

      inputDecorationTheme:
          InputDecorationTheme(
        filled: true,
        fillColor:
            AppColors.lightCard,
        border: OutlineInputBorder(
          borderRadius:
              BorderRadius.circular(16),
          borderSide: const BorderSide(
            color: AppColors.lightBorder,
          ),
        ),
        enabledBorder:
            OutlineInputBorder(
          borderRadius:
              BorderRadius.circular(16),
          borderSide: const BorderSide(
            color: AppColors.lightBorder,
          ),
        ),
        focusedBorder:
            OutlineInputBorder(
          borderRadius:
              BorderRadius.circular(16),
          borderSide: const BorderSide(
            color: AppColors.primary,
            width: 1.5,
          ),
        ),
        hintStyle: const TextStyle(
          color:
              AppColors.lightSecondaryText,
        ),
      ),

      elevatedButtonTheme:
          ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor:
              AppColors.primary,
          foregroundColor:
              Colors.white,
          elevation: 0,
          minimumSize:
              const Size(double.infinity, 52),
          shape:
              RoundedRectangleBorder(
            borderRadius:
                BorderRadius.circular(16),
          ),
        ),
      ),

      textButtonTheme:
          TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor:
              AppColors.primaryDark,
        ),
      ),

      snackBarTheme:
          const SnackBarThemeData(
        backgroundColor:
            AppColors.lightText,
        contentTextStyle:
            TextStyle(
          color: Colors.white,
        ),
        behavior:
            SnackBarBehavior.floating,
      ),
    );
  }
}