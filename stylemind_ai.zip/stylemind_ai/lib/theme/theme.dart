import 'package:flutter/material.dart';

import 'app_theme.dart';
import 'dark_theme.dart';
import 'light_theme.dart';

export 'app_theme.dart';
export 'dark_theme.dart';
export 'light_theme.dart';

/// Convenience facade used by [StyleMindApp] to access the light/dark
/// [ThemeData] without callers needing to know about [AppTheme] directly.
class StyleMindTheme {
  StyleMindTheme._();

  static ThemeData get light => AppTheme.lightTheme;

  static ThemeData get dark => AppTheme.darkTheme;
}
