import 'package:flutter/material.dart';

import '../core/constants/colors.dart';

class DarkTheme {
  DarkTheme._();

  static ThemeData get theme {
    final base = ThemeData.dark();

    return base.copyWith(
      brightness: Brightness.dark,
      scaffoldBackgroundColor:
          AppColors.darkBackground,
      canvasColor:
          AppColors.darkBackground,
      cardColor:
          AppColors.darkCard,
      primaryColor:
          AppColors.primary,

      colorScheme: const ColorScheme.dark(
        primary: AppColors.primary,
        secondary: AppColors.secondary,
        surface: AppColors.darkCard,
        error: AppColors.error,
        onPrimary: Colors.white,
        onSecondary: Colors.black,
        onSurface: AppColors.darkText,
        onError: Colors.white,
      ),

      appBarTheme: const AppBarTheme(
        backgroundColor:
            AppColors.darkBackground,
        foregroundColor:
            AppColors.darkText,
        elevation: 0,
        centerTitle: false,
      ),

      dividerTheme: const DividerThemeData(
        color: AppColors.darkBorder,
        thickness: 1,
      ),

      inputDecorationTheme:
          InputDecorationTheme(
        filled: true,
        fillColor:
            AppColors.darkCard,
        border: OutlineInputBorder(
          borderRadius:
              BorderRadius.circular(16),
          borderSide: const BorderSide(
            color: AppColors.darkBorder,
          ),
        ),
        enabledBorder:
            OutlineInputBorder(
          borderRadius:
              BorderRadius.circular(16),
          borderSide: const BorderSide(
            color: AppColors.darkBorder,
          ),
        ),
        focusedBorder:
            OutlineInputBorder(
          borderRadius:
              BorderRadius.circular(16),
          borderSide: const BorderSide(
            color: AppColors.primary,
            width: 1.5,
          ),
        ),
        hintStyle: const TextStyle(
          color: AppColors.darkSecondaryText,
        ),
      ),

      elevatedButtonTheme:
          ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor:
              AppColors.primary,
          foregroundColor:
              Colors.white,
          elevation: 0,
          minimumSize:
              const Size(double.infinity, 52),
          shape:
              RoundedRectangleBorder(
            borderRadius:
                BorderRadius.circular(16),
          ),
        ),
      ),

      textButtonTheme:
          TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor:
              AppColors.primaryLight,
        ),
      ),

      snackBarTheme:
          const SnackBarThemeData(
        backgroundColor:
            AppColors.darkCard,
        contentTextStyle:
            TextStyle(
          color: AppColors.darkText,
        ),
        behavior:
            SnackBarBehavior.floating,
      ),
    );
  }
}