import 'package:flutter/material.dart';

import '../core/constants/colors.dart';
import 'dark_theme.dart';
import 'light_theme.dart';

class AppTheme {
  AppTheme._();

  static ThemeData get lightTheme =>
      LightTheme.theme;

  static ThemeData get darkTheme =>
      DarkTheme.theme;

  static ThemeData getTheme(
    Brightness brightness,
  ) {
    return brightness == Brightness.dark
        ? darkTheme
        : lightTheme;
  }

  static ThemeData applyTextTheme(
    ThemeData theme,
  ) {
    return theme.copyWith(
      textTheme: theme.textTheme.apply(
        fontFamily: 'Roboto',
        bodyColor: theme.brightness == Brightness.dark
            ? AppColors.darkText
            : AppColors.lightText,
        displayColor: theme.brightness == Brightness.dark
            ? AppColors.darkText
            : AppColors.lightText,
      ),
    );
  }
}