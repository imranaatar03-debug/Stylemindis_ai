# STYLEMIND AI

> Your Wardrobe. Your Style. Powered by AI.

STYLEMIND AI is a modern AI-powered fashion assistant designed to help users understand their wardrobe, discover outfit combinations, and make smarter clothing choices.

## ✨ Core Features

- 🤖 AI-powered style recommendations
- 📷 AI STYLE SCAN camera
- 👕 Digital wardrobe
- 🎨 Color matching
- 🧩 Outfit generator
- ✅ DOES THIS MATCH?
- 💬 AI fashion assistant
- ❤️ Favorite outfits
- 📅 Outfit calendar
- 🕘 Outfit history
- 🌤️ Weather-based suggestions
- 🔐 Privacy controls
- 🌙 Light and dark themes

## 📱 Main Navigation

The application contains five main sections:

1. HOME
2. WARDROBE
3. AI CAMERA
4. OUTFITS
5. PROFILE

The AI Camera is intentionally emphasized as the central action.

## 🧠 AI Style System

STYLEMIND AI can analyze clothing items and use information such as:

- Category
- Color
- Style
- Occasion
- Wardrobe availability
- Compatibility

The outfit generator prioritizes clothing already available in the user's wardrobe.

## 👔 Supported Clothing

Examples include:

- T-Shirts
- Shirts
- Hoodies
- Jackets
- Jeans
- Pants
- Cargo Pants
- Shorts
- Sneakers
- Shoes
- Hats
- Bags
- Accessories

## 🎯 Supported Styles

- Casual
- Streetwear
- Sporty
- Minimal
- Classic

## 🎉 Supported Occasions

- School
- Casual Day
- Friends
- Family Event
- Sport
- Special Event

## 🎨 Design

STYLEMIND AI uses a premium futuristic interface featuring:

- Rounded cards
- Glass-style surfaces
- AI glow effects
- Smooth animations
- Modern typography
- Light mode
- Dark mode
- Purple, cyan and pink accent colors

## 🔐 Privacy

The application is designed around user control.

Users should be able to:

- Control camera permissions
- Control notification permissions
- Delete uploaded clothing images
- Delete wardrobe data
- Delete saved outfits
- Delete account-related data
- Control optional features

Uploaded images should only be used for the application's intended fashion features.

## 🗂️ Project Structure

```text
stylemind_ai/
├── android/
├── ios/
├── web/
├── assets/
├── lib/
│   ├── app/
│   ├── core/
│   ├── models/
│   ├── features/
│   └── navigation/
├── test/
├── pubspec.yaml
├── analysis_options.yaml
└── README.md